
rm /mnt/sata/test.out
./function_test > function_test.ret

rm /mnt/sata/test.out
./test1 > /dev/null
./dumpcsi
./dumpcsi -p 0

rm /mnt/sata/test.out
./linkedlist_test
./csiio_test > /dev/null


rm /mnt/sata/test.out
./csisimplerwlock_test -t 32 -l 1000000
./csistoredgroup_test -l 2000 -k 32 -v 64 -i 1
./csistoredgroup_test -l 80000 -k 32 -v 512 -i 200
./csistoredgroup_test -l 800000 -k 32 -v 512 -i 20000
./csimemgroup_test -t 16 -l 10000 -k 32 -v 128
./csipagemanager_test  -t 1 -l 1 -k 32 -v 512
./csislotdir_test
./filter_test  -s 4000 -c 4000
./csiq_test  -s 32 -c 100000 -t 16 > /dev/null

./test3 -t 1 -i 100000 -r 100000 -k 32 -v 1000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 2000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 3000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 4000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 5000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 6000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 7000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 8000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 9000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 10000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 11000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 12000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 13000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 14000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 15000
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 16000

./test3 -t 1 -i 100000 -r 100000 -k 32 -v 1000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 2000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 3000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 4000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 5000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 6000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 7000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 8000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 9000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 10000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 11000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 12000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 13000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 14000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 15000 -f
./test3 -t 1 -i 100000 -r 100000 -k 32 -v 16000 -f
