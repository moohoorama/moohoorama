#ifndef MACRO_H
#define MACRO_H

#include <pthread.h>

#if defined( SPIN_LOCK ) && defined ( MUTEX )
Choose one of SPIN_LOCK and MUTEX
#endif

#define barrier() \
    __asm__ __volatile__("": : :"memory")

#if defined( SPIN_LOCK )
#define LOCKTYPE        pthread_spin_t
#define INIT_LOCK(lock) pthread_spin_init( (lock), PTHREAD_PROCESS_PRIVATE )
#define DEST_LOCK(lock) pthread_spin_destroy(lock)
#define LOCK(x)         pthread_spin_lock(x)
#define TRYLOCK(x)      pthread_spin_lock(x)
#define UNLOCK(x)       pthread_spin_unlock(x)

#elif defined( MUTEX )
#define LOCKTYPE        pthread_mutex_t
#define INIT_LOCK(lock) pthread_mutex_init( (lock), NULL );
#define DEST_LOCK(lock) pthread_mutex_destroy(lock)
#define LOCK(x)         pthread_mutex_lock(x)
#define TRYLOCK(x)      pthread_mutex_trylock(x)
#define UNLOCK(x)       pthread_mutex_unlock(x)
#endif

#ifdef ASSERT_ON
#define ASSERT(x)   assert(x)
#else
#define ASSERT(x)
#endif

#endif 
