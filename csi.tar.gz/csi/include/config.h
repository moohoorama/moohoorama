/* Copyright [2013] <yw0119kim@samsung.net> */

#ifndef INCLUDE_CONFIG_H_
#define INCLUDE_CONFIG_H_

/* Performance Measurement and Integrity Check */
#define PRINT_ON
#define CSI_ASSERT_ON

#define PAGE_SIZE 4096
#define MUTEX     1

/* for CSI */
#define NAME_LEN            (256)
#define MEMGROUP_MAX        (4)
#define MERGING_MAX         (32)
#define MULTI_PAGE_READ_MAX (8)

#define PROPERTY_FILE    "./skvs.ini"
#define CSI_ALIGN        (4)

#define __NORMAL__TRACE__

#endif  // INCLUDE_CONFIG_H_
