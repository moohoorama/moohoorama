#ifndef __CSI_PAGE_MANAGER_H__
#define __CSI_PAGE_MANAGER_H__

#include <common.h>
#include <macro.h>
#include <linkedList.h>
#include <sys/uio.h>
#include <csiSlotDir.h>
#include <csiIO.h>

#define DIO_ALIGN                   (512)
#define NULL_PID                    (-1)
#define CSI_BUFFER_LRUPARALLEL_MAX  (256)
#define ESTIMATED_LASTOFFSET                    \
    (   PAGE_SIZE - sizeof( header->type )      \
        - sizeof( header->siblingSeq )          \
        - sizeof( header->prevPID ) )

/**********************************************************************
 * - Page Header Example
 *  PID : <Type, SiblingSeq,  PrevPID, slots...>
 *
 *    0 : NODE,           0, NULL_PID, [A][B][C]
 *    1 : NODE,           1,        0, [D][E]
 *    2 : NODE,           2,        1, [F][G][H]
 *    3 : ROOT,           0, NULL_PID, [A,0][D,1][F,2]
 *    4 : NODE,           3,        2, [I][J]
 *    5 : ROOT,           1,        3, [I,4]
 *
 **********************************************************************/

class csiPageHeader{
public:
    /* Page의 종류. csiStrucuture.h 의 csiPageType 참조 */
    csiPageType type;
    /* PageType별 페이지 번호.
     * 첫번째 RootPage는 0번, 다음 RootPage는 1번이다. */
    int     siblingSeq;         
    /* 바로 전 같은 Type의 Page의 PID */
    csiPageID   prevPID;
    /* SlotDirectory */
    csiSlotDir  slotDir;
};

/* MPR(MultiPageRead)를 하기 위한 구조체 */
class csiMPRInfo{
public:
    static bool     globalInit();

    bool          init( int bufferCount ); 
    bool          prepare( csiPageID PID ); /* 읽을 Page들을 통보 */
    char        * getNext(); /* Page들을 가져옴 */
    void          dest();

    void          dump();
    int           getReadPageCount(){return readPageCount;}
    int           getReadIOCount(){return readIOCount;}
private:

    /* 아래 Array를 Circurlar Queue로 이용한다. */
    int           bufferCount;      /* 확보된 Buffer 개수 */
    csiPageID     PIDArray[ MULTI_PAGE_READ_MAX + 1];
    char        * buffer[ MULTI_PAGE_READ_MAX + 1];

    /* 아래 두 값을 Queue의 begin/end Position으로 삼는다.*/
    int           prepareCount;
    int           getCount;
    int           readCount;

    int           readPageCount;
    int           readIOCount;
    char          bufferOrg[8192+DIO_ALIGN];

    static int    totalReadIOCount;
    static int    totalReadPageCount;
};

typedef int csiBufferSeq; /* BS(BufferSeq)는 PageManager의 Buffer의 번호 */

class csiBufferInfo{
public:
    csiPageID         PID;
    csiSimpleRWLock   lock;
    int               hitCount;
    LList             hash;
    LList             LRU;
};

class csiFlushPageArray{
public:
    int               groupCount;
    int               count;
    csiPageID         lastPID;
    struct iovec    * array;
    char            * page;
};

class csiFlushInfo {
public:
    LOCKTYPE              lock;
    int                   multiPageWriteCount;
    int                   accumulatedKVCount;
    int                   KVCount;
    int                   flushedPageCount;
    csiFlushPageArray     fpa[ CSI_PAGE_TYPE_MAX ];
    
    csiPageID             beginPID;
    csiPageID             endPID;
    csiPageID             lastFilterPID;
    int                   estimatedCount;

    int                   filterSize;
    char                * filterPtr;

    int                   missCount;
    uint64_t              prepareTime;
    uint64_t              beginTime;
    uint64_t              endTime;
                    
    bool                  init( int kvCount, int fRatio );
    bool                  dest();
};

class csiFlushResult {
public:
    int               nodeMergeLevel;
    int               groupMergeLevel;
    int               KVCount;
    csiPageID         beginPID;
    csiPageID         endPID;
    csiPageID         childBeginPID[ MERGING_MAX ];
    csiPageID         childEndPID[ MERGING_MAX ];
    int               flushedPageCount;
    int               pageCount[ CSI_PAGE_TYPE_MAX ];

    /* nodeMerge에 의해 여러 Filter가 사용될 수 있음
     * flush할때는 하나만 만드니, 0번에만 설정함 */
    csiPageID         lastFilterPID[ MERGING_MAX ];
    int               filterSize[ MERGING_MAX ];
    csiPageID         lastRootPID;
    int               estimatedCount;
    int               childEstimatedCount[ MERGING_MAX ];

    void add4nodeMerge( int seq, csiFlushResult * dst );
    void report( const char * title);
    void print( const char * title);
    void log( const char * title);

    void store( int fd );
    void reload( int fd );
};


class csiPageManager
{
public:
    static bool init();
    static void init_lru();
    static void init_hash();
    static void init_buffer();
    static bool dest();

    /*********************** Flush ***************************/
    static void flushLock();
    /*어떤 Group에 대한 flush를 시작함*/
    static bool flushBegin( int estimatedKeyCount = 0 );
    /*Dpage에 KV를 넣음.*/
    static bool insertKV( ByteArray * key, ByteArray * val); 
    /* Flush 종료됨*/
    static bool flushEnd(   const char      * title, 
                            csiFlushResult  * ret );
    static void flushUnlock();
    static int  flushElapsedSec();
    static int  flushEstimationSec();

    /********************* Scan and Read Page *************************/
    /* 페이지를 찾아보고, 없으면 victim을 얻어 read해 올려놓는다. */
    static char     * findOrReadPage( csiPageID   PID, 
                                    int         * retryCount = NULL );
    static void       releasePage( char * page );

    /* si들의 상태를 보고함 */
    static void report();
    static void dumpPage( char * page );
    static const char * getPageTypeName( csiPageType type ) {
        if( type >= CSI_PAGE_TYPE_MAX ) {
            type = CSI_PAGE_TYPE_NONE;
        }
        static const char typeName[][9]={
            "NONE",
            "DPAGE",
            "NODE",
            "ROOT",
            "FILTER",
            "SUPPL",
            "FLUSHMAX",
            "MEMGROUP",
            "WORKAREA",
            "MAX" };
        
        return typeName[ type ];
    }

    /* 쫓겨나도록, Hit Count를 낮춤 */
    static void kickOut( char * page )
    {
        csiBufferSeq      bs = getSeqByBufPtr( page );
        CSI_ASSERT( bs < infoCount );
        infoPtr[ bs ].hitCount  = -hitThreshold * 160 ;
    }
    static char * getVictimBuffer( bool retry = false )
    { return getBuffer( getVictim( retry ) ); }
    static void releaseVictimBuffer( char * page )
    {
        csiPageHeader   * header    = (csiPageHeader*)page;
        csiBufferSeq      bs        = getSeqByBufPtr( page );
        int               PIdx      = (getThreadID() % 1023)  % LRUParallelity;

        header->type                = CSI_PAGE_TYPE_NONE;
        CSI_ASSERT( bs < infoCount );
        /* 완전히 빈 페이지이기에, FreeList로 넣음 */
        slist_pushHead( &freeList[ PIdx ], &(infoPtr[ bs ].LRU) );
    }

    static bool insertKeyArrayToNode( csiSlotDir    **subSlots, int i );
    /* KeyArray 형태의 Slot에 begin/end key와 DPageID 삽입함 */
    static bool insertToKeyArray(   csiSlotDir          * subSlotDir,
                                    ByteArray             beginKey,
                                    ByteArray             endKey,
                                    csiPageID             PID,
                                    bool                * ret );
    static bool insertToNode(   char        * childDPage,
                                csiPageID     PID );
    static bool insertToRoot(   ByteArray   key, csiPageID PID );

    static int  getBufferSize(){return bufferSize;}

    /* BufferPage를 Header등을 고려하여 초기화함 */
    static void initBufferPage( char        * page, 
                                csiPageType   type);
    
    /* Pointer Address 기반 Buffer 탐색 연산 */
    static csiBufferSeq       getSeqByBufPtr( char * argPtr );
    static bool               validatationBufPtr( char * argPtr );
    static char             * getBuffer( csiBufferSeq i);
private:
    /* LRU List용 */
    static csiBufferSeq     getVictim( bool retry = false, int init_hint=0);
    static void             pushToLRU( csiBufferSeq bs);
    static int              getParallelSeq( csiBufferSeq i );
    static csiBufferSeq     getSeqByInfoPtr( csiBufferInfo * ptr );

    /* Buffer용 */
    /* 페이지를 할당 가능한 페이지로 */
    static char *   findPage( csiPageID     PID, bool RLock );
    /* PID설정용. PID를 찾기 위한 Hash도 관리함  */
    static int      getHashIdx( csiPageID   PID );
    static void     assignPID( char * page, csiPageID   PID );
    static void     assignPID( csiBufferSeq bs, csiPageID   PID );
    static void     unassignPID( csiBufferSeq bs );

    static int      insertSupplementKV( ByteArray *val,
                                        csiLargeValueRef *lvRef);

    /* Flush Internal */
    static bool allocAndRegistFlushPage( csiPageType type );
    static bool flushPages(csiPageType type );
    static bool flushFilter();

    /* Page에 대한 Buffer. DIRECT/IO를 위해, bufferOrgPtr를 4k만큼 크게
     * 할당받고, bufferPtr을 4k 올림시켜 align을 맞춘다 */
    static char             * bufferOrgPtr;
    static char             * bufferPtr;
    static uint64_t           bufferSize;
    static uint64_t           filterRatio;

    static csiBufferInfo    * infoPtr;
    static int                infoCount;

    /* LRU List의 병렬화 정도 */
    static int                LRUParallelity;
    /* 다음번 Victim획득시, 선택할 List Idx */
    static int                LRUPIdx;
    static SyncLList          LRU[ CSI_BUFFER_LRUPARALLEL_MAX ];
    /* 한번도 사용하지 않은 페이지 */
    static int                freePIdx;
    static SyncLList          freeList[ CSI_BUFFER_LRUPARALLEL_MAX ];

    static SyncLList        * hashMap;
    static int                hashMapSize;

    static csiFlushInfo       flushInfo;

    static int                findOrReadPageCount;
    static int                findPageCount;
    static int                dupPageCount;
    static int                readPageCount;

    static int                hitThreshold;
    static int                hashReportLimit;
    static int                hashReportChainingThreshold;
    static int                hashReportLockMissThreshold;
    static int                victimSleepMsec;
    static int                victimSleepCount;

    static int                hitWeightRoot;
    static int                hitWeightNode;
    static int                hitWeightDPage;
    static int                hitWeightDefault;

    static int                kickOutPolicy[ CSI_PAGE_TYPE_MAX ];
};

inline csiBufferSeq csiPageManager::getVictim( bool retry, int init_hint )
{
    int               PIdx;
    LList           * cur = NULL;
    csiBufferSeq      bs;
    int               i;

    /* freelist에 빈 Page가 있으면, 그것부터 사용함 */
    PIdx    = ((getThreadID() % 1023)+init_hint)  % LRUParallelity;
    for( i = 0 ; i < LRUParallelity ; i ++ )
    {
        PIdx    = (PIdx + 1 ) % LRUParallelity ;
        if( freeList[ PIdx ].size )
        {
            cur = slist_popTail( &freeList[ PIdx ] );
            if( cur != NULL )
            {
                bs = getSeqByInfoPtr( (csiBufferInfo*)cur->data );
                infoPtr[ bs ].hitCount = 0;
                CSI_ASSERT( infoPtr[ bs ].PID == NULL_PID );
                return bs;
            }
        }
    }

    while( true )
    {
        for( i = 0 ; i < LRUParallelity ; i ++ )
        {
            while( true )
            {
                PIdx    = (PIdx + 1 ) % LRUParallelity ;
                cur     = slist_popTail( &LRU[ PIdx ] );

                /* 하나도 pop못했다는건, List가 아예 비어있다는 것 */
                if( cur == NULL )   break;

                bs = getSeqByInfoPtr( (csiBufferInfo*)cur->data );

                if( ( infoPtr[ bs ].hitCount >= hitThreshold ) ||
                    ( !infoPtr[ bs ].lock.isNoLock() ) )
                {   /* 꽤 읽었으니, 다시 Top에 달고 다음을 찾음 */
                    infoPtr[ bs ].hitCount -= hitThreshold;
                    pushToLRU( bs );
                    continue;
                }
                infoPtr[ bs ].hitCount = 0;
                if( infoPtr[ bs ].PID != NULL_PID ) unassignPID( bs );
                return bs;
            }
        }

        /* LRU List를 전부 돌았는데도 확보 못하는 상태 */
        atomicInc( &victimSleepCount, 1 );
        if( retry == false ) return NULL_PID;
        usleep( victimSleepMsec );
    }
}

inline void csiPageManager::pushToLRU( csiBufferSeq bs)
{
    slist_pushHead( &LRU[ getParallelSeq( bs ) ],&(infoPtr[ bs ].LRU) );
}

inline int  csiPageManager::getParallelSeq( csiBufferSeq i )
{
    return i % LRUParallelity;
}

inline csiBufferSeq csiPageManager::getSeqByInfoPtr( csiBufferInfo * ptr )
{
    return (ptr - infoPtr);
}

inline csiBufferSeq csiPageManager::getSeqByBufPtr( char * argPtr )
{
    return ((csiBufferSeq)(argPtr - bufferPtr)/PAGE_SIZE);
}

inline bool csiPageManager::validatationBufPtr( char * argPtr )
{
    csiBufferSeq    seq =   getSeqByBufPtr( argPtr );
    bool            ret = false;

    ret= ( 0<=seq ) && ( seq < (int)(bufferSize/PAGE_SIZE) );
    if( ret == false )
    {
        LOG( "bufferPtr : 0x%x", bufferPtr );
        LOG( "object    : 0x%x", argPtr );
        LOG( "seq       : %d", seq );
        LOG( "limit     : %d", bufferSize/PAGE_SIZE );
    }
    
    return ret;
}

inline char *csiPageManager::getBuffer( csiBufferSeq i)
{
    if( i == NULL_PID ) return NULL;
    CSI_DASSERT( i < (int)(bufferSize / PAGE_SIZE) );
    return bufferPtr + i * PAGE_SIZE;
}
inline char *csiPageManager::findPage( csiPageID    PID, bool RLock )
{
    LList           * cur;
    csiBufferInfo   * BInfo;
    SyncLList       * list;
    int               tryCount = 0;
    csiPageHeader   * header = NULL;

    list = &hashMap[ getHashIdx( PID ) ];

    slist_RLock( list );
    for(    cur = list->head.next ; 
            cur != &list->head ; 
            cur = cur->next )
    {
        BInfo = (csiBufferInfo*)cur->data;
        if( BInfo->PID == PID )
        {
            header = (csiPageHeader*)getBuffer( getSeqByInfoPtr( BInfo ) );
            CSI_ASSERT( header != NULL );

            /* RLock 안잡아도 되니 그냥 Return */
            if( RLock == false )    break;

            BInfo->lock.RLock();
            /* RLock잡기 전에 getVictim으로, 변경되었을 수 있음 */
            if( BInfo->PID == PID )
            { /* 성공 */
                switch( header->type )
                {
                    case CSI_PAGE_TYPE_ROOT:
                        BInfo->hitCount += hitWeightRoot;
                        break;
                    case CSI_PAGE_TYPE_NODE:
                        BInfo->hitCount += hitWeightNode;
                        break;
                    case CSI_PAGE_TYPE_DPAGE:
                        BInfo->hitCount += hitWeightDPage;
                        break;
                    default:
                        BInfo->hitCount += hitWeightDefault;
                        break;
                }
                break;
            }
            /* 실패 */
            header = NULL;
            BInfo->lock.release();
        }
        tryCount ++;
        CSI_ASSERT( tryCount <= list->size );
    }
    slist_unlock( list );

    return (char*)header;
}
inline int  csiPageManager::getHashIdx( csiPageID   PID )
{
    return PID % hashMapSize; 
}

inline char *   csiPageManager::findOrReadPage( csiPageID         PID, 
                                                int             * retryCount)
{
    char            * page;
    csiBufferSeq      bs;
    csiBufferInfo   * BInfo;
    LList           * cur;
    SyncLList       * list;
    int               tryCount = 0;
    int               init_hint = 0;
    bool              hadVictim = false;

    atomicInc( &findOrReadPageCount, 1 );
    while( true )
    {
        page = findPage( PID, true /*RLock*/ );
        atomicInc( &findPageCount, 1 );

        /* 찾았다!*/
        if( page  ) break;

        tryCount ++;

        /* 페이지가 버퍼 상에 없다 */
        bs      = getVictim( true/*retry*/, init_hint );
        BInfo   = &infoPtr[ bs ];
        hadVictim = true;

        /*  페이지 중복 Read & Assign방지용.
         * Hash부터 lock 잡아야, Deadlock 안걸림 */
        list = &hashMap[ getHashIdx( PID ) ];
        slist_RLock( list );
        BInfo->lock.WLock();
        for(    cur = list->head.next ; 
                cur != &list->head ; 
                cur = cur->next )
        {
            if( ((csiBufferInfo*)cur->data)->PID == PID )
            {   /* 그 사이에 등록되어 있음(dup). 실패함 */
                slist_unlock( list );
                atomicInc( &dupPageCount, 1 );
                BInfo->lock.release();
                hadVictim = false;
                pushToLRU( bs );
                init_hint ++;

                break;
            }
        }
        if( cur->data )//dup
        {
            continue;
        }
        slist_unlock( list );

        /* PID 등록함 */
        BInfo->PID = PID;
        slist_pushHead( list,&BInfo->hash );

        atomicInc( &readPageCount, 1 );
        page    = getBuffer( bs );
        CSI_ASSERT( page != NULL );
        CSI_ASSERT( csiIO::readPage( (char*)page, PID ) );
        hadVictim = false;
        pushToLRU( bs );
        BInfo->lock.release();
        /* lock 풀고 다시 시도하여, read lock을 잡은체 반환함 */
    }

    CSI_ASSERT( hadVictim == false );

    if( retryCount ) *retryCount = tryCount;

    return page;
}
inline void     csiPageManager::releasePage( char * page )
{
    csiBufferSeq          bs;

    bs = csiPageManager::getSeqByBufPtr( page );
    infoPtr[ bs ].lock.release();
}

#endif
