/* Copyright 2013 yw0119kim@samsung.net */
#ifndef INCLUDE_COMMON_H_
#define INCLUDE_COMMON_H_

#include <assert.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/syscall.h>

#include <config.h>
#include <csiUtil.h>
#include <csiException.h>

#include <string>
#include <vector>
#include <deque>
#include <map>
#include <bitset>
#include <set>

#include <unordered_map>

typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned int   uint;
typedef unsigned long  ulong;

#define GB    1073741824
#define MB    1048576
#define KB    1024

#endif  // INCLUDE_COMMON_H_
