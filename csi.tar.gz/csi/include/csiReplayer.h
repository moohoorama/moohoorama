#ifndef __CSI_REPLAYER_H__
#define __CSI_REPLAYER_H__

#define QUERY_Q_CNT     2
#define QUERY_Q_SIZE    65536

#define RQQ_SIZE        65536

void   initQueryRecording();
void   destQueryRecording();
bool   writeQuery(
        char    * si,
        int       siLen,
        char    * key,
        int       keyLen,
        int       type,
        int       op,
        int       limit );
bool  skipQuery();
void * queryRecordFlusher( void * ptrArg );
void * replayer( void * ptrArg );
void   replayQuery();

#endif /* __CSI_REPLAYER_H__ */
