#ifndef __CSI_INTERFACE_H__
#define __CSI_INTERFACE_H__

#include <common.h>

extern "C" 
{
/*csiStructure.h 의 csiOperation과 맞춰야 함 */
enum
{
    OP_EQ   = 0,    /* Equal */
    OP_GTE  = 1,    /* Grater than or Equal*/
    OP_GT   = 2,    /* Grater than */
    OP_LTE  = 3,    /* Less than or Equal */
    OP_LT   = 4     /* Less than */
};

/* scan시 결과값을 반환하는데 사용할 구조체 */
typedef struct {
    int       keyLen;
    char    * keyBody;
    int       valLen;
    char    * valBody;
} csiResult;

bool csiInsert( int           SINameLen, 
                const char  * SIName, 
                int           keyLen,
                char        * keyBody,
                int           valueLen,
                char        * valueBody,
                int           info ); /* 데이터 삽입 */
bool csiDelete( int           SINameLen, 
                const char  * SIName, 
                int           keyLen,
                char        * keyBody ); /* 데이터 삭제 */
bool csiRead(   int           SINameLen, 
                const char  * SIName, 
                int           keyLen,
                char        * keyBody,
                int         * valueLen,
                char        **valueBody );  /* 데이터 읽기*/
bool csiReadEnd( char * value );

/* range scan */
int  csiScan(   int           SINameLen, 
                const char  * SIName, 
                int           op,
                int           limit,
                int           keyLen,
                char        * keyBody );
csiResult * csiScanNext( int handle );
bool csiScanEnd( int handle );

void csiScanDump( int handle );

void csiReplay();

bool csiGetSIList( int bufferLen, char * buffer );
bool csiCreate( int SINameLen, const char * SIName );               /* 새로운 SI 생성 */
bool csiDrop( int SINameLen, const char * SIName );                 /* SI 제거 */

bool csiTruncate( int SINameLen, const char * SIName );             /* 내용 비우기 */
bool csiForceBlockingFlushAll();                                    /* 모든 SI Flush */
bool csiForceBlockingFlush( int SINameLen, const char * SIName );   /* 강제 Flush */
bool csiForceBlockingCompactionAll();                               /* 모든 SI Compaction */
bool csiForceBlockingCompaction( int SINameLen, const char * SIName );      /*  SI Compaction */
bool csiForceBlockingNodeMergeAll();                                        /* 모든 SI Compaction */
bool csiForceBlockingNodeMerge( int SINameLen, const char * SIName );       /* SI Compaction */
bool csiForceBlockingRangeCompaction( int SINameLen, const char * SIName ); /*  SI Compaction */
uint64_t csiGetSize( int SINameLen, const char * SIName );                      /* SI의 크기반환 */
uint64_t csiGetMemgroupSize( int SINameLen, const char * SIName );              /* SI의 크기반환 */

bool csiInit( bool monitoring = true, bool signalHandling = true, bool forceStdout = false  );          /* CSI 구동 */
void csiReload();                                               /* warm-up */
void csiStore();                                                /* saveMeta */
bool csiDest( bool immedate );                                  /* CSI 종료 */

void csiReportAll();

char *csiGet(int SINameLen, char * name, int keyLen, char * keyBody );
bool csiGetEnd(char * value );
void *GET(int SINameLen, char * name, char* InStream);
void *GETNull();
void GET_callback( char *outstream );
int PUT(int SINameLen, char * name, char* ptr);

}

#endif 
