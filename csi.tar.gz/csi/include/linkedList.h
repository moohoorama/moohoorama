#ifndef __LINKED_LIST_H__
#define __LINKED_LIST_H__

#include <config.h>
#include <macro.h>
#include <csiSimpleRWLock.h>

/* LList(LinkedList) */
typedef struct LList
{
    LList   * prev;
    LList   * next;
    void    * data;
} LList;

#define SLIST_INIT(sl, spin,sleep) slist_init(sl,__FILE__,__LINE__,spin,sleep)

#define LLIST_INIT( x )     (x)->prev=(x)->next=NULL;

/* x - x_next  => x - y - x_next */
#define LLIST_LINK(x,y)     (y)->next=(x)->next;(y)->prev=(x);if((x)->next!=NULL){(x)->next->prev=(y);}(x)->next=(y)

/* x - y - z => x - z */
#define LLIST_UNLINK(x)     if((x)->next!=NULL){(x)->next->prev=(x)->prev;}if((x)->prev!=NULL){(x)->prev->next=(x)->next;}

typedef struct
{
    csiSimpleRWLock  lock;
    LList            head;
    int              size;
}   SyncLList;

void   global_slist_init();

void   slist_init( SyncLList  *slist, 
                   const char *codeFile, 
                   int         codeLine,
                   int         spin = 0,
                   int         sleep = 0);
void   slist_dest( SyncLList * slist );
void   slist_RLock( SyncLList * slist );
void   slist_WLock( SyncLList * slist );
void   slist_unlock( SyncLList * slist );
void   slist_pushHeadNolock( SyncLList * slist, LList * target );
void   slist_pushHead( SyncLList * slist, LList * target );
void   slist_pushTail( SyncLList * slist, LList * target );
LList *slist_popHead( SyncLList * slist );
LList *slist_popTail( SyncLList * slist );
void   slist_remove( SyncLList * slist, LList * target );
void   slist_dest( SyncLList * slist );

void   slist_validation( SyncLList * slist );
void   slist_report( SyncLList * slist );

inline void      slist_RLock( SyncLList * slist )
{
    slist->lock.RLock();
}

inline void     slist_unlock( SyncLList * slist )
{
    slist->lock.release();
}

#endif
