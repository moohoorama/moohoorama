#ifndef __CSI_MEMGROUP_H__
#define __CSI_MEMGROUP_H__

#include <common.h>
#include <map>
#include <csiByteArray.h>
#include <csiPageManager.h>
#include <stdint.h>

/* MemGroup의 Flush별 상태.*/
typedef enum {
    CSI_MEMGROUP_STATUS_ACTIVE,             /* 정상적으로 read/write 중 */
    CSI_MEMGROUP_STATUS_FLUSHING,           /* flush중. read만 됨 */
    CSI_MEMGROUP_STATUS_MAX
} csiMemGroupStatus;

/* MemGroup의 Insert성공 여부 상태 */
typedef enum {
    CSI_MEMGROUP_SUCCESS,
    CSI_MEMGROUP_FAIL_OVERFLOW_VB,
    CSI_MEMGROUP_FAIL_OVERFLOW_VC,
} csiMemGroupResult;

typedef pair<ByteArray, ByteArray>          KVPair;
typedef map<ByteArray, ByteArray>::iterator KVIterator;

class csiMemGroup
{
public:
    static bool init();
    static bool dest();

    /* memGroup을 새로 생성함. seq를 반환함 */
    static csiMemGroup  * create();
    static void           drop( csiMemGroup * memGroup );

    /* MemGroup을 깨긋히 비움 */
    void    clear();

    /*삽입하면서 동시에 정렬함*/
    bool insertAndSort( ByteArray             key,
                        ByteArray             value,
                        uint                  info,
                        csiMemGroupResult   * result );

    /* 데이터를 읽음 */
    bool read(  ByteArray     key, ByteArray * val );
    void readInternal( KVIterator itr, ByteArray *val );

    inline KVIterator   beginScan( ByteArray * key = NULL); /*Scan을 시작함*/
    inline bool         isEndScan( KVIterator * itr ); /*Scan이 끝났는가? */
    inline void         finishScan();

    void report();
    static void reportNaming( int prefixPadding = 0);
    void reportTable( int prefixPadding = 0);
    csiMemGroupStatus   getStatus(){return status;}

    inline bool     changeStatus(   csiMemGroupStatus before, 
                                    csiMemGroupStatus after);
    int getKeyCount(){return keyCount;}
    int getLocalBufferCount(){return localBufferCount;}
private:
    /* VB(ValueBuffer)에 데이터를 추가할 공간 확보
     * 실패하면 NULL 반환 */
    char    * allocVB( int len );
    bool      allocBuffer( bool retry = false);
    void      releaseAllBuffer();

    /*모든 memTable이 할당한 총 Buffer 개수 */
    static int                    globalBufferCount;
    static int                    globalBufferThreshold;
    static int                    localMaximumKVCount;  /*MemGroup당 한계치 */
    static int                    localBufferThreshold; /*MemGroup당 한계치 */

    csiMemGroupStatus             status;           /*MemGroup의 상태 */
    char                        * lastBufferPtr;    /*삽입 가능한 최신Buffer*/
    csiBufferSeq                  lastBS;           /*마지막Buffer의 SeqNum*/
    csiSlotDir                  * slotDir;          /*마지막Buffer의 slotdir*/
    int                           localBufferCount;

    map<ByteArray, ByteArray>     sortedMap;

    csiSimpleRWLock               mapRWLock;
    int                           keyCount;
};

/************************* internal functions *************************/

inline bool csiMemGroup::allocBuffer( bool retry )
{
    if( globalBufferCount >= globalBufferThreshold )    return false;
    if( localBufferCount >= localBufferThreshold )      return false;

    lastBufferPtr = csiPageManager::getVictimBuffer( retry );
    if( lastBufferPtr == NULL ) return false;

    atomicInc( &globalBufferCount, 1 );
    localBufferCount ++;

    /* MemGroup용 Buffer로 초기화하고, BlockSequence값으로 LinkedList로
     * 할당한 Buffer들을 관리함 */
    csiPageManager::initBufferPage( lastBufferPtr, CSI_PAGE_TYPE_MEMGROUP );
    ((csiPageHeader*)lastBufferPtr)->prevPID = lastBS;
    slotDir = (csiSlotDir*)&(((csiPageHeader*)lastBufferPtr)->slotDir);
    lastBS  = csiPageManager::getSeqByBufPtr( lastBufferPtr );

    return true;
}

inline  void    csiMemGroup::releaseAllBuffer()
{
    char * ptr;

    /* LinkedList를 바탕으로 Buffer들을 pageManager에게 반환함*/
    while( lastBS != NULL_PID )
    {
        ptr = csiPageManager::getBuffer( lastBS );
        lastBS = ((csiPageHeader*)ptr)->prevPID;
        csiPageManager::releaseVictimBuffer( ptr );
        localBufferCount --;
    }

    CSI_ASSERT( localBufferCount == 0 );
    CSI_ASSERT( lastBS == NULL_PID );
    CSI_ASSERT( allocBuffer( true/*retry*/ ) );
}

inline char * csiMemGroup::allocVB( int len )
{
    char * ptr = NULL;

    CSI_ASSERT( lastBufferPtr != NULL );

    ptr = slotDir->allocSlot( len );
    if( ptr == NULL )
    {
        if( !allocBuffer() )    return NULL;
        /* retry */
        ptr = slotDir->allocSlot( len );
        /* 4k보다 크면 또 실패함. 이후 개량해야 함 */
        CSI_ASSERT( ptr != NULL );
    }
    return ptr;
}


/*Scan을 시작함(미리 첫 페이지 read해둠)*/
inline KVIterator csiMemGroup::beginScan(ByteArray * key) 
{
    mapRWLock.RLock();
    if( key->isNull() )
    {
        return sortedMap.begin();
    }
    return sortedMap.find( *key ); 
}

inline bool csiMemGroup::isEndScan( KVIterator * itr ) /*Scan이 끝났는가? */
{
    bool ret = (*itr == sortedMap.end() );

    if( ret == true )
    {
        mapRWLock.release();
    }

    return ret;
}

inline void csiMemGroup::finishScan()
{
    mapRWLock.release();
}

inline bool     csiMemGroup::changeStatus(  csiMemGroupStatus before, 
                                            csiMemGroupStatus after)
{
    return __sync_bool_compare_and_swap( &status, before, after );
}

#endif 
