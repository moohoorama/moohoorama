#ifndef __CSI_STORED_GROUP_H__
#define __CSI_STORED_GROUP_H__

#include <common.h>
#include <csiPageManager.h>

/* Macro function for read/find page function */
#define NULL_NODE_NO -1

#define    DECLARE_BASE_VARIABLE                        \
    csiPageHeader    * header = NULL;                   \
    bool               locked = false;                  \
    int                category = CSI_IO_STAT_NONE;     \
    csiIOStat          tStat;                           \
    csiPageType        requestType;                     \
    csiPageID          curPID = 0;                      \
    char               bufOrg[PAGE_SIZE*2];

#define SET_CATEGORY( new_category ) category = new_category

#define    ACCESS_PAGE( PID, pageType, cache )                                \
  curPID = PID;                                                               \
  requestType = pageType;                                                     \
  if( cache ){                                                                \
      header=(csiPageHeader*)csiPageManager::findOrReadPage(PID,&tStat.read );\
      tStat.find ++;                                                          \
      CSI_DASSERT( locked == false );    locked = true;                       \
  } else {                                                                    \
      char     * buf = (char*)align( (intptr_t)bufOrg, PAGE_SIZE );       \
      TEST( csiIO::readPage( (char*)buf, PID ) );                             \
      header=(csiPageHeader*)buf;                                             \
      tStat.dpath ++;                                                         \
  }                                                                           \
  DTEST( header->type == pageType )

#define RELEASE_PAGE( cache )                           \
    if( cache ){                                        \
        locked = false;                                 \
        csiPageManager::releasePage( (char*)header );   \
    }

#define FINALIZE_PAGE( )                            \
    CSI_ASSERT( locked == false );                  \
    addStat( category, &tStat )

#define EXCEPTION_PAGE( )                                       \
    LOG("Access page error : %d(%d)\n",curPID,requestType );    \
    if( header ) csiPageManager::dumpPage( (char*)header );     \
    if( locked ) csiPageManager::releasePage( (char*)header );

#define READ_LAST_SEQ    (-1)

enum
{
    CSI_POS_RMAP,
    CSI_POS_ROOT,
    CSI_POS_NODE,
    CSI_POS_DATA,
    CSI_POS_MAX
};

typedef struct csiSGCursor{
    void             * targetSGPtr;
    int                subNo;  /* subGroupNumber for nodeMerged SG*/
    csiPos             pos[ CSI_POS_MAX ];
    int                depth;
    int                readCount;
    bool               done;

    void report();
} csiSGCursor;


/* StoredGroup의 Read한 결과 상태 */
typedef enum {
    CSI_STOREDGROUP_SUCCESS,
    CSI_STOREDGROUP_FILTER_OUT,
    CSI_STOREDGROUP_FALSE_POSITIVE,
} csiStoredGroupResult;

class csiStoredGroup
{
public:
    /*********************** Stored group Management **********************/
    static bool init();
    static bool dest();

    static bool add( csiSIInfo    * info, csiFlushResult    * result );
    static bool remove( csiSIInfo * info, csiPageID    RPID );
    static bool disable(csiSIInfo * info, csiPageID    RPID );

    static csiStoredGroup ** find( csiSIInfo * info, csiPageID   RPID );

    static void reportMaster( int fd, int count );
    static int  reloadMaster( int fd, csiSIInfo  * info, int count );
    void storeMaster( int fd );

    /****************************** scan *****************************/
    /* 여러 Iterator 중 가장 큰(또는 작은)값을 선택함 */
    static ByteArray   chooseNodeKeyInBuffer( char * nodePtr, bool min );
    static int chooseKey( csiSGCursor * sgCursor, int count, int depth );

    /* Scan을 시작함 */
    bool initCursor( csiSGCursor     * cursor,
                     int               depth = CSI_POS_DATA,
                     bool              mpr = true,
                     int               subNo = NULL_NODE_NO,
                     ByteArray       * beginKey = NULL );

    bool destCursor( csiSGCursor * cursor );
    bool nextCursor( csiSGCursor * cursor );

    /* node 개수를 바탕으로 key count를 추적함 */
    int estimatedKeyCount( int nodeCount )
    {
        if( nodeCount )
        {
            return ((uint64_t)getKeyCount() * nodeCount)
                / getPageCount( CSI_PAGE_TYPE_NODE );
        }
        else
        {
            return getKeyCount();
        }
    }

    bool    findKeyValue( ByteArray key, ByteArray * val );

    /*************************** group operation *********************/
    bool    tryRangeCompaction( ByteArray key, int NSeq );
    /* beginkey <-> endkey에 해당하는 Node만 제외한체, Root를 다시 쓴다. */
    bool    rootRewrite(    csiPageID          nodeBeginPID,
                            csiPageID          nodeEndPID,
                            csiFlushResult   * newFlushResult );
    /* root를 새것으로 재구성한다. */
    bool    changeRoot(     csiFlushResult   * newFlushResult,
                            int                kvCount );

    /* 특정 Key를 찾기 위한 접근 */
    bool    findFromPage(   csiPageID          PID, 
                            csiPageType        type, 
                            ByteArray          key,
                            bool               exact,
                            csiPos           * pos,
                            int                nodeNo );
    bool    readFromPage(   csiPageID          PID, 
                            csiPageType        type, 
                            int                seq, 
                            csiPos           * pos,
                            int                nodeNo );

    void    drawStoredGroup();
    void    report();
    void    reportTable( int prefixPadding = 0);

    csiStoredGroup * getNext(){ return next; }
    csiFlushResult * getFlushResult(){return &flushResult; }
    int              getNodeMergeLevel(){ return flushResult.nodeMergeLevel;}
    int              getGroupMergeLevel(){return flushResult.groupMergeLevel;}
    int              getKeyCount(){return flushResult.KVCount;}
    int              getRPID(){return flushResult.lastRootPID;}
    int              getPageCount( csiPageType type )
    {return flushResult.pageCount[ type ];}
private:
    /* RPID를 바탕으로 Group을 찾는다.
     * 찾은 storedGroup의 포인터가 반환된다.
     * (포인터의 포인터이다. 주의해야 하며, remove함수를 참조할 것 */
    bool makeRootMap();
    bool makeFilterCache();

    bool    findByKey( ByteArray key, csiPos * pos, int subNo,
                       bool exact = true, int depth = CSI_POS_DATA);

    void    addStat( int category, csiIOStat * tStat );

    bool    equal( csiStoredGroup * sGrp );

    /* RPID가 여럿으로 나뉘어 있을때, 이를 총괄한다.
     * Cassandra의 IndexInterval과 비슷한 역할 */
    char            * rootMapOrg;
    csiSlotDir      * rootMap;

    char            * filterCache[ MERGING_MAX ];
    csiStoredGroup  * next;
    csiSIInfo       * owner;

    /* NAN(NodeAccessNumber)
     * StoredGroup내 해당 node에 대해 Filtering에 의해 접근되었을때,
     * FalsePositive가 발생하면 해당 Slot의 번호를 1 올린다. */
    int                * NANSlot;
    int                  NANSize; 

    csiFlushResult     flushResult;
    csiLookupStat      lookupStat;

    static int                multiPageReadCount;
    static int                useCacheRoot;
    static int                useCacheNode;
    static int                useCacheDpage;
    static int                rangeMergeThreshold;
    static int                rangeMergeSubThreshold;
    static int                rangeMergeMinNodeCount;
    static int                rangeMergeMaxNodeCount;
    static const csiPageType  depthType[ CSI_POS_MAX ];
};

inline void        csiStoredGroup::addStat( int category, csiIOStat * tStat )
{
    if( tStat->find )
    {
        atomicInc( &lookupStat.ioStat[category].find, tStat->find );
        atomicInc( &owner->lookupStat.ioStat[category].find, tStat->find );
    }
    if( tStat->read )
    {
        atomicInc( &lookupStat.ioStat[category].read, tStat->read );
        atomicInc( &owner->lookupStat.ioStat[category].read, tStat->read );
    }
    if( tStat->dpath )
    {
        atomicInc( &lookupStat.ioStat[category].dpath, tStat->dpath );
        atomicInc( &owner->lookupStat.ioStat[category].dpath, tStat->dpath );
    }
}

inline bool        csiStoredGroup::equal( csiStoredGroup * sGrp )
{
    return ( flushResult.lastRootPID == sGrp->flushResult.lastRootPID );
}

#endif 
