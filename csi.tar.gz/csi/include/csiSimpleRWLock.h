#ifndef __CSI_SIMPLE_RWLOCK_H__
#define __CSI_SIMPLE_RWLOCK_H__

#define CSI_SRWL_INIT(l)    (l)->init(__FILE__,__LINE__)
#define CSI_SRWL_INIT_CUSTOM(l,spin,sleep)  (l)->init(__FILE__,__LINE__,spin,sleep)

#include <unistd.h>
#include <assert.h>

class csiSimpleRWLock
{
public:
    static void globalInit();
    static void globalDest();

    void init(const char * codeFile, int codeLine, int spin=0, int sleep = 0);
    void dest();

    bool tryRLock();
    bool tryWLock();

    void RLock();
    void WLock();

    void release();

    bool isWLock(){return (status == -1 );}
    bool isRLock(){return (status > 0 );}
    bool isNoLock(){return (status == 0 );}

    int  getTotalMissCount(){return RMissCount + WMissCount; }
    void report( bool dump_stack = false );

    int  getStatus(){return status;}
    static void reportGlobal();
private:
    void initInternal( int spin, int sleep );
    /* 0            lock 없음
     * 1,2,3,...    read lock(숫자만큼 readlock 잡은 회수)
     * -1           erite lock */
    volatile int      status;
    volatile int      blockRLock;
    int               spinCount;
    int               sleepMsec;
                      
    int               RMissCount;
    int               WMissCount;
    char              codeName[128];
    csiSimpleRWLock * next;
    csiSimpleRWLock * prev;

    static int             globalSpinCount;
    static int             globalSleepMsec;
    static int             missThreshold;

    static csiSimpleRWLock globalLock;
};

inline bool csiSimpleRWLock::tryRLock()
{
    if( blockRLock ) return false;
    int prev = status;
    if( prev < 0 ) return false;

    return __sync_bool_compare_and_swap( &status, prev, prev + 1 );
}

inline bool csiSimpleRWLock::tryWLock()
{
    int prev = status;

    if( prev != 0 ) return false;

    return __sync_bool_compare_and_swap( &status, 0, -1 );
}

inline void csiSimpleRWLock::RLock()
{
    int tryCount = 0;

    while( tryRLock() == false )
    {
        tryCount ++;
        if( tryCount > spinCount )
        {
            usleep( sleepMsec * 1000 );
            (void)__sync_add_and_fetch( &RMissCount, 1 );
            tryCount = 0;
            if( ( RMissCount % missThreshold ) == 0 )
            {
                report( true );
            }
        }
    }
}

inline void csiSimpleRWLock::WLock()
{
    int        tryCount = 0;
    bool    blockRLocked = false;

    while( tryWLock() == false )
    {
        tryCount ++;
        if( tryCount > spinCount )
        {
            usleep( sleepMsec * 1000 );
            (void)__sync_add_and_fetch( &WMissCount, 1 );
            if( ( WMissCount % missThreshold ) == 0 )
            {
                report( true );
            }
            tryCount = 0;
            if( !blockRLocked )
            {
                (void)__sync_add_and_fetch( &blockRLock, 1 );
                blockRLocked = true;
            }
        }
    }
    if( blockRLocked )    (void)__sync_add_and_fetch( &blockRLock, -1 );
    assert( status == -1 );
}

inline void csiSimpleRWLock::release()
{
    __sync_synchronize();
    if( status < 0 )
    {
        status = 0;
    }
    else
    {
        if( status == 0 )
        {
            __sync_synchronize();
        }
        assert( status > 0 );
        (void)__sync_add_and_fetch( &status, -1 );
    }
}


#endif
