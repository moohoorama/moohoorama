#ifndef __CSI_SLOTDIR_H__
#define __CSI_SLOTDIR_H__

#include <common.h>
#include <stdint.h>
#include <csiStructure.h>
#include <csiByteArray.h>

#define NULL_SLOT (-1)
#define CSI_1BLEN_MAX      (250)
#define CSI_2BLEN_MAX      (65536)
#define CSI_2B_HEAD        (251)
#define CSI_4B_HEAD        (252)
#define CSI_SUPPLEMENTAL   (253)
#define CSI_HEAD_MAXLEN    (4)

typedef enum
{
    CSI_SD_NONE,        /* 판단할 수 없음 */
    CSI_SD_SUPER_KA,    /* 내부에 다시 KEY_ARRAY의 SlotDirectory를 갖음 */
    CSI_SD_KEY_PID,     /* RMap, Root용. Key 후 PID가 배치됨. */
    CSI_SD_KEY_ARRAY,   /* Node용. Key들만 쭉 배치되며, beginPID를 통해 PID를 알 수 있음 */
    CSI_SD_KEY_VALUE,   /* Data용. Key/Value 쌍으로 기록됨 */
    CSI_SD_KEY_ONLY,    /* Test용.*/
    CSI_SD_VALUE_ONLY,  /* Test용.*/
    CSI_SD_MAX,         /* Type 개수 */
} csiSlotDirType;

/* SlotDirectory내 위치를 표현하는데 사용됨 */
typedef struct csiPos{
    bool          ret;        /* 탐색한 결과값 */
    int           seq;        /* 현 SlotDirectory내에서의 번호 */
    int           globalSeq;  /* 같은 Level내 전체에서의 번호 */
    int           remainCount;/* 마지막으로 읽은 Key 포함, 더 읽을 slot 수*/
    ByteArray     key;        /* Slot의 Key */
    ByteArray     subKey;     /* KEY_ARRAY일때 다음 Key, KEY_VALUE일때 Value*/
    csiPageID     PID;        /* 소속한 page */
    csiPageID     prevPID;    /* KEY_ARRAY일때, Node걸침때문에 볼 이전 페이지*/

    csiPos()
    {
//        reset();
    }
    
    void reset()
    {
        seq                = 0;
        globalSeq          = -1;
        ret                = false;
        remainCount        = 0;
    }
    void copyPos( csiPos * src )
    {
        ret             = src->ret;
        seq             = src->seq;
        globalSeq       = src->globalSeq;
        remainCount     = src->remainCount;
        PID             = src->PID;
        prevPID         = src->prevPID;
    }
    /* key, subkey 등을 저장하는 ByteArray에 대한 메모리를 할당받는다.
     * 할당이 실패하면, 이후 find 연산등에서 key값등을 read하지않는다.*/
    void allocBA()
    {
        key.alloc( CSI_BA_POOL_SLOT_SCAN );
        subKey.alloc( CSI_BA_POOL_SLOT_SCAN );
    }
    void freeBA()
    {
        key.free();
        subKey.free();
    }
    void report();
} csiPos;

class csiSlotDir
{
public:
    static void        globalInit();

    /* slotDirectory를 초기화함
     * lastPtr은 이 SlotDirectory가 관리할 공간의 마지막 지점*/
    void      init( csiSlotDirType type, char * lastPtr);

    char    * allocSlot( int size, int align = 1);/* Slot을 할당받음 */

    bool      insertK( ByteArray *key );
    bool      insertV( ByteArray *key );
    bool      insertKV( ByteArray *key, ByteArray *val);
    bool      insertKV4Supplemental(ByteArray *key, csiLargeValueRef *lvRef);
    bool      insertKP( ByteArray *key, csiPageID  PID);
    ByteArray insertUtmostV(ByteArray *val, int *ret);

    int       getSlotSize( int idx );                /* slot의 크기를 알아냄 */
    int       getLastSlotSize()
    {
        return getSlotSize( slotCount -1 );
    }
    bool      removeLastSlot();                    /* 마지막 Slot을 지움 */
    int       getUsedSize( int align = 1 );
    int       getFreeSize( int align = 1);        /* 남은 공간 알려줌 */
    bool      isSlotLimit();

    bool      copyFrom(    csiSlotDir * src );
    bool      setPrev(    csiSlotDir * src );
    
    bool      find( ByteArray key, csiPos * pos, bool exact );
    bool      read( int seq, csiPos * pos );
    void      readBA( int seq, ByteArray * ba ) {
        readCompactBA( getPtrBySlot( seq ), ba );
    }

    /* 아래 기능들은, Slot의 head로 CompactBA가 저장되어 있어야 함 */
    /* key를 탐색함.*/
    int       binarySearch( ByteArray key );    
    int       binarySearchInternal( ByteArray key );    
    /* key로 정렬함 */
    bool      sort();

    int       getOffset( char * ptr )
    {    return (intptr_t)(char*)(ptr - (char*)this);}
    char    * getPtr( int offset )
    {    
        DTEST( ( 0 <= offset ) && ( offset < lastOffset ) );

        return ((char*)this) + offset; 
        
        EXCEPTION_END;

        LOG("OFFSET : %d\n",offset );
        dumpStack();
        CSI_ASSERT( false );
    }

    char    * getPtrBySlot( int slot )
    {    return    getPtr( slotDir[slot] ); }
    void      dump(int limitLen = 40 );
    void      dumpKeyOnly( csiPageID beginPID, int limitLen = 40 );
    void      dumpKeyValue(int limitLen = 40 );
    void      dumpKeyPID(int limitLen = 40);

    static int   getCompactBASize( ByteArray * ba );
    static char *readCompactBA( char * ptr, ByteArray * ba );
private:
    /************************* Compact Int ***************************/
    /* 0~253는 1B로, 254-65536은 254+2BLEN, 65536-INTMAX는 255+4B LEN
     * 으로 총 3byte로 기록하여 공간절약 */
    static uchar *dumpCompactBA( uchar * ptr, int limitLen );
    static int    readCompactInt( char * ptr, int * val  );
    static int    getCompactIntLen( int val );
    static char  *writeCompactInt( char * ptr, int val );
    static char  *writeSupplement( char *ptr, int cnt, csiPageID PID);
    static char  *writeSupplement( char *ptr, csiLargeValueRef *lvRef);
    static char  *writeCompactBA( char * ptr, ByteArray * ba );
    static char  *readAndMergeCompactBA( char * ptr, ByteArray * dst );
    static char  *readAndCopyCompactBA( char * ptr, ByteArray * dst );
    static void   readAndCopyValue( uchar *ptr, ByteArray * ba );

public:
    /******************************** Data Structure ******************/
    csiSlotDirType   type;        /* 이 SlotDirectory의 Type */
    int              globalSeq;   /* 누적 Slot Seq */
    csiPageID        prevPID;     /* KeyArray용. 이전 SlotDir의 PID Link*/
    csiPageID        beginPID;    /* KeyArray용. 첫 Slot의 PID */
    ushort           slotCount;
    csiOffset        lastOffset;
    csiOffset        slotDir[0];

    static int       slotLimit[ CSI_SD_MAX ];
    static int       supplementMinPiece;
};

inline int       csiSlotDir::binarySearch( ByteArray key )
{
    int          seq = binarySearchInternal( key );
    ByteArray    BA;

    if( ( 0 <= seq ) && ( seq < slotCount ) )
    {
        (void)readCompactBA(    getPtrBySlot( seq ), &BA );
        if( BA == key )    return seq;
    }

    return -seq-1;
}

inline int       csiSlotDir::binarySearchInternal( ByteArray key )
{
    int          min = 0;
    int          max = slotCount - 1;
    int          mid;
    int          ret;
    ByteArray    midBA;

    while(min <= max)
    {
        mid = (min + max) >> 1;
        (void)readCompactBA(    getPtrBySlot( mid ), &midBA );
        ret = midBA.compare( &key );
        if( ret == 0 )
        {
            return mid;
        }
        if( ret < 0 )
        {
            min = mid+1;
        }
        else
        {
            max = mid-1;
        }

    };

    mid = (min + max) >> 1;
    if( mid < 0 )
    {
//        mid = 0;
    }
    if( mid >= slotCount )
    {
        mid = slotCount -1;
    }

    return mid;
}

/* compactInt로 기록될때의 byte 크기 */
inline int  csiSlotDir::getCompactIntLen( int val )
{
    if( val <= CSI_1BLEN_MAX ) return 1;
    if( val <= CSI_2BLEN_MAX ) return 3;
    return 5;
}

/* compactInt로 기록함 */
inline char *csiSlotDir::writeCompactInt( char * cursorPtr, int val )
{
    uint32_t ulen = (uint32_t)val;

    if( ulen <= CSI_1BLEN_MAX )
    {
        cursorPtr[0] = ulen;
        return cursorPtr + 1;
    }
    if( ulen <= CSI_2BLEN_MAX )
    {
        cursorPtr[0] = CSI_2B_HEAD;
        cursorPtr[1] = ulen & 255;
        cursorPtr[2] = (ulen>>8) & 255;
        return cursorPtr + 3;
    }
    cursorPtr[0] = CSI_4B_HEAD;
    cursorPtr[1] = (ulen>> 0) & 255;
    cursorPtr[2] = (ulen>> 8) & 255;
    cursorPtr[3] = (ulen>>16) & 255;
    cursorPtr[4] = (ulen>>24) & 255;
    return cursorPtr + 5;
}
inline char *csiSlotDir::writeSupplement( char *ptr, csiLargeValueRef *lvRef)
{
    int    i;

    (*ptr) = CSI_SUPPLEMENTAL;
    ptr++;
    csiMemcpy(ptr, lvRef, sizeof(*lvRef));
    ptr += sizeof(*lvRef);
    return ptr;
}

/* compactInt로 읽음 */
inline int csiSlotDir::readCompactInt( char * cursorPtr, int * val  )
{
    /* unsigned로 해야 128 ~ 254의 크기를 제대로 계산*/
    uchar * ptr = (uchar*)cursorPtr;
    switch( ptr[0] )
    {
        case CSI_SUPPLEMENTAL:
            (*val) = ptr[1] | (ptr[2]<<8) | (ptr[3]<<16) |  (ptr[4]<<24) ;
            return 5;
        case CSI_4B_HEAD:
            (*val) = ptr[1] | (ptr[2]<<8) | (ptr[3]<<16) |  (ptr[4]<<24) ;
            return 5;
        case CSI_2B_HEAD:
            (*val) = ptr[1] | (ptr[2]<<8);
            return 3;
        default:
            (*val) = ptr[0];
            return 1;
    }
}

inline int    csiSlotDir::getCompactBASize( ByteArray * ba )
{
    return ba->len + getCompactIntLen( ba->len );
}
inline char * csiSlotDir::writeCompactBA( char * ptr, ByteArray * ba )
{
    ptr= writeCompactInt( ptr, ba->len );
    csiMemcpy( ptr, ba->body, ba->len );
    return ptr + ba->len;
}

inline  char * csiSlotDir::readCompactBA( char * ptr, ByteArray * ba )
{
    /* Data를 읽어 body 변수로 pointing하기 때문에, 
     * 만약 body로 alloc한 버퍼를 pointing하던 중이라면,
     * 할당한 buffer를 읽어버릴 수 있다. */
    CSI_ASSERT( ba->allocSize == 0 );
    ptr += readCompactInt( ptr, (int*)&(ba->len) );
    ba->body = (uchar*)ptr;
    return ptr + ba->len;
}

inline  char * csiSlotDir::readAndCopyCompactBA( char * ptr, ByteArray * dst )
{
    ByteArray  ba;
    char      *ret;

    ret = readCompactBA(ptr, &ba);
    dst->copyFrom( &ba );

    return ret;
}

#endif
