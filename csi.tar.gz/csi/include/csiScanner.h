#ifndef __CSI_SCANNER_H__
#define __CSI_SCANNER_H__

#include <csiUtil.h>
#include <csiInterface.h>
#include <csiConcurrentQueue.h>
#include <csiByteArray.h>
#include <csiManager.h>

#define CSI_SCANNER_NULL        (-1)
#define CSI_SCANNER_PREALLOC    8
#define CSI_SCANNER_CACHE       64
#define CSI_MIN_SG_CNT          512

class csiScanner
{
public:
    static bool init();
    static bool dest();

    static void report();

    static int alloc();
    static csiScanner * get( int seq ){ return &scannerPool[seq]; }
    static void release(int seq );

    bool begin(  ByteArray       aSI, 
                 csiOperation    aOP, 
                 int             aCount,
                 ByteArray       beginKey );
    bool next();
    bool end();
    void dump();

    csiResult * getResult(){ return (csiResult*)result; }

private:
    int                seq;
    csiSIInfo        * si;
    csiOperation       op;
    int                readKVCount;
    int                limitCount;
    int                sgCursorCount;
    bool               doneMemItr[MEMGROUP_MAX];
    KVIterator         memItr[MEMGROUP_MAX];
    csiSGCursor      * sgCursor;
    csiSGCursor        sgCursorPrealloc[ CSI_SCANNER_PREALLOC ] ;
    ByteArray          key[CSI_SCANNER_CACHE];
    ByteArray          value[CSI_SCANNER_CACHE];
    csiResult          result[CSI_SCANNER_CACHE+1];

    static int                     scannerPoolSize;
    static int                     cacheSize;
    static int                     useMPR;
    static csiScanner            * scannerPool;
    static csiConcurrentQueue      poolQueue;
};

#endif 
