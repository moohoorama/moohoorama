#ifndef __CSI_CONCURRENT_QUEUE_H__
#define __CSI_CONCURRENT_QUEUE_H__

#include <csiSimpleRWLock.h>

typedef void* VoidPtr;
typedef unsigned long XINT;

typedef enum
{
    CSI_CQ_PUSHABLE,
    CSI_CQ_PUSHING,
    CSI_CQ_POPABLE,
    CSI_CQ_POPPING,
} csiCQStatus;

class csiConcurrentQueue 
{
public:
    static void globalInit();
    static void globalDest();

    bool init(const char * codeFile, int codeLine, int count );
    void free();

    void push( VoidPtr *ptr );
    bool pop( VoidPtr *ptr  );

    void report();
    int  getTotalMissCount(){return pushMiss+popMiss;}
    int  getFree()
    {
        if( pushPos < popPos )
            return pushPos + count - popPos;
        else
            return pushPos - popPos;
    }
    static void reportGlobal();
private:
    void initInternal( int spin, int sleep );

    int                   count;
    volatile int          popPos;
    volatile int          pushPos;
    volatile csiCQStatus *status;
    VoidPtr              *queue;
    int                   pushMiss;
    int                   popMiss;

    char                  codeName[128];
    csiConcurrentQueue   *next;
    csiConcurrentQueue   *prev;

    static int                sleepMsec;
    static csiSimpleRWLock    globalLock;
    static csiConcurrentQueue globalHead;
};
#endif
