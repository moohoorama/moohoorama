#ifndef __CSI_STRUCTURE_H__
#define __CSI_STRUCTURE_H__

#include <common.h>
#include <string.h>
#include <map>
#include <linkedList.h>
#include <csiUtil.h>


/*************************** 저장구조 ***********************************/

/* - DPage
 * +-----------------------+
 * | PageHeader            |
 * | Type, SlotCount       |
 * +-------+-------+-------+
 * |SlotDir|SlotDir|SlotDir|
 * +-------+-------+-------+
 * |                       |
 * |           +-----------+
 * |           | Key Value |
 * +-----------+-----------+
 * | KeyValue  | Key Value |
 * +-----------+-----------+ 
 *
 * - Node
 * +-----------------------+
 * | PageHeader            |
 * | Type, SlotCount       |
 * +-------+-------+-------+
 * |SlotDir|SlotDir|SlotDir|
 * +-------+-------+-------+
 * |                       |
 * +-----------------------+
 * | KeyArray              |
 * +-----------------------+
 * | KeyArray              |
 * +-----------------------+
 * | KeyArray              |
 * +-----------------------+
 *
 * - KeyArray
 * +-------+---+---+---+---+
 * | DPID  |Key|Key|Key|Key|
 * +-------+---+---+---+---+
 * | KeyArray               |
 * |       +---+---+---+---+
 * | DPID  |Key|Key|Key|Key|
 * +-------+---+---+---+---+
 * | KeyArray               |
 * |       +---+---+---+---+
 * | DPID  |Key|Key|Key|Key|
 * +-------+---+---+---+---+
 */


/* SSD에 저장된 페이지의 상태*/
typedef enum {
    CSI_PAGE_TYPE_NONE,
    CSI_PAGE_TYPE_DPAGE,        /* (K + V) * N */
    CSI_PAGE_TYPE_NODE,         /* KArray */
    CSI_PAGE_TYPE_ROOT,         /* (K + NodePID ) * N */
    CSI_PAGE_TYPE_FILTER,       /* bloomFilter */
    CSI_PAGE_TYPE_SUPPLEMENT,   /* 4k이상 kv를 위한 page. */
    CSI_PAGE_TYPE_FLUSH_MAX,    /* flush/non flush 구분용 타입 */
    CSI_PAGE_TYPE_MEMGROUP,     /* MEMGROUP 임시 저장용 */
    CSI_PAGE_TYPE_WORKAREA,     /* I/O와 상관없이, 작업용 버퍼 사용 */
    CSI_PAGE_TYPE_MAX,
} csiPageType;

typedef int csiPageID;
typedef ushort csiOffset;

typedef struct csiIOStat{
    int read;
    int find;
    int dpath;

    csiIOStat()
    {
        read = find = dpath = 0;
    }
    float getHitRatio()
    {
        if( find == 0 )
            return 0.0f;
        return (find - read) *100.0f / find;
    }
} csiIOStat;

typedef enum
{
    CSI_IO_STAT_MAKE_FILTER_CACHE,
    CSI_IO_STAT_MAKE_ROOT_MAP,
    CSI_IO_STAT_SEARCH_ROOT,
    CSI_IO_STAT_SEARCH_NODE,
    CSI_IO_STAT_SEARCH_DPAGE,
    CSI_IO_STAT_SCAN_ROOT,
    CSI_IO_STAT_SCAN_NODE,
    CSI_IO_STAT_SCAN_DPAGE,
    CSI_IO_STAT_NONE,
    CSI_IO_STAT_MAX
} csiIOStatType;

typedef struct csiLookupStat {
    int               readCount;
    int               filterOutCount;
    int               falsePositiveCount;
    int               overNodeRead;

    csiIOStat         ioStat[ CSI_IO_STAT_MAX ];

    csiLookupStat()
    {
            readCount = 
            filterOutCount = 
            falsePositiveCount = 
            overNodeRead = 0;
    }

    float getReadAmplification()
    {
        int         totalReadPage = 0;
        float       readAmplification=0.0;
        int         j;

        for( j = 0 ; j < CSI_IO_STAT_MAX ; j ++ )
        {
            totalReadPage += ioStat[j].read + ioStat[j].dpath;
        }

        if( readCount == 0 )    
        {
            readAmplification = 0.0;
        }
        else
        {
            readAmplification = totalReadPage*1.0f/readCount;
        }

        return readAmplification;
    }
    float getFalsePositiveRatio()
    {
        int         totalCount;

        totalCount = filterOutCount + readCount + falsePositiveCount;
        if( totalCount == 0 )   return 0.0f;
        return falsePositiveCount*100.0f / totalCount;
    }

    void report( int prefixPadding = 0 )
    {
        const char  title[][9]={
            "MK_FILT",
            "MK_RMAP",
            "SER_ROOT",
            "SER_NODE",
            "SER_DP",
            "SCN_ROOT",
            "SCN_NODE",
            "SCN_DP",
            "NONE"};
        int         i;
        int         j;

        for( i = 0 ; i < prefixPadding ; i ++ ) REPORT(" ");
        REPORT( "filterOut:%-8d readCount:%-8d falsePositive:%-8d overRead:%-8d"
                "readAmpl.:%-6.3f "
                "falseRatio.:%-6.3f\n",
                filterOutCount, readCount, falsePositiveCount, overNodeRead,
                getReadAmplification(),
                getFalsePositiveRatio() );

        for( i = 0 ; i < prefixPadding ; i ++ ) REPORT(" ");
        REPORT("%-8s %8s %8s %8s %8s\n", 
                "TYPE","FIND","READ","DPATH","HIT");

        for( j = 0 ; j < CSI_IO_STAT_MAX ; j ++ )
        {
            for( i = 0 ; i < prefixPadding ; i ++ ) REPORT(" ");
            REPORT("%-8s %8d %8d %8d %8.4f\n",
                    title[ j ], 
                    ioStat[j].find, 
                    ioStat[j].read, 
                    ioStat[j].dpath,
                    ioStat[j].getHitRatio() );
        }
    }
} csiLookupStat;


/* SI를 표현하는 구조체 */
class csiSIInfo {
public:
    char              SIName[NAME_LEN];         /* 이 SI의 이름 */
    void            * storedGroup;              /* 이 SI에 소속된 StoredGroup*/
    void            * memGroup[MEMGROUP_MAX];   /* 이 SI에 소속된 MemGroup */
    int               curMemGroupIdx;           /* 현재 Write대상인 memGroup */
    int               flushMemGroupIdx;         /* Flush할 memGroup */
    csiSimpleRWLock   switchLock;
    csiSimpleRWLock   mergeLock;
    int               keyCount;
    int               unmergedGroupCount;
    int               groupCount;

    int               scanCount;
    int               queryCount;
    int               groupCompactionCount;
    int               rangeCompactionCount;
    int               nodeMergeCount;

    csiLookupStat     lookupStat;

    /* 통계정보 */
    int               flushWaitingCount;
    int               switchByVB;
    int               switchByVC;

    void reportDetail();
    void reportSimple();
    void report( bool detail = false)
    {
        if( detail )
            reportDetail();
        else
            reportSimple();
    }
};

typedef enum
{
    CSI_OP_EQ   = 0,    /* Equal */
    CSI_OP_GTE  = 1,    /* Grater than or Equal*/
    CSI_OP_GT   = 2,    /* Grater than */
    CSI_OP_LTE  = 3,    /* Less than or Equal */
    CSI_OP_LT   = 4     /* Less than */
} csiOperation;

#endif
