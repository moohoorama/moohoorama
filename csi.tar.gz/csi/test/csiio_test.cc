#include <stdio.h>
#include <csiInterface.h>
#include <csiIO.h>

void diff( char * bufSrc, char *bufDst )
{
    int i;

    for( i = 0 ; i < PAGE_SIZE ; i ++ )
    {
        if( bufSrc[i] != bufDst[i] )
        {
            printf("%04x : %02x <-> %02x\n",
                   i,
                   bufSrc[i],
                   bufDst[i] );
        }
    }
}

bool basicIoTest()
{
    char       bufOrg[4096*3];
    char      *buf1 = (char*)align( (uintptr_t)bufOrg, 4096 );
    char      *buf2 = (char*)align( ((uintptr_t)bufOrg)+4096, 4096 );
    csiPageID  PID;
    int        i;

    for( i=0 ; i<4096 ; i++ )
    {
        buf1[i]='!' + ( i % ('~'-'!') );
    }

    csiIO::report();
    *((int*)buf1) = 0x12345678;
    TEST( csiIO::appendPage( buf1, 4096, &PID ) );
    TEST( csiIO::readPage( buf2, PID ) );
    diff( buf1, buf2 );
    csiIO::report();

    *((int*)buf1) = 0x87654321;
    TEST( csiIO::appendPage( buf1, 4096, &PID ) );
    TEST( csiIO::readPage( buf2, PID ) );
    diff( buf1, buf2 );
    csiIO::report();

    return true;

    EXCEPTION_END;

    return false;
}

bool appendPerf( int size, int unit, int count )
{
    char      *bufOrg;
    char      *buf;
    csiPageID  PID;
    uint64_t        startTime;
    uint64_t        endTime;
    uint64_t        durTime;
    int        qps;
    int        i;
    int        j;
    int        pageCount = size / PAGE_SIZE;

    size = align( size, unit );
    TEST( CSI_MALLOC( size + unit, (void**)&bufOrg ) );

    buf = (char*)align( (uintptr_t)bufOrg, unit );

    CSI_ASSERT( ((intptr_t)buf) + size <= ((intptr_t)bufOrg) + size + unit );

    for( i = 0 ; i < size ; i ++ )    buf[i]='!' + ( i % ('~'-'!') );

    csiIO::setLastPID( 0 );

    startTime = get_cur_microseconds();
    for( i = 0 ; i < count ; i ++ )
    {
        for( j = 0 ; j < pageCount ; j ++ ) 
            *((int*)(buf + j *PAGE_SIZE))  = j + i * pageCount;
        TEST( csiIO::appendPage( buf, size, &PID ) );
    }
    endTime = get_cur_microseconds();



    durTime = endTime - startTime;
    qps = ((uint64_t)count * 1000 * 1000) / durTime;
    printf("%16d %16d %16d %16llu\n", 
            qps, qps*size, qps*size/(1024*1024), durTime );

    return true;

    EXCEPTION_END;

    return false;
}

bool readPerf( int size, int unit, int count )
{
    char      *bufOrg;
    char      *buf;
    csiPageID  PID;
    uint64_t        startTime;
    uint64_t        endTime;
    uint64_t        durTime;
    int        qps;
    int        i;
    int        j;

    size = align( size, unit );
    TEST( CSI_MALLOC( size + unit, (void**)&bufOrg ) );

    buf = (char*)align( (uintptr_t)bufOrg, unit );

    CSI_ASSERT( ((uintptr_t)buf)+size <= ((uintptr_t)bufOrg) + size + unit );

    startTime = get_cur_microseconds();
    for( i = 0 ; i < count ; i ++ )
    {
        //PID = i*size/PAGE_SIZE;
        PID = rand() % (size * ( count - 1 )/PAGE_SIZE);
        TEST( csiIO::readBulk( buf, size, PID ) );
        for( j = 0 ; j < ( size / PAGE_SIZE ) ; j ++ )
            CSI_ASSERT( *((int*)(buf + j *PAGE_SIZE))  == j + PID );
    }
    endTime = get_cur_microseconds();

    durTime = endTime - startTime;
    qps = ((uint64_t)count * 1000 * 1000) / durTime;
    printf("%16d %16d %16d %16d %16llu\n", 
            size, qps, qps*size, qps*size/(1024*1024), durTime );

    return true;

    EXCEPTION_END;

    return false;
}

typedef struct{
    int size;
    int unit;
    int count;
    int qps;
    uint64_t durTime;
} Argument;
void * readPerf4Parallel( void * ptr );

bool readPerfParallel( int size, int unit, int count, int parallel )
{
    pthread_t workerDesc[256];
    Argument  arg[256];
    int       i;

    CSI_ASSERT( parallel <= 256 );

    for( i = 0 ; i < parallel ; i ++ )
    {
        arg[i].size  = size;
        arg[i].unit  = unit;
        arg[i].count = count;
        arg[i].qps     = 0;
        arg[i].durTime = 0;
        if( pthread_create( &(workerDesc[ i ]), 
                    NULL,
                    readPerf4Parallel,
                    (void*)&arg[i] ) )
        {
            perror("create thread error ");
            CSI_ASSERT( 0 );
        }
    }
    for( i = 0 ; i < parallel ; i ++ )
    {
        intptr_t status;
        pthread_join( workerDesc[i], (void **)&status );
    }
    int sumQps=0;
    for( i = 0 ; i < parallel ; i ++ )
    {
        sumQps += arg[i].qps;
        printf("%16d %16d %16d %16d %16llu\n", 
                size,
                arg[i].qps, 
                arg[i].qps*size, 
                arg[i].qps*size/(1024*1024), 
                arg[i].durTime );
    }
    printf("%16d %16d %16d %16d <sumation>\n", 
            size,
            sumQps,
            sumQps*size,
            sumQps*size/(1024*1024) );

    printf("================================================================================\n");
    return true;
}
void * readPerf4Parallel( void * ptr )
{
    Argument  *arg = (Argument*)ptr;
    char      *bufOrg;
    char      *buf;
    csiPageID  PID;
    uint64_t        startTime;
    uint64_t        endTime;
    uint64_t        durTime;
    int        qps;
    int        i;
    int        j;
    int        size=arg->size;
    int        unit=arg->unit;
    int        count=arg->count;

    size = align( size, unit );
    CSI_ASSERT( CSI_MALLOC( size + unit, (void**)&bufOrg ) );

    buf = (char*)align( (uintptr_t)bufOrg, unit );

    CSI_ASSERT( ((intptr_t)buf) + size <= ((intptr_t)bufOrg) + size + unit );

    for( i = 0 ; i < size ; i ++ )    buf[i]='!' + ( i % ('~'-'!') );

    startTime = get_cur_microseconds();
    for( i = 0 ; i < count ; i ++ )
    {
        //PID = i*size/PAGE_SIZE;
        PID = rand() % (size * ( count - 1 )/PAGE_SIZE);
        CSI_ASSERT( csiIO::readBulk( buf, size, PID ) );
        for( j = 0 ; j < ( size / PAGE_SIZE ) ; j ++ )
            CSI_ASSERT( *((int*)(buf + j *PAGE_SIZE))  == j + PID );
    }
    endTime = get_cur_microseconds();

    durTime = endTime - startTime;
    qps = ((uint64_t)count * 1000 * 1000) / durTime;
    arg->durTime    = endTime - startTime;
    arg->qps        = qps;

    CSI_FREE( bufOrg );

    return NULL;
}

int main(int argc, char **argv)
{
    int        totalSize = 16384 * 16384  ;
    int        size;
    int        i;
    int        j;

    CSI_ASSERT( csiInit( true /*monitoring*/ )  );
    CSI_ASSERT( basicIoTest() );

    printf("append test:\n");
    printf("%16s %16s %16s %16s %16s\n", 
            "size",
            "QPS",
            "BPS",
            "MPS",
            "microtime" );
    for( i = 1 ; i <= 128 ; i*= 2 )
    {
        size = PAGE_SIZE * i;
        printf("%16d ", size);
        CSI_ASSERT( appendPerf( 
                    size,
                    PAGE_SIZE, /* unit */
                    totalSize / size /* count */ )
                );
    }    

    printf("random read test:\n");
    printf("%16s %16s %16s %16s %16s\n", 
            "size",
            "QPS",
            "BPS",
            "MPS",
            "microtime" );
#ifdef tt
    for( i = 1 ; i <= 2048 ; i*= 2 )
    {
        size = PAGE_SIZE * i;
        CSI_ASSERT( readPerf( 
                    size,
                    PAGE_SIZE, /* unit */
                    totalSize / size /* count */ )
                );
    }
#endif


    printf("read parallel test:\n");
    for( j = 8 ; j <= 32 ; j *= 2 )
    {
        printf("%16s %16s %16s %16s %16s - %d thread\n", 
                "size",
                "QPS",
                "BPS",
                "MPS",
                "microtime",
                j);
//        for( i = 1 ; i <= 1024 ; i*= 2 )
        i = 1;    /* 4096만 한다 */
        {
            size = PAGE_SIZE * i;
            CSI_ASSERT( readPerfParallel(
                        size,
                        PAGE_SIZE, /* unit */
                        totalSize / size, /* count */ 
                        j )
                  );
        }
    }

    CSI_ASSERT( csiDest( false /* immediate */ ) );


    return 0;
}
