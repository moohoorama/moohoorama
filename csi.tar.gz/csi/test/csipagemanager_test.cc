#include <stdio.h>
#include <csiWorkerPool.h>
#include <csiPageManager.h>
#include <csiSimpleRWLock.h>
#include <testutil.h>

#define KVSIZE_MAX      8192

int     keySize     = -1;
int     valSize     = -1;
int     threadCount = -1;
int     loopCount   = -1;

bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "t:l:k:v:";
    int             param_opt;

    threadCount = -1;
    loopCount   = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 't':
            threadCount = atoi( optarg );
            break;
        case 'l':
            loopCount = atoi( optarg );
            break;
        case 'k': 
            keySize = atoi( optarg );
            break;
        case 'v': 
            valSize = atoi( optarg );
            break;
        }
    }

    if( ( threadCount   == -1   ) ||
        ( loopCount     == -1   ) ||
        ( keySize       == -1 ) ||
        ( valSize       == -1 ) )
    {
        printf("csipagemanager_test -t [thread_count] -l [try_count_per_thread] -k [keySize] -v [valSize] \n");
        return false;
    }

    return true;
}




bool readTest()
{
    /*
    csiPageID     rootPID = csiPageManager::getLastRootPID();
    char        * page;
    */
//  page = csiPageManager::findOrReadPage( rootPID );
    
    return true;
}

bool flushTest()
{
    char                Buf[KVSIZE_MAX];
    ByteArray           key;
    ByteArray           val;
    csiFlushResult      flushResult;
    int                 i;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( rand() % ('~' - '!') );

    key.len = keySize;
    val.len = valSize;
    key.body = (uchar*)Buf;
    val.body = (uchar*)Buf;

    csiPageManager::flushLock();
    TEST( csiPageManager::flushBegin() );

    for( i = 0 ; i < loopCount ; i ++ )
    {
        *((int*)Buf) = i;
        TEST( csiPageManager::insertKV( &key, &val ) );
    }

    TEST( csiPageManager::flushEnd("PAGE_MANAGER_TEST", &flushResult) );
    flushResult.report( "csiPageManager flush Test" );
    csiPageManager::flushUnlock();

    csiPageManager::report();

    return true;

    EXCEPTION_END;

    return false;
}

bool test()
{
    TEST( initUtil() );
    TEST( csiWorkerPool::init( false ) );
    TEST( csiIO::init() );
    TEST( csiPageManager::init() );

    TEST( flushTest() );
    TEST( readTest() );

    TEST( csiWorkerPool::stopWorkers( false ) );
    TEST( csiPageManager::dest() );
    TEST( csiIO::dest() );
    TEST( csiWorkerPool::dest() );
    TEST( destUtil() );

    return true;

    EXCEPTION_END;

    return false;
}

int main(int argc, char **argv)
{
    if(readArg( argc, argv ) )
    {
        CSI_ASSERT( test() );
    }

    return 0;
}

