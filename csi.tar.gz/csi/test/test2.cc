#include <linkedList.h>
#include <stdio.h>
#include <csiInterface.h>
#include <testutil.h>

#define KVSIZE_MAX 8192
#define THREAD_MAX 256

int qps[THREAD_MAX];
int keySize = -1;
int valSize = -1;
int queryCount = -1;
int threadCount = -1;

void *insertFunc( void * arg)
{
    char        Buf[KVSIZE_MAX];
    int         num = (intptr_t)arg;
    uint64_t    startTime;
    uint64_t    endTime;
    uint64_t    durTime;
    int         seq;
    int         i;
    bool        ret=true;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( i % ('~' - '!') );

    startTime = get_cur_milliseconds();
    for( i = 0 ; i < queryCount ; i ++ )
    {
        seq=pseudoRand();
        *((int*)Buf) = seq;

        ret&=csiInsert( 4, "test", 
                keySize,Buf,valSize,Buf,
                0 ); /* delInfo*/
        incPerfStat();
    }
    endTime = get_cur_milliseconds();

    durTime = endTime - startTime;
    if( durTime == 0.0 )
    {
        qps[ num ] = 0;
    }
    else
    {
        qps[ num ] = queryCount * 1000 / durTime;
    }
}

void *insertReadFunc( void * arg)
{
    char        Buf[KVSIZE_MAX];
    int         num = (intptr_t)arg;
    int         retLen;
    char        valBuf[KVSIZE_MAX];
    char        * retBuf;
    uint64_t    startTime;
    uint64_t    endTime;
    uint64_t    durTime;
    int         seq;
    int         i;
    bool        ret=true;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( i % ('~' - '!') );

    startTime = get_cur_milliseconds();
    for( i = 0 ; i < queryCount ; i ++ )
    {
        seq=pseudoRand();
        *((int*)Buf) = seq;

        if( num & 1 )
        {
            ret&=csiInsert(4, "test", 
                    keySize,Buf,valSize,Buf,
                    0 ); /* delInfo*/
        }
        else
        {
            retLen = sizeof( valBuf );
            csiRead(4, "test" ,keySize,Buf, &retLen,&retBuf );
            csiReadEnd( retBuf );
        }
        incPerfStat();
    }
    endTime = get_cur_milliseconds();

    durTime = endTime - startTime;
    if( durTime == 0.0 )
    {
        qps[ num ] = 0;
    }
    else
    {
        qps[ num ] = queryCount * 1000 / durTime;
    }
}


bool concurrentInsert()
{
    int i;
    int sum = 0;

    doParallelTest( insertFunc, threadCount );

    for( i = 0 ; i < threadCount ; i ++ )
    {
        printf("%4d : %6d\n", i, qps[i]);
        sum += qps[i];
    }
    printf(BAR_STR"\n");
    printf("%4s : %6d\n", "sum", sum );

    return true;
}

bool concurrentReadAndInsert()
{
    int i;
    int sum = 0;

    doParallelTest( insertReadFunc, threadCount );

    for( i = 0 ; i < threadCount ; i ++ )
    {
        printf("%4d : %6d\n", i, qps[i]);
        sum += qps[i];
    }
    printf(BAR_STR"\n");
    printf("%4s : %6d\n", "sum", sum );

    return true;
}


bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "t:c:k:v:";
    int             param_opt;

    threadCount = -1;
    queryCount   = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 't':
            threadCount = atoi( optarg );
            break;
        case 'c':
            queryCount = atoi( optarg );
            break;
        case 'k': 
            keySize = atoi( optarg );
            break;
        case 'v': 
            valSize = atoi( optarg );
            break;
        }
    }

    if( ( threadCount == -1 ) || 
        ( queryCount == -1 ) ||
        ( keySize == -1 ) ||
        ( valSize == -1 ) )
    {
        printf("test2 -t [thread_count] -c [try_count_per_thread] -k [keySize] -v [valSize] \n");
        return false;
    }

    CSI_ASSERT( keySize <= KVSIZE_MAX );
    CSI_ASSERT( valSize <= KVSIZE_MAX );
    CSI_ASSERT( threadCount < THREAD_MAX );

    return true;
}

int main(int argc, char **argv)
{
    int     totalSize = 16384 * 16384 / 16;
    int     size;
    int     i;
    int     j;

    CSI_ASSERT( readArg( argc, argv ) );

    CSI_ASSERT( csiInit( true /*monitoring*/ )  );
    csiCreate(4, "test"  );
//  CSI_ASSERT( concurrentInsert() );
    CSI_ASSERT( concurrentReadAndInsert() );
    csiForceBlockingFlushAll();
    csiReportAll();
    CSI_ASSERT( csiDest( true /* immediate */ ) );
    csiReportAll();

    return 0;
}
