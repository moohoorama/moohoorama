#include <csiSimpleRWLock.h>
#include <csiUtil.h>
#include <testutil.h>

#define MAX_VALUE       (loopCount*(threadCount/2))

int threadCount = 16;
int loopCount   = 65536;

csiSimpleRWLock lock;
int             value;

bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "t:l:";
    int             param_opt;

    threadCount = -1;
    loopCount   = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 't':
            threadCount = atoi( optarg );
            break;
        case 'l':
            loopCount = atoi( optarg );
            break;
        }
    }

    if( ( threadCount   == -1  ) ||
        ( loopCount     == -1   ) )
    {
        printf("csisimplerwlock_test -t [thread_count] -l [try_count_per_thread]\n");
        return false;
    }

    return true;
}



void * simpleRWLockTest4Parallel( void * ptr )
{
    int num = (intptr_t)ptr;
    int i;

    for( i = 0 ; i < loopCount ; i ++ )
    {
        if( num & 1 )
        {
            lock.WLock();
            value ++;
            lock.release();
        }
        else
        {
            lock.RLock();
            CSI_ASSERT( ( 0 <= value ) && ( value <= MAX_VALUE ) );
            lock.release();
        }
    }

    return NULL;
}

int main(int argc, char **argv)
{
    if(readArg( argc, argv ) )
    {
        CSI_ASSERT( initUtil() );
        value = 0;
        CSI_SRWL_INIT(  &lock );
        doParallelTest( simpleRWLockTest4Parallel, threadCount, false /*qps*/ );
        CSI_ASSERT( value == MAX_VALUE );
        CSI_ASSERT( destUtil() );
    }

    return 0;
}

