#include <stdio.h>
#include <csiStoredGroup.h>
#include <csiWorkerPool.h>
#include <testutil.h>

#define KVSIZE_MAX        1024

void initSIInfo( csiSIInfo * si );
bool readArg( int argc, char ** argv);
void setKey( int idx, char * keyBuf );
void updateKey( int idx, char * keyBuf );
bool readTest( csiSIInfo * si );
bool rangeScanTest( csiSIInfo * si, int begin = -1 , int end = -1 );
bool nodeBoundRangeScanTest( csiSIInfo * si, int begin = -1 , int end = -1 );
bool flushStoredGroupTest();
int main(int argc, char **argv);


int     keySize     = -1;
int     valSize     = -1;
int     loopCount   = -1;
int     interval    = 10;

bool readArg( int argc, char ** argv)
{
    const char optstr[] = "l:k:v:i:";
    int        param_opt;

    loopCount    = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 'l':
            loopCount = atoi( optarg );
            break;
        case 'k': 
            keySize = atoi( optarg );
            break;
        case 'v': 
            valSize = atoi( optarg );
            break;
        case 'i': 
            interval = atoi( optarg );
            break;
        }
    }

    if( ( loopCount == -1    ) ||
        ( keySize   == -1 ) ||
        ( valSize   == -1 ) )
    {
        printf("csistoredgroup_test -l [try_count] -k [keySize] -v [valSize] -i {range_scan_check_interval}\n");
        return false;
    }

    return true;
}

void initSIInfo( csiSIInfo * si )
{
    si->storedGroup         = NULL;
    csiMemset( si->memGroup, 0, sizeof( void* ) * MEMGROUP_MAX );
    si->curMemGroupIdx      = 0;
    si->flushMemGroupIdx    = 0;
    si->keyCount            = 0;
    si->queryCount          = 0;
    si->flushWaitingCount   = 0;
    si->switchByVB          = 0;
    si->switchByVC          = 0;
    CSI_SRWL_INIT( &si->switchLock );
}

void setKey( int idx, char * keyBuf )
{
    int i;
    for( i = 0 ; i < keySize ; i ++ )
        keyBuf[i] = '!' + ( i % ('~' - '!') );
    updateKey( idx, keyBuf );
}

void updateKey( int idx, char * keyBuf )
{
    keyBuf[0] = (idx>>24) & 255;
    keyBuf[1] = (idx>>16) & 255;
    keyBuf[2] = (idx>> 8) & 255;
    keyBuf[3] = (idx>> 0) & 255;
}


bool readTest( csiSIInfo * si )
{
    char              Buf[KVSIZE_MAX];
    char              hexBuf[ HEX_BUFFER_LEN ] ={0};
    ByteArray         key;
    ByteArray         val;
    csiPageID         dataPID[MERGING_MAX];
    csiStoredGroup   *storedGroup;
    int               i;
    int               j;

    key.len = keySize;
    key.body = (uchar*)Buf;

    val.alloc( CSI_BA_POOL_TEST );

    printf("Stored read test...:\n");
    storedGroup = (csiStoredGroup*) si->storedGroup ;
    while( storedGroup != NULL )
    {
        storedGroup->report();
        setKey( i, (char*)Buf );

        for( i = 0 ; i < loopCount ; i ++ )
        {
            updateKey( i, (char*)Buf );
            val.len = 0;
            TEST( storedGroup->findKeyValue( key, &val ) );

            /* key와 val은 length만 같게 하면 동일해야 함*/
            val.len = keySize;
            if( !( key == val ) )
            {
                dump_hex( (char*)key.body, key.len, (char*)hexBuf, HEX_BUFFER_LEN, 
                        false/*detail*/ );
                hexBuf[37]='.';
                hexBuf[38]='.';
                hexBuf[39]='.';
                hexBuf[40]='\0';

                printf("key : %4d|%40s\n", key.len, hexBuf);
                dump_hex( (char*)val.body, val.len, (char*)hexBuf, HEX_BUFFER_LEN, 
                        false/*detail*/ );
                hexBuf[37]='.';
                hexBuf[38]='.';
                hexBuf[39]='.';
                hexBuf[40]='\0';

                printf("val : %4d|%40s\n", val.len, hexBuf);
                val.len = 0;
                TEST( storedGroup->findKeyValue( key, &val ) );
                CSI_ASSERT( false );
            }

            if( ( i % 10000 ) == 0 ) printf("%d...\n",i);
        }
        storedGroup = storedGroup->getNext();
    }
    printf("complete.\n");

    val.free();

    return true;

    EXCEPTION_END;

    return false;
}

bool rangeScanTest( csiSIInfo * si, int begin, int end )
{
    char             Buf[KVSIZE_MAX];
    ByteArray        testKey;
    ByteArray        key[2];
    csiStoredGroup  *storedGroup;
    csiSGCursor      sgCursor;
    int              i;

    testKey.len = keySize;
    testKey.body = (uchar*)Buf;

    if( begin != -1 )
    {
        key[0].alloc( CSI_BA_POOL_TEST );
        CSI_ASSERT( key[0].allocSize >= keySize );
        setKey( begin, (char*)key[0].body );
        key[0].len = keySize;
        i = begin;
    }
    if( end != -1 )
    {
        key[1].alloc( CSI_BA_POOL_TEST );
        CSI_ASSERT( key[1].allocSize >= keySize );
        setKey( end, (char*)key[1].body );
        key[1].len = keySize;
    }


    storedGroup = (csiStoredGroup*) si->storedGroup ;
    while( storedGroup != NULL )
    {
        storedGroup->report();

        key[0].len = key[1].len = 0;
        i = 0;

        storedGroup->initCursor( &sgCursor, CSI_POS_DATA, &key );

        setKey( i, (char*)Buf );
        while( true )
        {
            updateKey( i, (char*)Buf );

            if( sgCursor.done ) break;
            if( ! ( *((int*)sgCursor.pos[ CSI_POS_DATA ].key.body) == 
                   *((int*)testKey.body ) ) )
            {
                sgCursor.report();
                REPORT("TestKey : ");
                testKey.dump();
                CSI_ASSERT( false );
            }
            i++;
            TEST( storedGroup->nextCursor( & sgCursor ) );
        }
        storedGroup->destCursor( & sgCursor );

        storedGroup = storedGroup->getNext();
    }
    if( begin != -1 )
    {
        key[0].free();
    }
    if( end != -1 )
    {
        key[1].free();
    }

    return true;

    EXCEPTION_END;

    return false;
}

bool nodeBoundRangeScanTest( csiSIInfo * si, int begin, int end )
{
    char             Buf[KVSIZE_MAX];
    ByteArray        key[2];
    csiStoredGroup  *storedGroup;
    csiSGCursor      sgCursor;
    ByteArray        endKey;
    bool             printBeginKey = false;
    int              i = 0;


    key[0].len = key[1].len = 0;

    if( begin != -1 )
    {
        key[0].alloc( CSI_BA_POOL_TEST );
        CSI_ASSERT( key[0].allocSize >= keySize );
        setKey( begin, (char*)key[0].body );
        key[0].len = keySize;
    }
    if( end != -1 )
    {
        key[1].alloc( CSI_BA_POOL_TEST );
        CSI_ASSERT( key[1].allocSize >= keySize );
        setKey( end, (char*)key[1].body );
        key[1].len = keySize;
    }

    storedGroup = (csiStoredGroup*) si->storedGroup ;
    while( storedGroup != NULL )
    {
        storedGroup->report();
#if 0
        storedGroup->initScan( &sgItr, true/*mpr*/, &key[0], &key[1], true /*nodeBound*/ );

        if( begin != -1 )
        {
            key[0].free();
        }
        if( end != -1 )
        {
            key[1].free();
        }

        printBeginKey = false;
        do
        {
            TEST( storedGroup->nextKeyValue( & sgItr ) );
            if( !sgItr.doneKV )
            {
                if( ((int*)sgItr.getCurData()->key.isNull() ) )
                {
                    sgItr.report();
                    CSI_ASSERT( false );
                }
                if( !printBeginKey )
                {
                    sgItr.getCurData()->key.print( 40 );
                    printf("\n");
                    printBeginKey = true;
                }
                endKey = sgItr.getCurData()->key;
            }
            else
            {
                endKey.print( 40 );
                printf("\n");
            }
            i ++;
        }
        while( !sgItr.doneKV );
        storedGroup->destScan( & sgItr );
#endif
        storedGroup = storedGroup->getNext();
    }

    return true;

    EXCEPTION_END;

    return false;
}


bool flushStoredGroupTest()
{
    csiSIInfo      si;
    char           Buf[KVSIZE_MAX];
    ByteArray      key;
    ByteArray      val;
    csiFlushResult flushResult;
    int            i;
    int            j;

    initSIInfo( & si );

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( i % ('~' - '!') );

    key.len = keySize;
    val.len = valSize;
    key.body = (uchar*)Buf;
    val.body = (uchar*)Buf;

    si.switchLock.WLock();

    /************************** Flush **********************************/
    csiPageManager::flushLock();
    TEST( csiPageManager::flushBegin() );

    setKey( 0, (char*)Buf );
    for( i = 0 ; i < loopCount ; i ++ )
    {
        updateKey( i, (char*)Buf );
        TEST( csiPageManager::insertKV( &key, &val ) );
    }

    TEST( csiPageManager::flushEnd("STORED_GROUP_TEST_FLUSH", &flushResult) );
    flushResult.report(    "csiPageManager flush Test" );
    csiPageManager::flushUnlock();
    csiPageManager::report();

    /************************** add **********************************/
    TEST( csiStoredGroup::add( &si, &flushResult ) );
    si.switchLock.release();

    /************************** read **********************************/
    TEST( readTest( &si ) );

    printf("Stored range scan test...:\n");
    TEST( rangeScanTest( &si ) );
    printf("complete.\n");
    printf("Stored range scan begin->:\n");
    for( i = 0 ; i < loopCount ; i += interval )
    {
        if( ( i % 1000 ) == 0 ) printf("%d/%d\n",i,loopCount );
        TEST( rangeScanTest( &si, i  ) );    /* begin ---> */
    }
    printf("complete.\n");
    printf("Stored range scan <-end:\n");
    for( i = 0 ; i < loopCount ; i += interval )
    {
        if( ( i % 1000 ) == 0 ) printf("%d/%d\n",i,loopCount );
        TEST( rangeScanTest( &si, -1, i  ) ); /* <-- end  */
    }
    printf("complete.\n");
    printf("Stored range scan begin<->end:\n");
    for( i = 0 ; i < loopCount/2 - 1 ; i += interval )
    {
        if( ( i % 1000 ) == 0 ) printf("%d/%d\n",i,loopCount/2 );
        TEST( rangeScanTest( &si, i,  loopCount - i  ) ); /* begin <--> end */
    }
    printf("complete.\n");

    printf("NodeBound range scan test...:\n");
    for( i = 0 ; i < loopCount/2 - 1 ; i += interval*10 )
    {
        if( ( i % 1000 ) == 0 ) printf("%d/%d\n",i,loopCount/2 );
        TEST( nodeBoundRangeScanTest( &si, i,  loopCount - i  ) ); /* begin <--> end */
    }
    printf("complete.\n");

    return true;

    EXCEPTION_END;

    return false;
}

int main(int argc, char **argv)
{
    if(readArg( argc, argv ) )
    {
        TEST( initUtil() );
        TEST( csiWorkerPool::init( false ) );
        TEST( ByteArray::init() );
        TEST( csiIO::init() );
        TEST( csiPageManager::init() );
        TEST( csiStoredGroup::init() );

        CSI_ASSERT( flushStoredGroupTest() );

        csiWorkerPool::reportAll();

        TEST( csiWorkerPool::stopWorkers( false ) );
        TEST( csiStoredGroup::dest() );
        TEST( csiPageManager::dest() );
        TEST( csiIO::dest() );
        TEST( ByteArray::dest() );
        TEST( csiWorkerPool::dest() );
        TEST( destUtil() );
    }

    return 0;

    EXCEPTION_END;

    return false;
}
