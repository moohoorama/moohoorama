#include <linkedList.h>
#include <stdio.h>
#include <csiInterface.h>
#include <testutil.h>

#define KVSIZE_MAX 65536
#define THREAD_MAX 256

int qps[THREAD_MAX];
int keysize = -1;
int valsize = -1;
int randValSize = 0;
int insertCount = -1;
int readCount = -1;
int threadCount = -1;
int forceFlush = 0;
int forceCompaction = 0;
int forceNodeMerge = 0;

int seed = 0;

int getKey(int & m_z, int & m_w )
{
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;  /* 32-bit result */
}

void *insertFunc( void * arg)
{
    char        Buf[KVSIZE_MAX];
    int         num = (intptr_t)arg;
    uint64_t    startTime;
    uint64_t    endTime;
    uint64_t    durTime;
    int         seq;
    int         i;
    bool        ret=true;
    int         z = num + seed;
    int         w = num + seed;
    int         newValSize;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( i % ('~' - '!') );

    startTime = get_cur_milliseconds();
    for( i = 0 ; i < insertCount ; i ++ )
    {
        seq=getKey( z, w );
        *((int*)Buf) = seq;

        if( randValSize > 0 )
            newValSize = valsize - (seq % randValSize );
        else
            newValSize = valsize;

        ret&=csiInsert( 4, "test", 
                keysize,Buf,newValSize,Buf,
                0 ); /* delInfo*/
        incPerfStat();
    }
    endTime = get_cur_milliseconds();

    durTime = endTime - startTime;
    if( durTime == 0.0 )
    {
        qps[ num ] = 0;
    }
    else
    {
        qps[ num ] = ((uint64_t)insertCount) * 1000 / durTime;
    }
}

void *readFunc( void * arg)
{
    char        Buf[KVSIZE_MAX];
    int         num = (intptr_t)arg;
    int         retLen;
    char        valBuf[KVSIZE_MAX];
    char        * retBuf;
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;
    int         seq;
    int         i;
    bool        ret=true;
    int         z = num + seed;
    int         w = num + seed;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( i % ('~' - '!') );

    startTime = get_cur_milliseconds();
    for( i = 0 ; i < readCount ; i ++ )
    {
        if( ( i % insertCount ) == 0 )
        {
            z = num + seed;
            w = num + seed;
        }
        seq=getKey( z, w );
        *((int*)Buf) = seq;

        retLen = sizeof( valBuf );
        csiRead(4, "test",keysize,Buf, &retLen,&retBuf );
        if( ( retBuf == NULL ) ||
            ( *((int*)retBuf) != seq ) )
        {
            REPORT("Error : %d\n",seq );
            REPORT("Read Error : ");
            REPORT_HEX( Buf, keysize );
            csiRead(4, "test",keysize,Buf, &retLen,&retBuf );
            CSI_ASSERT( false );
        }
        csiReadEnd( retBuf );
        incPerfStat();
    }
    endTime = get_cur_milliseconds();

    durTime = endTime - startTime;
    if( durTime == 0.0 )
    {
        qps[ num ] = 0;
    }
    else
    {
        qps[ num ] = readCount * 1000 / durTime;
    }
}


int  concurrentInsert()
{
    int         i;
    uint64_t            sum1 = 0;
    uint64_t            sum2 = 0;
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;

    startTime = get_cur_milliseconds();
    doParallelTest( insertFunc, threadCount );
    endTime = get_cur_milliseconds();

    for( i = 0 ; i < threadCount ; i ++ )
    {
        printf("%4d : %6d\n", i, qps[i]);
        sum1 += qps[i];
    }
    printf(BAR_STR"\n");
    durTime = endTime - startTime;
    if( durTime == 0.0 )    sum2 = 0;
    else    sum2 =  (uint64_t)insertCount  * threadCount * 1000 / durTime ;

    printf("%4s : %6lld(or %6lld)\n", "insert", sum2, sum1 );

    /* Flush */
    if( forceFlush )
    {
        csiForceBlockingFlushAll();
        endTime = get_cur_milliseconds();

        durTime = endTime - startTime;
        if( durTime == 0.0 )    sum2 = 0;
        else    sum2 =  (uint64_t)insertCount  * threadCount * 1000 / durTime ;
        printf("%4s : %6lld(or %6lld)\n", "flush", sum2, sum1 );
    }

    /* NodeMerge */
    if( forceNodeMerge )
    {
        startTime = get_cur_milliseconds();
        csiForceBlockingNodeMergeAll();
        endTime = get_cur_milliseconds();

        durTime = endTime - startTime;
        if( durTime == 0.0 )    sum2 = 0;
        else    sum2 =  (uint64_t)insertCount  * threadCount * 1000 / durTime ;
        printf("%4s : %6lld(or %6lld)\n", "NodeMerge", sum2, sum1 );
    }


    /* Compaction */
    if( forceCompaction )
    {
        startTime = get_cur_milliseconds();
        csiForceBlockingCompactionAll();
        endTime = get_cur_milliseconds();

        durTime = endTime - startTime;
        if( durTime == 0.0 )    sum2 = 0;
        else    sum2 =  (uint64_t)insertCount  * threadCount * 1000 / durTime ;
        printf("%4s : %6lld(or %6lld) time:%lld\n", "compaction", sum2, sum1,durTime );
    }

    return sum2;
}

int  concurrentRead()
{
    int i;
    uint64_t            sum1 = 0;
    uint64_t            sum2 = 0;
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;

    startTime = get_cur_milliseconds();

    doParallelTest( readFunc, threadCount );
    endTime = get_cur_milliseconds();

    for( i = 0 ; i < threadCount ; i ++ )
    {
        printf("%4d : %6d\n", i, qps[i]);
        sum1 += qps[i];
    }
    printf(BAR_STR"\n");
    durTime = endTime - startTime;
    if( durTime == 0.0 )
    {
        sum2 = 0;
    }
    else
    {
        sum2 = ( (uint64_t)readCount * threadCount * 1000 / durTime );
    }
    printf( "readCount  :%d\n"
            "threadCount:%d\n"
            "durTime    :%lld\n",readCount, threadCount, durTime );

    printf("%4s : %6lld(or %6lld)\n", "read", sum2, sum1 );

    return sum2;
}


bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "t:i:r:k:v:fcna:";
    int             param_opt;

    threadCount = -1;
    insertCount = -1;
    readCount   = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 't':
            threadCount = atoi( optarg );
            break;
        case 'i':
            insertCount = atoi( optarg );
            break;
        case 'r':
            readCount = atoi( optarg );
            break;
        case 'k': 
            keysize = atoi( optarg );
            break;
        case 'v': 
            valsize = atoi( optarg );
            break;
        case 'a':   /*rAnd valSize */
            randValSize = atoi( optarg );
            break;
        case 'f':
            forceFlush = true;
            break;
        case 'n':
            forceNodeMerge = true;
            break;
        case 'c':
            forceCompaction = true;
            break;
        }
    }

    if( ( threadCount == -1 ) || 
        ( insertCount == -1 ) ||
        ( readCount == -1 ) ||
        ( keysize == -1 ) ||
        ( valsize == -1 ) )
    {
        printf("test3 -t [thread_count] -i [inserted_record_count] -r [read_try_count] -k [keysize] -v [valsize] {-f} {-n} {-c}\n");
        return false;
    }

    CSI_ASSERT( keysize <= KVSIZE_MAX );
    CSI_ASSERT( valsize <= KVSIZE_MAX );
    CSI_ASSERT( threadCount < THREAD_MAX );

    return true;
}

int main(int argc, char **argv)
{
    int insertQps = 0;
    int readQps = 0;
    int i;

    CSI_ASSERT( readArg( argc, argv ) );

    for( i = 0 ; i < 1 ; i ++ )
    {
        seed = i + 100;
        CSI_ASSERT( csiInit( true /*monitoring*/ )  );
        if( csiCreate( 4, "test" ) )
        {
            insertQps   = concurrentInsert() ;
            csiReportAll();
            readQps     = concurrentRead();
            csiReportAll();
            CSI_ASSERT( csiDest( true /* immediate */ ) );

            printf("Insert : %10d\n", insertQps );
            printf("Read   : %10d\n", readQps );
        }
        else
        {
            printf("fail\n");
        }
    }

    return 0;
}
