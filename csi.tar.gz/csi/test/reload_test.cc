#include <stdio.h>
#include <csiInterface.h>

#define SI_NAME "data"
#define KVSIZE_MAX 2048

bool printFull()
{
    int         keySize=23;
    char        keyBuf[KVSIZE_MAX];
    int         handle;
    csiResult * ret;
    int         j;
    int         k=0;
    char    buffer[ HEX_BUFFER_LEN ] ={0};

    snprintf( keyBuf, KVSIZE_MAX, "user111344766640651314");
    printf("[ %s ]\n",keyBuf );

    j = 0;
    handle = csiScan( 4, SI_NAME, OP_GTE, 100, keySize, keyBuf );
    while( ( ret = csiScanNext( handle ) )->keyLen > 0 )
    {
        while( ret->keyLen > 0 )
        {
            print_hex( (char*)ret->keyBody, ret->keyLen );
            ret ++;
            j++;
        }
        k++;
    }
    CSI_ASSERT( csiScanEnd( handle ) );

    return true;
}

int main(int argc, char **argv)
{
    char command[65536];
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;
    CSI_ASSERT( csiInit( false /*monitoring*/, true/*signalHandling*/, true/*force std*/ )  );

    csiReload();
    for(;;)
    {
        printf("$>");
        scanf("%s",command);
        startTime = get_cur_milliseconds();
        if( strcmp(command,"scan")== 0 )
        {
            printFull();
        }
        if( strcmp(command,"nodemerge")==0 )
            csiForceBlockingNodeMergeAll();
        if( strcmp(command,"compaction")==0 )
            csiForceBlockingCompactionAll();
        if( strcmp(command,"exit")==0 )
            break;
        if( strcmp(command,"help")==0 )
        {
            printf("scan, nodemerge, compaction, help,exit\n");
        }
        endTime = get_cur_milliseconds();
        durTime = endTime - startTime;
        printf("%f sec\n", durTime/1000.0);
    }
//  csiForceBlockingCompactionAll();

//  csiReportAll();
    CSI_ASSERT( csiDest( true /* immediate */ ) );
//  csiReportAll();

    return 0;
}
