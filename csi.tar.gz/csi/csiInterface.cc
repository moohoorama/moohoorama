#include <csiInterface.h>
#include <csiManager.h>
#include <csiWorkerPool.h>
#include <csiPageManager.h>
#include <csiScanner.h>
#include <csiIO.h>
#include <csiReplayer.h>

extern "C" 
{

/*    CSI 전반적으로 새로 구동함.  */
bool csiInit( bool monitoring, bool signalHandling,bool forceStdout )
{
    csiSimpleRWLock::globalInit();
    csiConcurrentQueue::globalInit();
    TEST( initUtil( signalHandling, forceStdout ) );
    TEST( csiWorkerPool::init( monitoring ) );
    csiWorkerPool::registRF( csiSimpleRWLock::reportGlobal );
    csiWorkerPool::registRF( csiConcurrentQueue::reportGlobal );
    TEST( ByteArray::init() );
    TEST( csiIO::init() );
    TEST( csiPageManager::init() );
    TEST( csiMPRInfo::globalInit() );
    TEST( csiManager::init() );
    TEST( csiScanner::init() );
    LOG("CSI instance begin.");

    csiWorkerPool::registRF( memStatReport );

    initQueryRecording();

    return true;

    EXCEPTION_END;

    return false;
}

void csiReload()
{
    csiManager::reloadMaster();
}

void csiStore()
{
    csiManager::storeMaster();
}

/*  CSI 기능을 종료함 */
bool csiDest( bool immediate )
{
    destQueryRecording();

    if( !immediate )
    {
        TEST( csiManager::forceSwitchAndFlushAll() );
    }
    TEST( csiWorkerPool::stopWorkers( immediate ) );
    TEST( csiScanner::dest() );
    TEST( csiManager::dest() );
    TEST( csiPageManager::dest() );
    TEST( csiIO::dest() );
    TEST( ByteArray::dest() );
    TEST( csiWorkerPool::dest() );
    TEST( destUtil() );
    csiConcurrentQueue::globalDest();
    csiSimpleRWLock::globalDest();

    LOG("CSI End.");
    banner("CSI destroy");

    return true;

    EXCEPTION_END;

    return false;
}

void csiReportAll()
{
    csiWorkerPool::reportAll();
}

/* 새로운 SI 생성 */
bool csiCreate( int SINameLen, const char * SIName )
{
    int seq = -1;
    LOG( "create idx <%s>", SIName );

    TEST( ( seq = csiManager::createSI( SINameLen, (char*)SIName ) ) != -1 );

    return true;

    EXCEPTION_END;

    return false;
}

/* 모든 SI Flush */
bool csiForceBlockingFlushAll()
{
    LOG( "csiForceBlockingFlushAll" );
    return csiManager::forceSwitchAndFlushAll();
}

/* 강제 Flush */
bool csiForceBlockingFlush( int SINameLen, const char * SIName )
{
    LOG( "csiForceBlockingFlush : %s", SIName );
    return csiManager::forceSwitchAndFlush( SINameLen, (char*)SIName );
}

/* 모든 SI Compaction */
bool csiForceBlockingCompactionAll()
{
    LOG( "csiForceBlockingCompactionAll");
    return csiManager::forceCompactionAll();
}

/* 강제 Compaction */
bool csiForceBlockingCompaction( int SINameLen, const char * SIName )
{
    LOG( "csiForceBlockingCompaction : %s", SIName );
    return csiManager::forceCompaction( SINameLen, (char*)SIName );
}

/* 강제 RangeCompaction */
bool csiForceBlockingRangeCompaction( int SINameLen, const char * SIName )
{
    LOG( "csiForceBlockingRangeCompaction : %s", SIName );
    return csiManager::forceRangeCompaction( SINameLen, (char*)SIName );
}


/* 모든 SI NodeMerge */
bool csiForceBlockingNodeMergeAll()
{
    LOG( "csiForceBlockingNodeMergeAll");
    return csiManager::forceNodeMergeAll();
}

/* 강제 NodeMerge */
bool csiForceBlockingNodeMerge( int SINameLen, const char * SIName )
{
    LOG( "csiForceBlockingNodeMerge : %s", SIName );
    return csiManager::forceNodeMerge( SINameLen, (char*)SIName );
}

uint64_t     csiGetSize( int SINameLen, const char * SIName )
{
    uint64_t size = csiManager::getSize(SINameLen, (char*)SIName );

    return size;
}
uint64_t     csiGetMemgroupSize( int SINameLen, const char * SIName )
{
    uint64_t size = csiManager::getMemgroupSize(SINameLen, (char*)SIName );

    return size;
}

/* 데이터 삽입 */
bool csiInsert( int         SINameLen, 
                const char *SIName, 
                int         keyLen,
                char       *keyBody,
                int         valLen,
                char       *valBody,
                int         info ) /* 데이터 삽입 */
{
    (void)writeQuery( (char*)SIName, SINameLen, (char*)keyBody, keyLen, 
                    0/*insert*/, 0, 0 );
    if( skipQuery() )
        return true;

    return csiManager::insertKV( 
            SINameLen,
            SIName,
            keyLen, keyBody,
            valLen,valBody,
            info );
}

/* 데이터 삭제 */
bool csiDelete( int          SINameLen, 
                const char  *SIName, 
                int          keyLen,
                char        *keyBody )
{
    (void)writeQuery(   (char*)SIName, SINameLen, (char*)keyBody, keyLen, 
                    3/*insert*/, 0, 0 );
    if( skipQuery() )
        return true;

    return csiManager::insertKV( 
            SINameLen,
            SIName,
            keyLen, keyBody,
            0, NULL,
            0 );
}


bool     csiRead(   int          SINameLen, 
                    const char  *SIName, 
                    int          keyLen,
                    char        *keyBody,
                    int         *valLen,
                    char       **valBody )    /* 데이터 읽기*/
{
    ByteArray         si;
    ByteArray         key;
    ByteArray         val;
    bool              ret;

    si.len      = SINameLen;
    si.body     = (uchar*)SIName;
    key.len     = keyLen;
    key.body    = (uchar*)keyBody;

    val.alloc( CSI_BA_POOL_READ_RESULT );

    ret= csiManager::readKV( si, key, &val );

    if( ret )
    {
        if( val.len == 0 )
        {
            /* 데이터 없음 */
            *valLen = 0;
            *valBody = NULL;
            val.free();
        }
        else
        {
            *valLen = val.len;
            *valBody = (char*)val.body;
        }
    }
    else
    {
        val.free();
    }

    return ret;
}
bool csiReadEnd( char * value )
{
    if( value ) ByteArray::freeResultBA( value, CSI_BA_POOL_READ_RESULT );

    return true;
}

char *csiGet(int SINameLen, char * SIName, int keyLen, char * keyBody )
{
    int       valLen;
    char    * valBuf;

    (void)csiRead( 
            SINameLen,
            SIName,
            keyLen,
            keyBody,
            &valLen,
            &valBuf );

    return valBuf;
}
bool csiGetEnd( char * value )
{
    return csiReadEnd( value );
}

int         csiScan(int         SINameLen, 
                    const char *SIName, 
                    int         op,
                    int         limit,
                    int         keyLen,
                    char       *keyBody)    /* 데이터 읽기*/
{
    int            seq;
    csiScanner   * scanner;
    ByteArray      si;
    ByteArray      key;

    (void)writeQuery( (char*)SIName, SINameLen, (char*)keyBody, keyLen, 
                2/*scan*/, op, limit );
    if( skipQuery() )
        return CSI_SCANNER_NULL;

    si.len     = SINameLen;
    si.body    = (uchar*)SIName;
    key.len    = keyLen;
    key.body   = (uchar*)keyBody;

    seq        = csiScanner::alloc();
    scanner    = csiScanner::get( seq );

    TEST( scanner->begin( si, (csiOperation)op, limit, key ) );

    return seq;

    EXCEPTION_END;

    return CSI_SCANNER_NULL;
}

csiResult * csiScanNext( int handle )
{
    csiScanner       *scanner;
    csiResult        *result;
    bool              remain;

    if( skipQuery() )
    {
        return NULL;
    }
    scanner    = csiScanner::get( handle );

    remain = scanner->next();

    return scanner->getResult();
}

void csiScanDump( int handle )
{
    csiScanner        * scanner;

    scanner    = csiScanner::get( handle );

    scanner->dump();
}

bool csiScanEnd( int handle )
{
    if( skipQuery() )
    {
        return true;
    }

    csiScanner    * scanner;

    scanner    = csiScanner::get( handle );

    return scanner->end();
}

void csiReplay()
{
    replayQuery();
}

void *GET(int SINameLen, char * SIName, char* InStream)
{
    int      offset = 0;
    short    key_len;
    char    *key_ptr;
    int      valLen;
    char    *valBuf;

    key_len = *(short*)InStream;
    offset += 2;

    key_ptr = (char*)InStream + offset;
    offset += key_len;

    /*
    val_ptr    = (char*)InStream + offset;

    column_count = *(short*)(InStream+offset);
    offset += 2;
    for(i=0; i<column_count; i++)
    {
        column_name_len = *(short*)(InStream+offset);
        offset +=2;
        // column_name_ptr = ptr + offset
        offset += column_name_len;
    }
    val_len = (int)(((char*)InStream + offset) - val_ptr);
    */
//    valBuf    = allocValBuffer();
    valLen = 2048;

    (void)csiRead( 
            SINameLen,
            SIName,
            key_len,
            key_ptr,
            &valLen,
            &valBuf );

    //(void)csiForceBlockingFlush( name );

    return valBuf;
//    (*OutStream) = (char*)valBuf;
#ifdef __DEBUG__
    REPORT("GET!!! name %8s  key %10d, val %10d\n ", name, key_len , valLen );
    REPORT_HEX(    (char*)key_ptr,key_len );
    REPORT_HEX(    (char*)valBuf,valLen );
#endif

//    return 0;

    /*
    short key_len = *(short*)InStream;
    REPORT("key_len = %d\n", key_len);
    offset +=2;

    REPORT("key = %s\n", InStream + offset);
    offset += key_len;

    short column_count = *(short*)(InStream+offset);
    REPORT("column count = %d\n", column_count);
    offset += 2;

    for(int i=0; i<column_count; i++)
    {
        short name_len = *(short*)(InStream+offset);
        offset +=2;
        REPORT("name len = %d name = %s\n", name_len, InStream+offset);
        offset += name_len;
    }
    */
}
void GET_callback( char *outstream )
{
    csiReadEnd( (char*)outstream );
}
//2 byte key_len
//x byte key
//2 byte number of column
//2 byte column name length        |
//x byte column name                | xN
//4 byte column value length    |
//x byte column value            |

int PUT(int SINameLen, char * SIName, char* ptr)
{
    int      offset = 0;
    short    key_len;
    char    *key_ptr;
    short    val_len;
    char    *val_ptr;
    short    column_count;
    short    column_name_len;
    int      column_value_len;
    int      i;

    key_len = *(short*)ptr;
    offset += 2;

    key_ptr = (char*)ptr + offset;
    offset += key_len;

    val_ptr    = (char*)ptr + offset;

    column_count = *(short*)(ptr+offset);
    offset += 2;
    for(i=0; i<column_count; i++)
    {
        column_name_len = *(short*)(ptr+offset);
        offset +=2;
        /* column_name_ptr = ptr + offset */
        offset += column_name_len;

        column_value_len = *(int*)(ptr+offset);
        offset += 4;
        /* column_value_ptr = ptr + offset */
        offset += column_value_len;
    }
    val_len = (int)(((char*)ptr + offset) - val_ptr);

#ifdef __DEBUG__
    REPORT("PUT!!! name %8s  key %10d, val %10d\n ", name, key_len , offset );
    REPORT_HEX(    (char*)key_ptr, key_len );
    REPORT_HEX(    (char*)val_ptr, val_len );
#endif

    return csiInsert( 
            SINameLen,
            (const char*)SIName,
            key_len,
            key_ptr,
            val_len,
            val_ptr,
            0 /* delete info */ );

//    return 0;
}

}




