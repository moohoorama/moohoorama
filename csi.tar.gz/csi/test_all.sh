./stress_test.sh > /dev/null
./module_test.sh > module.test

diff module.ret module.test
