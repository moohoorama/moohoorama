#include <stdio.h>
#include <unistd.h>
#include <csiInterface.h>
#include <csiIO.h>
#include <csiPageManager.h>
#include <csiManager.h>

void dumpMaster()
{
    csiManager::reportMaster();
}



void dump( csiPageID PID )
{
    char          bufOrg[PAGE_SIZE*2];
    char        * buf = (char*)align( (uintptr_t)bufOrg, PAGE_SIZE );

    printf("PID : %d\n", PID );
    CSI_ASSERT( csiIO::readPage( (char*)buf, PID ) );
    print_hex( buf, PAGE_SIZE );
    csiPageManager::dumpPage( buf );
}

void dumpAll()
{
    char              bufOrg[PAGE_SIZE*2];
    char            * buf = (char*)align( (uintptr_t)bufOrg, PAGE_SIZE );
    int               lastPID = csiIO::estimatedAppendPID();
    csiPageHeader   * header;
    int               i;

    printf("size : %lld\n", csiIO::getLastOffset() );
    printf("%8s %8s %8s %16s %8s %8s\n"
            BAR_STR"\n",
            "PID",
            "TYPE",
            "PREV_PID",
            "SIBL_SEQ",
            "LAST_OFF",
            "SLOT_CNT" );
    for( i = 0 ; i < lastPID ; i ++ )
    {
        CSI_ASSERT( csiIO::readPage( (char*)buf, i ) );
        header = (csiPageHeader*)buf;
        printf("%8d %8s %8d %16d %8d %8d %8d\n",
               i,
               csiPageManager::getPageTypeName(header->type),
               header->prevPID,
               header->siblingSeq,
               header->slotDir.lastOffset,
               header->slotDir.slotCount,
               header->slotDir.getFreeSize() );
    }
}

int run(int argc, char **argv)
{
    const char      optstr[] = "mp:";
    int             param_opt;
    csiPageID       PID = -1;
    int             master = false;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 'm':
            master = true;
            break;
        case 'p': /* pageid */
            PID = atoi( optarg );
            break;
        }
    }

    CSI_ASSERT( csiInit( false /*monitoring*/, true/*signalHandling*/, true/*force std*/ )  );
    if( master )
    {
        dumpMaster();
    }
    if( PID != -1 )
    {
        dump( PID );
    }
    if( (! master ) && ( PID == -1 ) )
    {
        csiReload();
        dumpAll();
        printf("dumpcsi {-m} -p [PID]\n");
    }
    CSI_ASSERT( csiDest( false /* immediate */ ) );

    return true;
}

int main(int argc, char **argv)
{
    CSI_ASSERT( run( argc, argv ) );

    return 0;
}
