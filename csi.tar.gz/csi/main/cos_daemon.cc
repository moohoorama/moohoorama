

/* Original code : thrift/gen-cpp/COSThrift_server.skeleton.cpp */

#include <COSThrift.h>
#include <protocol/TBinaryProtocol.h>
#include <server/TThreadPoolServer.h>
#include <transport/TServerSocket.h>
#include <transport/TBufferTransports.h>
#include <concurrency/ThreadManager.h>
#include <concurrency/PosixThreadFactory.h>

#include <csiInterface.h>

using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;
using namespace ::apache::thrift::server;
using namespace ::apache::thrift::concurrency;

using namespace cosThrift;

class COSThriftHandler : virtual public COSThriftIf {
    public:
        COSThriftHandler() {
            // Your initialization goes here
        }

        void ping() {
            // Your implementation goes here
            printf("ping\n");
        }

        bool init(const bool monitoring, const bool signalHandling, const bool forceStdout) {
            // Your implementation goes here
            printf("init\n");
            return csiInit( monitoring, signalHandling, forceStdout );
        }

        bool reload() {
            // Your implementation goes here
            csiReload();
            printf("reload\n");
            return true;
        }

        bool dest(const bool immedate) {
            // Your implementation goes here
            printf("dest\n");
        }

        bool createSI(const std::string& SIName) {
            // Your implementation goes here
            printf("createSI\n");
            return csiCreate( SIName.size(), SIName.c_str() );
        }

        bool flush() {
            // Your implementation goes here
            printf("flush\n");
            csiForceBlockingFlushAll();
            printf("end\n");
        }

        bool nodemerge() {
            // Your implementation goes here
            printf("nodemerge\n");
            csiForceBlockingNodeMergeAll();
            printf("end\n");
        }

        bool compaction() {
            // Your implementation goes here
            printf("compaction\n");
            csiForceBlockingCompactionAll();
            printf("end\n");
        }

        bool put(const std::string& SIName, const std::string& key, const std::string& value) {
            // Your implementation goes here
            return csiInsert(
                    SIName.size(), SIName.c_str(), 
                    key.size(), (char*)key.c_str(),
                    value.size(), (char*)value.c_str(),
                    0);
        }

        void get(std::string& _return, const std::string& SIName, const std::string& key) {
            int           valLen;
            char        * valBuf;
            if( csiRead(
                        SIName.size(), SIName.c_str(), 
                        key.size(), (char*)key.c_str(),
                        &valLen,&valBuf ) )
            {
                _return += std::string( valBuf, valLen );
                if( valLen )
                {
                    csiReadEnd( valBuf );
                }
            }
        }

};


int main(int argc, char **argv) {
    int port = 9090;
    boost::shared_ptr<COSThriftHandler> handler(new COSThriftHandler());
    boost::shared_ptr<TProcessor> processor(new COSThriftProcessor(handler));
    boost::shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));
    boost::shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());
    boost::shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

    boost::shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(20); // Doesn't work with 1
    boost::shared_ptr<PosixThreadFactory> threadFactory(new PosixThreadFactory());
    threadManager->threadFactory(threadFactory);
    threadManager->start();
    TThreadPoolServer server(processor, serverTransport, transportFactory, protocolFactory, threadManager);

    printf("Start daemon...\n");
    server.serve();
    return 0;
}

