#include <csiUtil.h>
#include <csiMemGroup.h>
#include <map>

int csiMemGroup::globalBufferThreshold;
int csiMemGroup::globalBufferCount;
int csiMemGroup::localBufferThreshold;
int csiMemGroup::localMaximumKVCount;

bool csiMemGroup::init()
{
    /* property 읽어서 설정함. */
    globalBufferThreshold = 
        get_property_int("memgroup","global_buffer_threshold");
    localBufferThreshold = 
        get_property_int("memgroup","local_buffer_threshold");
    localMaximumKVCount = 
        get_property_int("memgroup","local_maximum_kvcount");
    globalBufferCount    = 0;

    /* 4 이하의 이상한 값일 경우, 적당하게 알아서 설정해줌 */
    if( globalBufferThreshold < 4 )
    {
        globalBufferThreshold = csiPageManager::getBufferSize()/2/PAGE_SIZE;
    }
    if( localBufferThreshold < 4 )
    {
        localBufferThreshold =globalBufferThreshold/2;
    }

    /* memGroup용 buffer로 pageManager의 buffer를 절반 이상 사용하면 안됨.
     * Flush시, Buffer가 부족해서 Flush가 느려질 수 있음  */
    CSI_ASSERT( globalBufferThreshold * PAGE_SIZE
            <= csiPageManager::getBufferSize()/2 );

    return true;
}

bool csiMemGroup::dest()
{
    return true;
}

/* MemGroup을 새로 생성함. seq를 반환함 */
csiMemGroup    * csiMemGroup::create()
{
    csiMemGroup    * newMemGroup = NULL;
    int              state = 0 ;

    TEST( CSI_MALLOC( sizeof( csiMemGroup ), (void**)(&newMemGroup) ) );
    state = 1;

    newMemGroup->lastBufferPtr    = NULL;
    newMemGroup->lastBS           = NULL_PID;
    newMemGroup->localBufferCount = 0;
    newMemGroup->keyCount         = 0;
    newMemGroup->status           = CSI_MEMGROUP_STATUS_ACTIVE;
    CSI_SRWL_INIT( &newMemGroup->mapRWLock );
    new (&(newMemGroup->sortedMap)) map<ByteArray, ByteArray>();
    state = 2;
    
    TEST( newMemGroup->allocBuffer() );
    state = 3;
    
    return newMemGroup;

    EXCEPTION_END;

    switch( state )
    {
        case 3:
            newMemGroup->releaseAllBuffer();
        case 2:
            (newMemGroup->sortedMap).~map<ByteArray, ByteArray>();
        case 1:
            CSI_ASSERT( CSI_FREE( newMemGroup ) );
        default:
            break;
    }

    return NULL;
}
void csiMemGroup::drop( csiMemGroup * memGroup )
{
    if( memGroup )
    {
        (memGroup->sortedMap).~map<ByteArray, ByteArray>();
        memGroup->releaseAllBuffer();
        memGroup->mapRWLock.dest();
        CSI_ASSERT( CSI_FREE( memGroup ) );
    }
}

/* MemGroup을 깨긋히 비움 */
void csiMemGroup::clear()
{
    mapRWLock.WLock();
    atomicInc( &globalBufferCount, -localBufferCount );

    releaseAllBuffer();

    sortedMap.clear();
    keyCount = 0;
    mapRWLock.release();
}
/*삽입하면서 동시에 정렬함*/
bool csiMemGroup::insertAndSort( ByteArray          key,
                                 ByteArray          value,
                                 uint               info,
                                 csiMemGroupResult *result )
{
    char             *VBPtr;
    int               addingCount = 0;
    int               pos;
    csiLargeValueRef  lvRef;
    ByteArray         target;
    KVIterator        itr;
    ByteArray         _key;
    ByteArray         _value;
    ByteArray         _ba;
    int32_t           slotIdx;

    mapRWLock.WLock();
    /* 중복 체크 */
    itr = sortedMap.find( key );
    if( itr == sortedMap.end() ) 
    {    /* 중복 없음 */
        addingCount = 1;
        target = value;
    }
    else
    {    /* 중복됨 */
        target.alloc( CSI_BA_POOL_MEMGROUP );
        readInternal( itr, &target );
        TEST( target.merge( &value ) );
    }

    /* KeyValue 개수가 너무 많으면, sort시 느려짐.
     * (compare 성능은 O(log N). 갯수를 적당히 제약*/
    (*result) = CSI_MEMGROUP_FAIL_OVERFLOW_VC;
    if( ( keyCount < localMaximumKVCount ) &&
        ( status == CSI_MEMGROUP_STATUS_ACTIVE ) )
    {
        if( target.isLargeValue() )
        {
            lvRef.count = 0;
            _ba=target;
            do {
                _ba = slotDir->insertUtmostV(&_ba, &slotIdx);
                if (slotIdx != -1) {
                    lvRef.count ++;
                    if(lvRef.count == 1 ) lvRef.slot_idx = slotIdx;
                } else {
                    if( !allocBuffer() ){
                        (*result) = CSI_MEMGROUP_FAIL_OVERFLOW_VB;
                        mapRWLock.release();
                        target.free();
                        return true;
                    }
                }
            } while( _ba.len > 0 );
            _ba.len  = sizeof(lvRef);
            lvRef.page_info = lastBS;
            _ba.body = (uchar*)&lvRef;

            while( !slotDir->insertKV( &key, &_ba ) )
            {
                if( !allocBuffer() ){
                    (*result) = CSI_MEMGROUP_FAIL_OVERFLOW_VB;
                    mapRWLock.release();
                    target.free();
                    return true;
                }
            }
            VBPtr=slotDir->getPtrBySlot( slotDir->slotCount-1 );
            VBPtr=slotDir->readCompactBA( VBPtr, &_key );
            VBPtr=slotDir->readCompactBA( VBPtr, &_value );
            _value.len=CSI_BA_SUPPLEMENTAL_LEN;
        }
        else
        {
            while( !slotDir->insertKV( &key, &target ) )
            {
                if( !allocBuffer() ){
                    (*result) = CSI_MEMGROUP_FAIL_OVERFLOW_VB;
                    mapRWLock.release();
                    target.free();
                    return true;
                }
            }
            VBPtr=slotDir->getPtrBySlot( slotDir->slotCount-1 );
            VBPtr=slotDir->readCompactBA( VBPtr, &_key );
            VBPtr=slotDir->readCompactBA( VBPtr, &_value );
        }
        keyCount += addingCount;
        sortedMap[_key]=_value;
        mapRWLock.release();
        target.free();

        (*result) = CSI_MEMGROUP_SUCCESS;
        CSI_ASSERT( target.allocSize == 0 );
        return true;
    }
    mapRWLock.release();
    target.free();

    /* overflow */
    CSI_ASSERT( target.allocSize == 0 );

    return true;

    EXCEPTION_END;

    mapRWLock.release();
    target.free();

    return false;
}

bool csiMemGroup::read(    ByteArray      key, ByteArray * val )
{
    ByteArray     ret;

    mapRWLock.RLock();
    KVIterator itr = sortedMap.find( key );
    mapRWLock.release();
    if( itr == sortedMap.end() ) return true;

    ret.alloc( CSI_BA_POOL_MEMGROUP );
    readInternal( itr, &ret );
    TEST( val->merge( &ret ) );
    ret.free();

    return true;

    EXCEPTION_END;

    return false;
}
void csiMemGroup::readInternal( KVIterator itr, ByteArray *val )
{
    csiLargeValueRef   lvRef;
    ByteArray         *ret;
    int                i;
    csiPageHeader     *header;
    ByteArray          _ba;
    ByteArray          buf;

    ret = &(itr->second);
    if( ret->len == CSI_BA_SUPPLEMENTAL_LEN )
    {
        csiMemcpy( &lvRef, ret->body, sizeof(lvRef) );
        val->len=0;
        for( i=0; i<lvRef.count; i++ ){
            header=(csiPageHeader*)csiPageManager::getBuffer(lvRef.page_info);
            if(lvRef.count-1 == i ){
                header->slotDir.readBA(lvRef.slot_idx, &_ba );
            } else {
                header->slotDir.readBA( 0, &_ba );
            }
            val->append( &_ba );
            lvRef.page_info = header->prevPID;
        }
    }
    else
    {
        val->copyFrom( ret );
    }

}
void csiMemGroup::report()
{
    reportNaming();
    reportTable();
}
void csiMemGroup::reportNaming( int prefixPadding )
{
    int i;
    for( i = 0 ; i < prefixPadding ; i ++ )    REPORT(" ");
    REPORT( "%6s %30s %3s\n",
            "LastBS",
            "Used",
            "keyCnt",
            "status" );
}
void csiMemGroup::reportTable( int prefixPadding )
{
    const char    statusName[][7]={"ACTIVE","FLUSH"};
    int           i;

    for( i = 0 ; i < prefixPadding ; i ++ )    REPORT(" ");

    if( status < CSI_MEMGROUP_STATUS_MAX )
    {
        REPORT( "%6d %4d/%4d(%7dMB/%7dMB) %7d %6s mapLock=>",
                lastBS,
                localBufferCount,
                localBufferThreshold,
                localBufferCount*PAGE_SIZE/1024/1024,
                localBufferThreshold*PAGE_SIZE/1024/1024,
                keyCount,
                statusName[status] );
        mapRWLock.report();
        REPORT(    "\n" );
    }
    else
    {
        REPORT( "%6d %4d/%4d(%7dMB/%7dMB) %7d %6d mapLock=>",
                lastBS,
                localBufferCount,
                localBufferThreshold,
                localBufferCount*PAGE_SIZE/1024/1024,
                localBufferThreshold*PAGE_SIZE/1024/1024,
                keyCount,
                status );
        mapRWLock.report();
        REPORT(    "\n" );
    }
}

