#include <csiIO.h>
#include <csiWorkerPool.h>
#include <csiUtil.h>

string            csiIO::target;
int               csiIO::fd = 0;
int               csiIO::printReadPID = 0;
int               csiIO::printWritePID = 0;
int               csiIO::readCount=0;
int               csiIO::writeCount=0;
csiPageID         csiIO::lastPID    = 0;

bool csiIO::init()
{
    int directIO;

    target          = get_property_string("io","target");
    directIO        = get_property_int("io","direct_io");
    printReadPID    = get_property_int("io","print_read_pid");
    printWritePID   = get_property_int("io","print_write_pid");

    if( directIO )
    {
        printf("enable O_DIRECT\n");
        fd=open(    target.c_str(), 
                O_RDWR | O_CREAT | O_DIRECT | O_LARGEFILE,
                644 );
    }
    else
    {
        fd=open(    target.c_str(), 
                O_RDWR | O_CREAT | O_LARGEFILE,
                644 );
    }
    if( fd == -1 )
    {
        perror("file open error:");
        CSI_ASSERT( fd != -1 );
    }

    setLastPID( 0 );
    csiWorkerPool::registRF( csiIO::report );

    return true;
}

bool csiIO::dest()
{
    close( fd );

    return true;
}

/*데이터를 기록함*/
bool csiIO::appendPage( char * data, int size, csiPageID * retPID )
{
    struct iovec iov;

    iov.iov_base    = data;
    iov.iov_len     = size;

    return appendPages( &iov, 1, retPID );
}

/*데이터를 여럿 기록함*/
bool csiIO::appendPages( struct iovec * iov, int iovCnt, csiPageID * beginPID )
{
    ssize_t writeSize;
    int     totalSize = 0;
    int     i;

    for( i = 0 ; i < iovCnt ; i ++ )    totalSize += iov[i].iov_len;

    if( printWritePID )
    {
        LOG("print_write_pid %d ~ %d", lastPID, lastPID + iovCnt );
    }

    atomicInc( &writeCount, 1 );

    writeSize = writev( fd, iov, iovCnt  );
    TEST( writeSize == totalSize );
    (*beginPID) = lastPID;
    lastPID     += writeSize / PAGE_SIZE;

    return true;

    EXCEPTION_END;

    LOG( "appendPage error : request(%d) <=> write(%d)", iovCnt*PAGE_SIZE, writeSize );
    perror("appenderror:");

    return false;
}


bool csiIO::readBulk( char * buffer, int size, csiPageID PID)
{
    int     readSize;

    TEST( ( readSize = pread64( fd, buffer, size, ((off64_t)PID) * PAGE_SIZE ) ) 
            == size );

    if( printReadPID )
    {
        LOG("print_read_pid %d",PID);
    }
    atomicInc( &readCount, 1 );

    return true;

    EXCEPTION_END;

    LOG( "readPage error : request(%d) <=> read(%d)", size, readSize );
    perror("read error:");

    return false;
}


bool csiIO::readPage( char * buffer, csiPageID PID)
{
    return readBulk( buffer, PAGE_SIZE, PID );
}

bool csiIO::readMultiPage( char ** buffers, csiPageID PID, int pageCount)
{
    int             readSize;
    struct iovec    iov[ MULTI_PAGE_READ_MAX ];
    int             i;

    for( i = 0 ; i < pageCount ; i ++ )
    {
        iov[i].iov_base = buffers[i];
        iov[i].iov_len  = PAGE_SIZE;
    }

    if( printReadPID )
    {
        LOG("print_read_pid %d",PID);
    }
    atomicInc( &readCount, 1 );

    TEST( ( readSize = preadv64( fd, iov, pageCount, ((off64_t)PID) * PAGE_SIZE ) ) ==
            PAGE_SIZE * pageCount );

    return true;

    EXCEPTION_END;

    LOG( "readMultiPage error : request(%d) <=> read(%d)", 
            pageCount*PAGE_SIZE, readSize );
    perror("read error:");

    return false;
}




void csiIO::report()
{
    static int       prevReadCount=0;
    static int       prevWriteCount=0;
    static uint64_t  prevTime = 0;
    uint64_t         curTime = 0;
    int              curReadCount;
    int              curWriteCount;
    int              recentTime = 0;
    tm              *cur_tm;
    timeval          tv;

//  banner( "csiIO" );
//  REPORT( "%s fd:%d lastPID:%d\n",target.c_str(),fd,lastPID );

    curTime = get_cur_milliseconds();
    recentTime = curTime - prevTime;
    curReadCount    = readCount;
    curWriteCount   = writeCount;
    if( recentTime )
    {

        gettimeofday( &tv, NULL );
        cur_tm = localtime(&tv.tv_sec );
        printf( "[%02d:%02d:%02d]",
                cur_tm->tm_hour,
                cur_tm->tm_min,
                cur_tm->tm_sec );
        printf( " R %10d/%7d(%6d IOPS)     ",
                curReadCount,
                curReadCount-prevReadCount,
                (curReadCount-prevReadCount)*1000/recentTime );
        printf( "W %10d/%7d(%6d IOPS)\n",
                curWriteCount,
                curWriteCount-prevWriteCount,
                (curWriteCount-prevWriteCount)*1000/recentTime
              );
        prevReadCount = curReadCount;
        prevWriteCount = curWriteCount;
        prevTime = curTime;
    }

}

void csiIO::dump( csiPageID PID )
{
    char          bufOrg[PAGE_SIZE*2];
    char        * buf = (char*)align( (uintptr_t)bufOrg, PAGE_SIZE );

    CSI_ASSERT( readPage( (char*)buf, PID ) );
    REPORT_HEX( buf, PAGE_SIZE );
}

