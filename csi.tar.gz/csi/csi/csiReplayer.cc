#include <csiInterface.h>
#include <csiScanner.h>
#include <csiReplayer.h>

static int recordQuery=0;
static int replayThreadCount=0;
struct queryInfo
{
    int     type;   /* 0=insert, 1=get, 2=scan */
    int     op;
    int     limit;
    int     siLen;
    int     keyLen;
    char    si[8];
    char    key[32];
};
struct queryInfo    *queryQInfos[   QUERY_Q_CNT ];
static volatile int  queryQPos[ QUERY_Q_CNT ];
static volatile int  queryPos;
static FILE         *qrfd;
static int           requestCount = 0;
static int           doneCount = 0;
static csiConcurrentQueue     replayQueryQueue;

void initQueryRecording()
{
    pthread_t   QRFlusher;
    int         ret;
    int         i;

    recordQuery = get_property_int("common","record_query");
    replayThreadCount   = get_property_int("common","replay_thread_count");

    if( recordQuery )
    {
        qrfd = fopen( "qr.ret", "wa" );
        CSI_ASSERT( qrfd );
    
        for( i = 0 ; i < QUERY_Q_CNT ; i ++ )
        {
            CSI_ASSERT( CSI_MALLOC( sizeof( queryQInfos[i] ) * QUERY_Q_SIZE,
                        (void**)&queryQInfos[i] ) );
            queryQPos[ i ] = 0;
        }
        queryPos = 0;

        CSI_ASSERT( pthread_create( 
                &QRFlusher,
                NULL,
                queryRecordFlusher,
                (void*)NULL ) == 0 );
    }
    else
    {
        CSI_ASSERT( replayQueryQueue.init( "REPLAY_QUERY",0,RQQ_SIZE ) );
        qrfd = fopen( "qr.ret", "rw+" );
        CSI_ASSERT( qrfd );

        for( i = 0 ; i < replayThreadCount ; i ++ )
        {
            ret = pthread_create( &QRFlusher, NULL, replayer, (void*)NULL);
            if( ret )
            {
                printf("ret:%d\n",ret);
                CSI_ASSERT( ret == 0 );
            }
        }
    }
}

void destQueryRecording()
{
    replayQueryQueue.free();
}


void * queryRecordFlusher( void * ptrArg )
{
    queryInfo   * info;
    int           curPos;
    int           curCnt;
    int           i;

    usleep( 10 * 1000 );
    while( true )
    {
        curPos = circularInc( &queryPos, QUERY_Q_CNT );
        curCnt = queryQPos[ curPos ];
        if( curCnt )
        {
            fprintf( qrfd, "%d\n", curCnt );
            for( i = 0 ; i < curCnt ; i ++ )
            {
                info = &queryQInfos[ curPos ][ i ];
                fprintf( qrfd, "%s,%s,%d,%d,%d\n",
                        info->si,
                        info->key,
                        info->type,
                        info->op,
                        info->limit );
            }
        }
        else
        {
            usleep( 1000 );
        }
        queryQPos[ curPos ] = 0;
    }
}

bool skipQuery()
{
    return recordQuery == 2;
}
bool writeQuery(
        char    * si,
        int       siLen,
        char    * key,
        int       keyLen,
        int       type,
        int       op,
        int       limit )
{
    queryInfo   * info;
    int           curPos = 0;
    int           curCnt = -1;

    if( !recordQuery )
    {
        return true;
    }
    
    while( true )
    {
        curPos = queryPos;
        curCnt = queryQPos[ curPos ];
        if( curCnt < QUERY_Q_SIZE )
        {
            if( __sync_bool_compare_and_swap( 
                        &queryQPos[ curPos ], curCnt, curCnt + 1 ) )
            {
                break;
            }
        }
        else
        {
            usleep( 100 ); /* sleep to flush */
        }
    }

    CSI_ASSERT( curCnt != -1 );
    info = &queryQInfos[ curPos ][ curCnt ];

    strncpy( info->si, si, siLen );
    strncpy( info->key, key, keyLen );
    info->type  = type;
    info->op    = op;
    info->limit = limit;

    return recordQuery == 1;
}

char * getStr( char * src, char * dst, int * len )
{
    char *ptr;
    char *next = NULL;

    ptr = strchr( src, ',' );
    if( ptr != NULL )
    {
        *ptr = '\0';
        next = ptr + 1;
    }
    else
    {
        ptr = strchr( src, '\n' );
        if( ptr != NULL )
        {
            *ptr = '\0';
            next = ptr + 1;
        }
    }
    strcpy( dst, src );
    *len = strlen( src );

    return next;
}
char * getInt( char * src, int * dst )
{
    char *ptr;
    char *next = NULL;

    ptr = strchr( src, ',' );
    if( ptr != NULL )
    {
        *ptr = '\0';
        next = ptr + 1;
    }
    else
    {
        ptr = strchr( src, '\n' );
        if( ptr != NULL )
        {
            *ptr = '\0';
            next = ptr + 1;
        }
    }
    *dst = atoi( src );

    return next;
}



void * replayer( void * ptrArg )
{
    VoidPtr       ptr;
    queryInfo   * info;
    int           handle;
    csiResult   * scanRet;
    char        * getRet;
    int           valLen = 800;
    char          valBody[1024]={0};
    int           j;

    while( true )
    {
        while( replayQueryQueue.pop( &ptr ) )
        {
            info = (queryInfo*)ptr;
            switch( info->type )
            {
                case 0:
                    (void)csiInsert(
                            info->siLen, info->si,
                            info->keyLen, info->key,
                            valLen,(char*)valBody, 0 );
                    break;
                case 1:
//                    for(j=0; j<4; j++)
                    {
                        getRet = csiGet(
                            info->siLen, info->si,
                            info->keyLen, info->key );
                        csiGetEnd( getRet );
                    }
                    break;
                case 2:
                    if( ( handle = csiScan( 
                                    info->siLen, info->si,
                                    info->op,
                                    info->limit,
                                    info->keyLen, info->key ) ) 
                            != -1 )
                    {
                        while( 
                                ( scanRet = 
                                  csiScanNext( handle ) )->keyLen > 0 );
                    }
                    CSI_ASSERT( csiScanEnd( handle ) );
                    break;
                default:
                    break;
            }
            free( info );
            atomicInc( &doneCount , 1 );
        }
        usleep( 10000 );
    }

}
void   replayQuery()
{
    int           i;
    int           curCnt;
    char          str[256];
    char        * cursor;
    int           idx;
    queryInfo   * info;
    int           handle;
    csiResult   * ret;
    int           line = 0;
    int           curPos;
    int           progress=0;
    int           beforeProgress=0;
    uint64_t      startTime;
    uint64_t      endTime;
    uint64_t      durTime;
    int           prevRecordQuery = recordQuery;

    recordQuery = 0; /* disable */

    startTime = get_cur_milliseconds();

    doneCount = 0;
    requestCount = 0;

    if( !recordQuery )
    {
        fseek( qrfd, 0L, SEEK_SET );
        while( !feof( qrfd ) )
        {
            curCnt = 0;
            fscanf( qrfd, "%d\n", &curCnt );
            line ++;
            DEBUG("{%d}\n",curCnt );
            for( i = 0 ; i < curCnt ; i ++ )
            {
                if( fgets( str, 256, qrfd ) )
                {
                    line ++;
                    DEBUG("[%s\n]",str);
                    cursor = (char*)str;

                    info = (queryInfo*)malloc( sizeof( *info ) );
                    CSI_ASSERT( info );
                    cursor =getStr( cursor, (char*)info->si, &info->siLen );
                    cursor =getStr( cursor, (char*)info->key, &info->keyLen );
                    cursor =getInt( cursor, &info->type );
                    cursor =getInt( cursor, &info->op );
                    cursor =getInt( cursor, &info->limit );
                    info->limit = 50;

                    DEBUG("[%s %s %d %d %d]\n",
                            info->si,
                            info->key,
                            info->type,
                            info->op,
                            info->limit );
                    replayQueryQueue.push( (VoidPtr*)&info );
                }
                requestCount ++;
                if( ( requestCount % 10000 ) == 0 )
                {
                    endTime = get_cur_milliseconds();
                    durTime = endTime - startTime;
                    printf("[%6d/%6d] QueueSize:%6d %8.f QPS",
                           doneCount,
                           requestCount,
                           replayQueryQueue.getFree(),
                           doneCount*1000.0/durTime
                          );
                    csiIO::report();
                    beforeProgress = progress;
                }
            }
        }
    }
    printf("%d count.\n",requestCount );
    while( replayQueryQueue.getFree() )
    {
        usleep( 100 );
        progress = doneCount * 100 / requestCount;
        if( beforeProgress != progress )
        {
            endTime = get_cur_milliseconds();
            durTime = endTime - startTime;
            printf("[%6d/%6d] QueueSize:%6d %8.f QPS",
                   doneCount,
                   requestCount,
                   replayQueryQueue.getFree(),
                   doneCount*1000.0/durTime
                  );
            csiIO::report();
            beforeProgress = progress;
        }
    }

    endTime = get_cur_milliseconds();
    durTime = endTime - startTime;

    printf("%f sec  %.3f IOPS\n", durTime/1000.0, doneCount*1000.0/durTime);

    recordQuery = prevRecordQuery; /* recovery*/
}
