#include <csiByteArray.h>
#include <csiWorkerPool.h>
#include <csiScanner.h>

int                     csiScanner::scannerPoolSize = 32;
int                     csiScanner::cacheSize = 16;
int                     csiScanner::useMPR = 0 ;
csiScanner            * csiScanner::scannerPool;
csiConcurrentQueue      csiScanner::poolQueue;


bool csiScanner::init()
{
    VoidPtr    ptr;
    int        i;
    int        j;

    scannerPoolSize = get_property_int("scanner","pool_size");
    cacheSize       = get_property_int("scanner","cache_size");
    useMPR          = get_property_int("scanner","use_mpr");

    CSI_ASSERT( cacheSize <= CSI_SCANNER_CACHE  );

    CSI_ASSERT( scannerPoolSize * cacheSize 
            <= ByteArray::getResultBufferPoolSize() );

    printf("ByteArrayPoolSize : %d \n",ByteArray::remainPoolFreeCount() );

    TEST( poolQueue.init( "SCANNER_POOL",0,scannerPoolSize*2 ) );
    TEST( CSI_MALLOC( 
                sizeof( csiScanner ) * scannerPoolSize, 
                (void**)&scannerPool ) );
    for( i = 0 ; i < scannerPoolSize ; i ++ )
    {
        new (&scannerPool[i]) csiScanner();
        for( j = 0 ; j < cacheSize ; j ++ )
        {
            scannerPool[i].key[j].alloc( CSI_BA_POOL_SCANNER );
            scannerPool[i].value[j].alloc( CSI_BA_POOL_SCANNER );
            /* set a value about null terminated */
            scannerPool[i].result[cacheSize+1].keyLen = 0;
            scannerPool[i].result[cacheSize+1].valLen = 0;
        }

        scannerPool[i].seq = i;
        ptr = (VoidPtr)i;
        poolQueue.push( &ptr );
    }

    printf("ByteArrayPoolSize : %d \n",ByteArray::remainPoolFreeCount() );

    return true;

    EXCEPTION_END;

    syncLogReport();
    assert( 0 );
}
bool csiScanner::dest()
{
    VoidPtr          ptr;
    int              seq;
    csiScanner    * scanner;
    int              i;
    int              j;

    for( i = 0 ; i < scannerPoolSize ; i ++ )
    {
        while( poolQueue.pop( &ptr ) == false )    usleep( 100 );
        seq = (intptr_t)ptr;
        scanner = get( seq );

        for( j = 0 ; j < cacheSize ; j ++ )
        {
            scanner->key[j].free();
            scanner->value[j].free();
        }
    }

    poolQueue.free();
    CSI_FREE( scannerPool );

    return true;
}


int csiScanner::alloc()
{
    VoidPtr    ptr;

    while( poolQueue.pop( &ptr ) == false )    usleep( 100 );

    return (intptr_t)ptr;
}

void csiScanner::release(int seq )
{
    VoidPtr ptr;

    ptr = (VoidPtr)seq;
    poolQueue.push( &ptr );

}

bool csiScanner::begin( ByteArray       aSI, 
                        csiOperation    aOP, 
                        int             aCount,
                        ByteArray       beginKey )
{
    csiMemGroup     * memGroup;
    csiStoredGroup  * storedGroup;
    bool              siMapLocked = false;
    bool              switchLocked = false;
    csiPos          * pos;
    int               i;
    int               j;

    si = csiManager::chooseSI( aSI.len, (char*)aSI.body, false/*XLock*/);
    siMapLocked = true;
    TEST( si );

    si->switchLock.RLock();
    switchLocked = true;

    readKVCount   = 0; /* limitCount 체크를 위한 것 */
    limitCount    = aCount;
    sgCursorCount = 0;

    storedGroup = (csiStoredGroup*)si->storedGroup;
    while( storedGroup != NULL )
    {
        sgCursorCount += storedGroup->getNodeMergeLevel();

        storedGroup = storedGroup->getNext();
        i ++;
    }


    if( sgCursorCount < CSI_SCANNER_PREALLOC )
    {
        sgCursor = (csiSGCursor*)sgCursorPrealloc;
    }
    else
    {
        TEST( CSI_MALLOC(  sizeof( csiSGCursor ) * sgCursorCount, 
                          (void**)(&sgCursor) ) );
        for( i = 0 ; i < sgCursorCount; i ++ )
        {
            new (&sgCursor[i]) csiSGCursor;
        }
    }

    atomicInc( &si->scanCount, 1 );

    /* MemGroup에 대한 Iterator On */
    for( i = 0 ; i < csiManager::getMemGroupCountForSwitch() ; i ++ )
    {
        memGroup     = (csiMemGroup*)si->memGroup[ i ];

        memItr[i] = memGroup->beginScan( &beginKey );
        if( memGroup->isEndScan( &memItr[i] ) )
        {
            doneMemItr[i] = true;
        }
        else
        {
            doneMemItr[i] = false;
        }
        /* beginKey이전의 값으로, skip해야 한다. */
        while( !doneMemItr[i] )
        {
            if( beginKey.compare( (ByteArray*)&memItr[i]->first ) <=0 )
                break;
            memItr[i] ++;
            if( memGroup->isEndScan( &memItr[i] ) )
            {
                doneMemItr[i] = true;
            }
        }
    }

    /* stored group에 대한 Iterator On */
    i = 0;
    storedGroup = (csiStoredGroup*)si->storedGroup;
    while( storedGroup != NULL )
    {
        for( j = 0 ; j < storedGroup->getNodeMergeLevel() ; j ++ )
        {
            storedGroup->initCursor( &sgCursor[ i ], CSI_POS_DATA, 
                                    true /*mpr*/,
                                    j,
                                    &beginKey );

            /* beginKey이전의 값은 skip해야 한다. */
            while( !sgCursor[ i ].done )
            {
                pos = &sgCursor[ i ].pos[ CSI_POS_DATA ];
                if( beginKey.compare( &pos->key ) <=0 )
                    break;
                storedGroup->nextCursor( &sgCursor[ i ] );
            }
            i ++;
            CSI_ASSERT( i <= sgCursorCount );
        }

        storedGroup = storedGroup->getNext();
    }

    CSI_ASSERT( i == sgCursorCount );

    return true;

    EXCEPTION_END;

    if( switchLocked == true )    si->switchLock.release();
    if( siMapLocked == true )    csiManager::releaseSIMapLock();

    syncLogReport();

    return false;
}


bool    csiScanner::next()
{
    csiMemGroup       * memGroup;
    csiStoredGroup    * storedGroup;
    /* minKey를 찾는다. 단 여러개일 수 있으니 모두 순회해보고, minKey가 여럿
     * 이면, 이를 병합한다. */
    ByteArray         * minKey = NULL;
    ByteArray         * curKey;
    ByteArray         * curValue;
    csiResult         * curResult;
    csiPos            * pos;
    int                 minMGIdx[MEMGROUP_MAX];
    int                 minMGCount = 0;
    int                 minSGIdx[ CSI_MIN_SG_CNT ]; 
    int                 minSGCount = 0;
    int                 ret;
    int                 i;
    int                 j;
    int                 curReadKVCount = 0;

    for( curReadKVCount = 0 ; curReadKVCount < cacheSize ; curReadKVCount ++ )
    {
        minKey        = NULL;
        minMGCount    = 0;
        minSGCount    = 0;
        curKey        = &key[ curReadKVCount ];
        curValue      = &value[ curReadKVCount ];
        curResult     = &result[ curReadKVCount ];

        curResult->keyLen = 0;
        curResult->valLen = 0;

        /* 필요한 개수 만큼 읽음 */
        if( ( limitCount > 0 ) &&
            ( readKVCount >= limitCount ) )
        {
            return false;
        }

        curKey->len = 0;
        curValue->len = 0;

        /************************** minKey를 찾는다 **************************/
        for( i = 0 ; i < csiManager::getMemGroupCountForSwitch() ; i ++ )
        {
            if( !doneMemItr[i] )
            {
                memGroup     = (csiMemGroup*)si->memGroup[ i ];

                if( minKey == NULL )
                {
                    ret = 1; /* 최초의 Read */
                }
                else
                {
                    ret = minKey->compare( (ByteArray*)&memItr[i]->first );
                }
                if( ret >= 0 ) /* 최소 key 발견 */
                {
                    if( ret > 0 )    /*더 작은 최소키이니, 이전 키 버림 */
                    {
                        minMGCount = 0;
                    }
                    CSI_ASSERT( minMGCount < MEMGROUP_MAX );
                    minKey = (ByteArray*)&memItr[i]->first;
                    minMGIdx[ minMGCount++ ] = i;
                }
            }
        }

        for( i = 0 ; i< sgCursorCount ; i ++ )
        {
            if( !sgCursor[ i ].done )
            {
                pos = &sgCursor[ i ].pos[ CSI_POS_DATA ];
                if( minKey == NULL )
                {
                    ret = 1; /* 최초의 Read */
                }
                else
                {
                    ret = minKey->compare( &pos->key );
                }
                if( ret >= 0 ) /* 최소 key 발견 */
                {
                    if( ret > 0 )    /*더 작은 최소키이니, 이전 키 버림 */
                    {
                        minMGCount = 0;
                        minSGCount = 0;
                    }
                    CSI_ASSERT( minSGCount < CSI_MIN_SG_CNT );
                    minKey = &pos->key;
                    minSGIdx[ minSGCount++ ] = i;
                }
            }
        }

        if( minKey == NULL )/*탐색 끝 */
        {
            return false;
        }

        curKey->copyFrom( minKey );

        /* 최소key와 같은 경우에만 fetchNext */
        for( i = 0, j = 0 ; i < csiManager::getMemGroupCountForSwitch() ; i ++ )
        {
            if( j >= minMGCount ) break;

            if( minMGIdx[ j ] == i )
            {
                if( doneMemItr[i] )
                {
                    LOG("%d / minMGIdx:%d", j, minMGIdx[j ] );
                    LOG("doneMemitr[ %d ] : %d", i, doneMemItr );
                    CSI_ASSERT( !doneMemItr[i] );
                }
                memGroup     = (csiMemGroup*)si->memGroup[ i ];

                CSI_ASSERT( curValue->merge( &memItr[i]->second ) );

                memItr[i] ++;
                if( memGroup->isEndScan( &memItr[i] ) )
                {
                    doneMemItr[i] = true;
                }
                j++;
            }
        }

        j = 0;
        for( i = 0 ; i< sgCursorCount ; i ++ )
        {
            if( j >= minSGCount ) break;
            if( minSGIdx[ j ] == i )
            {
                CSI_DASSERT( !sgCursor[ i ].done );

                storedGroup = (csiStoredGroup*)sgCursor[ i ].targetSGPtr;
                pos = &sgCursor[ i ].pos[ CSI_POS_DATA ];
                do
                {
                    CSI_ASSERT( curValue->merge( &pos->subKey ) );
                    storedGroup->nextCursor( &sgCursor[ i ] );
                    /* nodeMerge되었을 경우, 
                     * 중복된 Key가 Group별로 여러번 올라올 수 있음 */
                    pos = &sgCursor[ i ].pos[ CSI_POS_DATA ];
                }
                while( ( !sgCursor[ i ].done ) &&
                       ( curKey->compare( &pos->key ) == 0 ) );

                j++;

            }
        }

        readKVCount ++;

        curResult->keyLen = curKey->len;
        curResult->keyBody= (char*)curKey->body;
        curResult->valLen = curValue->len;
        curResult->valBody= (char*)curValue->body;
    }

    return true;
}

bool          csiScanner::end()
{
    csiMemGroup      * memGroup;
    csiStoredGroup   * storedGroup;
    bool               siMapLocked = true;
    bool               switchLocked = true;
    int                i;

    for( i = 0 ; i < csiManager::getMemGroupCountForSwitch() ; i ++ )
    {
        if( !doneMemItr[i] )
        {
            memGroup     = (csiMemGroup*)si->memGroup[ i ];
            memGroup->finishScan();
            doneMemItr[i] = true;
        }
    }

    for( i = 0 ; i< sgCursorCount ; i ++ )
    {
        storedGroup = (csiStoredGroup*)sgCursor[ i ].targetSGPtr;
        storedGroup->destCursor( &sgCursor[ i ] );
    }
    
    switchLocked = false;
    si->switchLock.release();

    siMapLocked = false;
    csiManager::releaseSIMapLock();


    if( sgCursorCount >= CSI_SCANNER_PREALLOC )
    {
        TEST( CSI_FREE( sgCursor) );
    }

    release( seq );

    return true;

    EXCEPTION_END;

    if( switchLocked == true )    si->switchLock.release();
    if( siMapLocked == true )    csiManager::releaseSIMapLock();

    return false;
}

void csiScanner::dump()
{
    int i;

    REPORT("********* CSI Scanner *********\n");
    REPORT(    "seq         : %d\n"
            "si          : 0x%x\n"
            "op          : %d\n"
            "readKVCount : %d\n"
            "limitCount  : %d\n"
            "sgCursorCount  : %d\n",
            seq,
            si,
            op,
            readKVCount,
            limitCount,
            sgCursorCount );
    si->reportDetail();

    REPORT("MemGroupInfo:\n");
    for( i = 0 ; i < csiManager::getMemGroupCountForSwitch() ; i ++ )
    {
        REPORT("[%d] %d", i, doneMemItr[i] );
        if( !doneMemItr[i] )
        {
            ((ByteArray*)&memItr[i]->first )->dump();
            ((ByteArray*)&memItr[i]->second )->dump();
        }
        REPORT("\n");
    }
    REPORT("StoredGroupInfo:\n");
    for( i = 0 ; i < sgCursorCount ; i ++ )
    {
        REPORT("[%d]\n",i);
        sgCursor[ i ].report();
        REPORT("\n");
    }
    REPORT("StoredGroupIterator:\n");
    for( i = 0 ; i < CSI_SCANNER_CACHE ; i ++ )
    {
        if( result[ i ].keyLen == 0 )
            break;

        REPORT("[%2d]",i);
        key[ i ].dump();
        REPORT("  ");
        value[ i ].dump();
        REPORT("\n");
    }
}
