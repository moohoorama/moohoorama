#include <common.h>
#include <csiPageManager.h>
#include <csiManager.h>
#include <csiMemGroup.h>
#include <csiStoredGroup.h>
#include <csiWorkerPool.h>

int                 csiStoredGroup::multiPageReadCount;
int                 csiStoredGroup::useCacheRoot = 0;
int                 csiStoredGroup::useCacheNode = 0;
int                 csiStoredGroup::useCacheDpage = 0;
int                 csiStoredGroup::rangeMergeThreshold = 0;
int                 csiStoredGroup::rangeMergeSubThreshold = 0;
int                 csiStoredGroup::rangeMergeMinNodeCount = 0;
int                 csiStoredGroup::rangeMergeMaxNodeCount = 0;
const csiPageType   csiStoredGroup::depthType[ CSI_POS_MAX ] = { 
                            CSI_PAGE_TYPE_NONE, /*RMap */
                            CSI_PAGE_TYPE_ROOT,
                            CSI_PAGE_TYPE_NODE,
                            CSI_PAGE_TYPE_DPAGE };
bool csiStoredGroup::init()
{
    useCacheRoot       =get_property_int("storedgroup_use_cache","root");
    useCacheNode       =get_property_int("storedgroup_use_cache","node");
    useCacheDpage      =get_property_int("storedgroup_use_cache","dpage");
    multiPageReadCount =get_property_int("storedgroup","multi_page_read_count");
    rangeMergeThreshold=get_property_int("storedgroup_range_merge","threshold");
    rangeMergeSubThreshold    =
        get_property_int("storedgroup_range_merge","sub_threshold");
    rangeMergeMinNodeCount    =
        get_property_int("storedgroup_range_merge","min_node_count");
    rangeMergeMaxNodeCount    =
        get_property_int("storedgroup_range_merge","max_node_count");

    /* multipageReadCount * nodeMerge threshold 만큼 victim을 소모한다. */
    CSI_ASSERT( 
        multiPageReadCount * csiManager::getNodeMergeThreshold() * PAGE_SIZE 
        < csiPageManager::getBufferSize()/2 );
    CSI_ASSERT( multiPageReadCount <= MULTI_PAGE_READ_MAX );

    return true;
}
bool csiStoredGroup::dest()
{
    return true;
}

bool csiStoredGroup::add(   csiSIInfo         * info, 
                            csiFlushResult    * result )
{
    csiStoredGroup    * newSGrp = NULL;
    csiStoredGroup    **SGrpRef = NULL;
    int                  i;

    /* 위쪽에서 반드시 switchLock을 WLock을 잡고 와야 함 */
    CSI_ASSERT( info->switchLock.isWLock() );

    TEST( CSI_MALLOC( sizeof( csiStoredGroup ), (void**)&newSGrp ) );
    csiMemset( newSGrp, 0, sizeof( csiStoredGroup ) );
    csiMemcpy( &newSGrp->flushResult, result, sizeof( csiFlushResult ) );
    newSGrp->owner        = info;
    newSGrp->NANSlot    = NULL;
    newSGrp->NANSize    = result->pageCount[ CSI_PAGE_TYPE_NODE ];
    newSGrp->rootMapOrg    = NULL;
    TEST( CSI_MALLOC( sizeof( int ) * newSGrp->NANSize, 
                        (void**)&newSGrp->NANSlot ) );
    csiMemset( newSGrp->NANSlot, 0, sizeof( int ) * newSGrp->NANSize );

    TEST( newSGrp->makeRootMap() );
    TEST( newSGrp->makeFilterCache() );

    newSGrp->flushResult.log( "add StoredGroup" );

    /* 중복 검색. 없어야 함 */
    SGrpRef = find( info, newSGrp->flushResult.lastRootPID );
    CSI_ASSERT( (*SGrpRef) == NULL );

    /* 추가함 */
    newSGrp->next        = (csiStoredGroup*)info->storedGroup;
    info->storedGroup    = newSGrp;
    info->groupCount ++;
    if( newSGrp->getNodeMergeLevel() == 1 )
    {
        info->unmergedGroupCount ++;
    }

    return true;

    EXCEPTION_END;

    if( newSGrp )
    {
        if( newSGrp->NANSlot )       CSI_FREE( newSGrp->NANSlot );
        if( newSGrp->rootMapOrg )    CSI_FREE( newSGrp->rootMapOrg );
        for( i = 0 ; i < newSGrp->getNodeMergeLevel() ; i ++ )
        {
            if( newSGrp->filterCache[i] ) CSI_FREE( newSGrp->filterCache[i] );
        }

        CSI_FREE( newSGrp );
    }

    newSGrp = NULL;

    return false;
}

bool csiStoredGroup::makeFilterCache()
{
    int                      slotSize;
    int                      usedSize;
    int                      size;
    csiPageID                PID;
    int                      i;
    DECLARE_BASE_VARIABLE;

    SET_CATEGORY( CSI_IO_STAT_MAKE_FILTER_CACHE );

    for( i = 0 ; i < getNodeMergeLevel() ; i ++ )
    {
        PID              = flushResult.lastFilterPID[ i ];
        size             = flushResult.filterSize[ i ];
        usedSize         = 0;
        filterCache[ i ] = NULL;
        if( size == 0 ) continue;

        TEST( CSI_MALLOC( size, (void**)&filterCache[ i ] ) );

        do
        {
            CSI_ASSERT( PID != NULL_PID );

            /* 한번만 읽고 마니, cache사용 안함 */
            ACCESS_PAGE( PID, CSI_PAGE_TYPE_FILTER, false/*cache*/ );
            /* slot하나 통채로 복사 */
            slotSize = header->slotDir.getSlotSize( 0 );
            csiMemcpy( filterCache[ i ] + usedSize, 
                       header->slotDir.getPtrBySlot( 0 ),
                       slotSize );
            usedSize += slotSize;
            CSI_ASSERT( usedSize <= size );

            RELEASE_PAGE( false/*cache*/ );

            PID = header ->prevPID;
        } while( usedSize < size );

    }
    FINALIZE_PAGE( );

    return true;

    EXCEPTION_END;

    EXCEPTION_PAGE();

    return false;    
}

bool csiStoredGroup::makeRootMap()
{    
    ByteArray             firstKey;
    csiPageID             PID;
    char                * bytePtr;
    int                   rootMapSize;
    int                   count;
    int                   i;
    DECLARE_BASE_VARIABLE;

    SET_CATEGORY( CSI_IO_STAT_MAKE_ROOT_MAP );

    LOG( "Generate root map..." );
    /********************* Size Estimation *****************/
    /* root가 page 여럿에 결처 저장될 수 있음 */
    PID =  flushResult.lastRootPID ;
    ACCESS_PAGE( PID, CSI_PAGE_TYPE_ROOT, true/*cache*/ );

    /* LastRoot여야 함. 그래야 이전 Group의 Flush가 완성된 것 */
    count    = header->siblingSeq;
    i        = count;

    /* 읽어가면서 map의 크기를 얻어냄 */
    rootMapSize = sizeof( csiSlotDir );
    while( true )
    {
        TEST( header->slotDir.slotCount >= 1 );
        header->slotDir.readBA( 0, &firstKey );
        rootMapSize+= sizeof( csiOffset ) 
                    + csiSlotDir::getCompactBASize( &firstKey )
                    + sizeof( csiPageID );
        RELEASE_PAGE( true/*cache*/ );

        if( i == 0 ) break;

        i --;
        TEST( header->prevPID != NULL_PID );

        PID = header->prevPID;
        ACCESS_PAGE( PID, CSI_PAGE_TYPE_ROOT, true/*cache*/ );
        TEST( header->siblingSeq == i );
    }

    LOG( "rootMap ByteSize : %d\n", rootMapSize );
    TEST( CSI_MALLOC( rootMapSize + CSI_ALIGN, (void**)&rootMapOrg ) );
    rootMap = (csiSlotDir*)align( (uintptr_t)rootMapOrg, CSI_ALIGN );
    rootMap->init( CSI_SD_KEY_PID, ((char*)rootMap) + rootMapSize );


    /****************** generate map *************************/
    /* 다시 읽어서 map을 만듬 */
    PID =  flushResult.lastRootPID ;
    for( i = 0 ; i <= count ; i ++ )
    {
        CSI_ASSERT( PID != NULL_PID );
        ACCESS_PAGE( PID, CSI_PAGE_TYPE_ROOT, true/*cache*/ );

        header->slotDir.readBA( 0, &firstKey );
        rootMap->insertKP( &firstKey, PID );

        RELEASE_PAGE( true/*cache*/ );

        PID = header->prevPID;
    }

    TEST( rootMap->sort() );

    FINALIZE_PAGE();

    return true;

    EXCEPTION_END;

    EXCEPTION_PAGE();

    return false;
}

csiStoredGroup    ** csiStoredGroup::find( csiSIInfo * info, csiPageID  RPID)
{
    csiStoredGroup  *SGrp = NULL;
    csiStoredGroup **SGrpRef = NULL;

    SGrpRef = (csiStoredGroup**)&info->storedGroup;
    SGrp    = *SGrpRef; 

    while((SGrp != NULL) && (SGrp->flushResult.lastRootPID != RPID))
    {
        SGrpRef = &(SGrp->next);
        SGrp    = *SGrpRef; 
    }

    return SGrpRef;
}

bool csiStoredGroup::remove( csiSIInfo * info, csiPageID    RPID )
{
    csiStoredGroup    * SGrp = NULL;
    csiStoredGroup    **SGrpRef = NULL;
    int                 i;

    /* 위쪽에서 반드시 switchLock을 WLock을 잡고 와야 함 */
    TEST( info->switchLock.isWLock() );

    SGrpRef = find( info, RPID );
    SGrp    = *SGrpRef;
    TEST( SGrp != NULL );

    SGrp->flushResult.log( "remove StoredGroup" );

    if( SGrp->getNodeMergeLevel() == 1 )
    {
        info->unmergedGroupCount --;
    }
    info->groupCount --;


    /* Free함 */
    for( i = 0 ; i < SGrp->getNodeMergeLevel() ; i ++ )
    {
        if( SGrp->filterCache[i] )    CSI_FREE( SGrp->filterCache[i] );
    }
    CSI_FREE( SGrp->rootMapOrg );
    CSI_FREE( SGrp->NANSlot );

    *SGrpRef = SGrp->next;
    CSI_FREE( SGrp );

    return true;

    EXCEPTION_END;

    return false;
}

int csiStoredGroup::reloadMaster( int fd, csiSIInfo  * info, int count )
{
    csiFlushResult flushResult;
    int            lastPID = 0;
    int            i;

    for( i = 0 ; i < count ; i ++ )
    {
        flushResult.reload( fd );
        flushResult.report("RELOAD");
        flushResult.log("RELOAD");
        add( info, &flushResult );

        lastPID = ( flushResult.endPID > lastPID ) ?
                flushResult.endPID : lastPID ;
    }

    return lastPID;
}


void csiStoredGroup::reportMaster( int fd, int count )
{
    csiFlushResult      flushResult;
    int                  ret;
    int                  i;

    for( i = 0 ; i < count ; i ++ )
    {
        /*
        ret = read( fd, &flushResult, sizeof( csiFlushResult ) );
        CSI_ASSERT( ret == sizeof( csiFlushResult ) ) ;
        */
        flushResult.reload( fd );
        flushResult.report("RELOAD");

    }
}

void    csiStoredGroup::storeMaster( int fd )
{
/*
    CSI_ASSERT( write( fd, &flushResult, sizeof( flushResult ) ) ==
                sizeof( flushResult ) );
 */
    flushResult.store( fd );
}

bool    csiStoredGroup::findFromPage(   csiPageID          PID, 
                                        csiPageType        type, 
                                        ByteArray          key,
                                        bool               exact,
                                        csiPos           * pos,
                                        int                nodeNo )
{
    csiSlotDir        * slotDir;
    int                 i;
    bool                useCache = true;
    csiIOStatType       ioType=CSI_IO_STAT_NONE;
    DECLARE_BASE_VARIABLE;

    switch( type )
    {
        case CSI_PAGE_TYPE_DPAGE:         /* (K + V) * N */
            ioType        = CSI_IO_STAT_SEARCH_DPAGE;
            useCache    = useCacheDpage;
            break;
        case CSI_PAGE_TYPE_NODE:            /* KArray */
            ioType        = CSI_IO_STAT_SEARCH_NODE;
            useCache    = useCacheNode;
            break;
        case CSI_PAGE_TYPE_ROOT:          /* (K + NodePID ) * N */
            ioType        = CSI_IO_STAT_SEARCH_ROOT;
            useCache    = useCacheRoot;
            break;
        default:
            break;
    }

    ACCESS_PAGE( PID, type, useCache );
    SET_CATEGORY( ioType );

    if( header->slotDir.type == CSI_SD_SUPER_KA )
    {    /* super이기 때문에, 내부 Group들도 읽음 */
        CSI_ASSERT( header->slotDir.slotCount == getNodeMergeLevel() );
        if( nodeNo == NULL_NODE_NO )
        {
            CSI_ASSERT( 0 );
            for( i = 0 ; i < header->slotDir.slotCount ; i ++ )
            {
                slotDir = (csiSlotDir*)header->slotDir.getPtrBySlot( i );
                (void)slotDir->find( key, &pos[ i ], exact );
            }
        }
        else
        {
            /* 특정 Node 지목 */
            CSI_ASSERT( nodeNo < header->slotDir.slotCount );
            slotDir = (csiSlotDir*)header->slotDir.getPtrBySlot( nodeNo );
            (void)slotDir->find( key, pos, exact );
        }
    }
    else
    {
        (void)header->slotDir.find( key, pos, exact );
    }
    RELEASE_PAGE( useCache );

    FINALIZE_PAGE( );

    return true;

    EXCEPTION_END;

    EXCEPTION_PAGE();

    return false;
}
bool    csiStoredGroup::readFromPage( csiPageID          PID, 
                                      csiPageType        type, 
                                      int                seq, 
                                      csiPos           * pos,
                                      int                nodeNo )
{
    csiSlotDir        * slotDir;
    int                 i;
    bool                useCache = true;
    csiIOStatType       ioType= CSI_IO_STAT_NONE;
    DECLARE_BASE_VARIABLE;

    switch( type )
    {
        case CSI_PAGE_TYPE_DPAGE:         /* (K + V) * N */
            ioType        = CSI_IO_STAT_SCAN_DPAGE;
            useCache    = useCacheDpage;
            break;
        case CSI_PAGE_TYPE_NODE:            /* KArray */
            ioType        = CSI_IO_STAT_SCAN_NODE;
            useCache    = useCacheNode;
            break;
        case CSI_PAGE_TYPE_ROOT:          /* (K + NodePID ) * N */
            ioType        = CSI_IO_STAT_SCAN_ROOT;
            useCache    = useCacheRoot;
            break;
        default:
            break;
    }

    ACCESS_PAGE( PID, type, useCache );
    SET_CATEGORY( ioType );

    if( header->slotDir.type == CSI_SD_SUPER_KA )
    {    /* super이기 때문에, 내부 Group들도 읽음 */
        CSI_ASSERT( header->slotDir.slotCount == getNodeMergeLevel() );
        if( nodeNo == NULL_NODE_NO )
        {
            CSI_ASSERT( 0 );
            for( i = 0 ; i < header->slotDir.slotCount ; i ++ )
            {
                slotDir = (csiSlotDir*)header->slotDir.getPtrBySlot( i );
                /* 마지막을 읽어라 */
                if( seq == READ_LAST_SEQ ) seq = slotDir->slotCount - 1;
                (void)slotDir->read( seq, &pos[ i ] );
            }
        }
        else
        {
            /* 특정 Node 지목 */
            CSI_ASSERT( nodeNo < header->slotDir.slotCount );
            slotDir = (csiSlotDir*)header->slotDir.getPtrBySlot( nodeNo );
            /* 마지막을 읽어라 */
            if( seq == READ_LAST_SEQ ) seq = slotDir->slotCount - 1;
            (void)slotDir->read( seq, pos );
        }
    }
    else
    {
        /* 마지막을 읽어라 */
        if( seq == READ_LAST_SEQ ) seq = header->slotDir.slotCount - 1;
        (void)header->slotDir.read( seq, pos );
    }

    RELEASE_PAGE( useCache );

    FINALIZE_PAGE( );

    return true;

    EXCEPTION_END;

    EXCEPTION_PAGE();

    return false;
}
bool    csiStoredGroup::findByKey(  ByteArray      key, 
                                    csiPos       * pos,
                                    int            subNo,
                                    bool           exact,
                                    int            depth )
{
    csiPos                   * upperPos = NULL;
    csiPos                   * curPos;
    int                        i;

    for( i = CSI_POS_RMAP ; i <= depth ; i ++ )
    {
        curPos = &pos[ i ];
        if( upperPos == NULL )
        {
            (void)rootMap->find( key, curPos, exact );
        }
        else
        {
            TEST( findFromPage( 
              upperPos->PID, depthType[i], key, exact, curPos, subNo ) );
        }
        if( !curPos->ret )
        {
            if( ( i == CSI_POS_NODE ) && ( getNodeMergeLevel() > 1)
               && ( curPos->prevPID >= 0 ) )
            {
                /* shift too prev */
                pos[ CSI_POS_ROOT ].PID = pos[ CSI_POS_NODE ].prevPID;
                if( pos[ CSI_POS_ROOT ].prevPID >= 0 )
                {
                    pos[ CSI_POS_RMAP ].PID = pos[ CSI_POS_ROOT ].prevPID;
                }

                /* Node 걸침 현상 확인 */
                TEST( findFromPage( 
                   upperPos->PID, depthType[i], key, exact, curPos, subNo ) );
            }
            if( !curPos->ret )
                break;
        }
        upperPos = curPos;
    }
    return true;

    EXCEPTION_END;

    return false;
}


bool    csiStoredGroup::findKeyValue( ByteArray      key, 
                                      ByteArray    * val )
{
    int            prevValLen = val->len;
    csiPos         pos[ CSI_POS_MAX ];
    csiPos       * dataPos;
    int            NSeq;
    int            i;

    dataPos = &pos[ CSI_POS_DATA ];
    dataPos->allocBA();

    for( i = 0 ; i < getNodeMergeLevel() ; i ++ )
    {
        /************************** Filtering **************************/
        if( !checkFilter( filterCache[i], flushResult.filterSize[i], &key ) )
        {
            atomicInc( &lookupStat.filterOutCount, 1 );
            atomicInc( &owner->lookupStat.filterOutCount, 1 );
            continue;
        }

        /************************** Traverse **************************/
        TEST( findByKey( key, (csiPos*)pos, i ) );
        if( dataPos->key == key )
        {
            CSI_ASSERT( val->merge( &dataPos->subKey ) );
        }
    }
    dataPos->freeBA();

    /************************** Postprocessing **************************/
    if( prevValLen == val->len )    /* 데이터 추가된거 없음. false positive */
    {
        atomicInc( &lookupStat.falsePositiveCount, 1 );
        atomicInc( &owner->lookupStat.falsePositiveCount, 1 );

        NSeq = pos[ CSI_POS_ROOT ].globalSeq;
        if( ( NSeq != -1 ) && rangeMergeThreshold )
        {
            CSI_ASSERT( NSeq < NANSize );
            atomicInc( &NANSlot[ NSeq ], 1 );
            if( NANSlot[ NSeq ] > rangeMergeThreshold )
            {
                TEST( tryRangeCompaction( key, NSeq ) );
            }
        }
    }
    else
    {
        atomicInc( &lookupStat.readCount, 1 );
        atomicInc( &owner->lookupStat.readCount, 1 );
    }

    return true;

    EXCEPTION_END;

    return false;
}

bool csiStoredGroup::tryRangeCompaction( ByteArray key, int NSeq )
{
    ByteArray              beginKey;
    ByteArray              endKey;
    int                    seq;
    int                    beginNSeq;
    int                    endNSeq;
    int                    count;
    int                    prevNSeq;
    int                    nextNSeq;
    csiPageID              RPID;
    int                    i;
    DECLARE_BASE_VARIABLE;

    /* 한 Node만 하면 효과가 적으니, 주변 Node도 부하가 심하면 같이 한다.*/
    for( prevNSeq = NSeq ; prevNSeq > 0 ; prevNSeq -- )
    {
        if( NANSlot[ prevNSeq - 1 ] < rangeMergeSubThreshold ) break;
        if( NSeq - prevNSeq > rangeMergeMaxNodeCount / 2 ) break;
    }
    for( nextNSeq = NSeq + 1 ; nextNSeq + 1 < NANSize ; nextNSeq ++ )
    {
        if( NANSlot[ nextNSeq + 1 ] < rangeMergeSubThreshold ) break;
        if( nextNSeq - NSeq > rangeMergeMaxNodeCount / 2 ) break;
    }

    /* 너무 작으면, 부하만 심해지니 하지 않는다. */
    if( ( nextNSeq - prevNSeq + 1 <= rangeMergeMinNodeCount ) &&
        ( rangeMergeMinNodeCount > 0 ) ) return true;


    /* last Root부터 역순으로 앞쪽으로 나아가며, 해당하는 Key를 탐색
     * Root는 거의 pageCache에 있을테니 I/O는 없으며,
     * prevPID Link만 있기 때문에 역순으로 간다. */
    seq     =    NANSize;
    RPID    =    flushResult.lastRootPID ;
    do
    {
        CSI_ASSERT( RPID != NULL_PID );
        ACCESS_PAGE( RPID, CSI_PAGE_TYPE_ROOT, true/*cache*/ );
        count = header->slotDir.slotCount;

        beginNSeq    = seq - count;
        endNSeq      = seq;

        /* 이 page에 해당 key가 있으면 */
        if( ( beginNSeq <= prevNSeq ) && ( prevNSeq < endNSeq ) )
            header->slotDir.readBA( prevNSeq - beginNSeq, &beginKey );
        if( ( beginNSeq <= nextNSeq ) && ( nextNSeq < endNSeq ) )
            header->slotDir.readBA( nextNSeq - beginNSeq, &beginKey );

        RPID = header->prevPID;
        RELEASE_PAGE( true/*cache*/ );

        seq -= count;
    }
    while( seq > 0 );

    CSI_ASSERT( seq == 0 );

    for( i = prevNSeq ; i < nextNSeq ; i ++)
    {
        CSI_ASSERT( i < NANSize );
        NANSlot[ i ] =0;
    }

    /* read하는 도중, 즉 switch lock을 잡은 상태의 시도이기 때문에,
     * asyncCompaction은 시도만 해보고 만다. 잘못해도 workerPool Queue full로
     * 인해 retry하면서 대기하면,flush/compaction 등 switch lock을 잡아야 하는
     * Worker가 여기 이 switch lock 때문에 대기하면서, deadlock이 걸리기
     * 때문이다. 
     * 시도만 해보고, 안되도 무시한다. compaction 안해도 문제는 아니니까 */
    (void)csiWorkerPool::asyncCompaction( (void*)owner, 
            beginKey,endKey,
            nextNSeq - prevNSeq + 1,
            getGroupMergeLevel());

//    NANSlot[ NSeq ] = 0;

    FINALIZE_PAGE();

    return true;

    EXCEPTION_END;

    EXCEPTION_PAGE();

    return false;
}

bool csiStoredGroup::rootRewrite( csiPageID           beginPID,
                                  csiPageID           endPID,
                                  csiFlushResult    * newFlushResult )
{
    csiPos                rmapPos;
    csiPos                rootPos;
    int                   nodeCount = 0;
    bool                  insert;

    rootPos.allocBA();
    TEST( csiPageManager::flushBegin() );

    rmapPos.seq = 0;
    while( rootMap->read( rmapPos.seq, &rmapPos ) )
    {
        rootPos.seq = 0;
        while( true )
        {
            TEST( readFromPage( rmapPos.PID, CSI_PAGE_TYPE_ROOT,
                                rootPos.seq, &rootPos, NULL_NODE_NO ) );
            if( !rootPos.ret )    break;
            rootPos.seq ++;

            /* 범위에 맞는 경우만 재구축 */
            if( ( ( beginPID == NULL_PID ) || ( rootPos.PID >= beginPID ) ) &&
                ( ( endPID == NULL_PID )   || ( rootPos.PID <= endPID   ) ) )
                continue;
            TEST( csiPageManager::insertToRoot( rootPos.key,rootPos.PID ));
            nodeCount ++;
        }
        rmapPos.seq ++;
    }
    rootPos.freeBA();
    TEST( csiPageManager::flushEnd( "RootRewrite", newFlushResult ) );

    /* root rewrite에 따라, root가 가리키는 Node들만 유효한 노드임 */
    newFlushResult->pageCount[ CSI_PAGE_TYPE_NODE ] = nodeCount;

    return true;

    EXCEPTION_END;

    rootPos.freeBA();

    return false;
}


bool csiStoredGroup::changeRoot( csiFlushResult    * newFlushResult,
                                 int                 kvCount )
{
    /* 위쪽에서 반드시 switchLock을 WLock을 잡고 와야 함 */
    CSI_ASSERT( owner->switchLock.isWLock() );

    flushResult.log( "change StoredGroup from" );

    /* NAN 재구성 */
    CSI_FREE( NANSlot );
    NANSize    = newFlushResult->pageCount[ CSI_PAGE_TYPE_NODE ];
    TEST( CSI_MALLOC( sizeof( int ) * NANSize, (void**)&NANSlot ) );
    csiMemset( NANSlot, 0, sizeof( int ) * NANSize );

    flushResult.pageCount[ CSI_PAGE_TYPE_NODE ] =
        newFlushResult->pageCount[ CSI_PAGE_TYPE_NODE ];
    flushResult.pageCount[ CSI_PAGE_TYPE_ROOT ] =
        newFlushResult->pageCount[ CSI_PAGE_TYPE_ROOT ];
    flushResult.pageCount[ CSI_PAGE_TYPE_FILTER ] =
        newFlushResult->pageCount[ CSI_PAGE_TYPE_FILTER ];
    flushResult.lastRootPID    = newFlushResult->lastRootPID;
    flushResult.KVCount       -= kvCount;
    CSI_ASSERT( flushResult.KVCount > 0 );

    /* root 재구성 */
    if( rootMapOrg )    CSI_FREE( rootMapOrg );
    rootMapOrg    = NULL;
    TEST( makeRootMap() );

    flushResult.log( "change StoredGroup to" );

    return true;

    EXCEPTION_END;

    return false;
}

bool csiStoredGroup::initCursor( csiSGCursor     * cursor,
                                 int               depth,
                                 bool              mpr,
                                 int               subNo,
                                 ByteArray       * beginKey )
{
    int    mprCount = multiPageReadCount;
    int    i;

    if( !mpr ) mprCount = 1;

    if( subNo == NULL_NODE_NO )
    {
        CSI_ASSERT( getNodeMergeLevel() == 1 );
        subNo = 0;
    }
    else
    {
        cursor->subNo = subNo;
    }
    cursor->depth = depth;
    for( i = 0 ; i <= depth ; i ++ ) cursor->pos[ i ].reset();

    cursor->pos[ depth ].allocBA();

    if( beginKey )
    {
        TEST( findByKey( *beginKey, (csiPos*)cursor->pos, 
                         subNo, false/*exact*/, depth ) );
    }
    else
    {
        TEST( findByKey( ByteArray::nullByteArray, (csiPos*)cursor->pos, 
                         subNo, false/*exact*/, depth ) );
    }

    cursor->targetSGPtr = (void*)this;
    cursor->done        = !cursor->pos[ depth ].ret;
    cursor->readCount   = 0;

    return true;

    EXCEPTION_END;

    return false;
}

bool csiStoredGroup::destCursor( csiSGCursor * cursor )
{
    cursor->pos[ cursor->depth ].freeBA();

    return true;
}

bool csiStoredGroup::nextCursor( csiSGCursor * cursor )
{
    csiPos * upperPos;
    csiPos * curPos;
    int      curDepth = cursor->depth;

    if( cursor->done ) return true;

    while( 1 )
    {
        curPos = &cursor->pos[ curDepth ];
        curPos->seq ++;
        if( curDepth == CSI_POS_RMAP )
        {
            if( !rootMap->read( curPos->seq, curPos ) )
            {
                cursor->done = true;
                break;
            }
        }
        else
        {
            upperPos = &cursor->pos[ curDepth - 1 ];
            TEST( readFromPage( upperPos->PID,
                                depthType[ curDepth ],
                                curPos->seq,
                                curPos,
                                cursor->subNo ) );
        }

        /* 현 depth의 Page를 다 읽었으니, 다음 page를 찾기 위해
         * 상위 depth의 page를 읽음 */
        if( !curPos->ret )
        {
            curPos->seq = -1;
            curDepth --;
            continue;
        }
        else
        {
            if( curDepth == cursor->depth )
            {
                cursor->readCount ++;
                break;
            }
            curDepth ++;
        }
    }

    return true;

    EXCEPTION_END;

    return false;
}

ByteArray csiStoredGroup::chooseNodeKeyInBuffer( char * nodePtr,
                                                 bool   min)
{
    csiPageHeader        * header;
    csiSlotDir            * subSlotDir;
    ByteArray              key[ MERGING_MAX ];
    int                      i;
    int                      ret = -1;

    /* Node내 SubSlotDir에서 가장 작은 Key를 읽음 */
    header    = (csiPageHeader*)nodePtr;
    CSI_ASSERT( header->slotDir.slotCount >= 1 );

    for( i = 0 ; i < header->slotDir.slotCount ; i ++ )
    {
        subSlotDir = (csiSlotDir*)header->slotDir.getPtrBySlot( i );
        if( subSlotDir->slotCount == 0 )
        {
            CSI_ASSERT( subSlotDir->beginPID == NULL_PID );
            continue;
        }
        
        if( min )
        { /* minKey를 읽음 */
            subSlotDir->readBA( 0, &key[ i ] );

            if( ret == -1 )
            {
                ret = i;
            }
            else
            {
                if( key[ i ] < key[ ret ] )
                {
                    ret = i;
                }
            }
        }
        else
        { /* maxKey를 읽음 */
            subSlotDir->readBA( subSlotDir->slotCount - 1, &key[ i ] );

            if( ret == -1 )
            {
                ret = i;
            }
            else
            {
                if( key[ ret ] < key[ i ] )
                {
                    ret = i;
                }
            }
        }
    }

    CSI_ASSERT( ret != -1 );

    return key[ ret ];
}

int csiStoredGroup::chooseKey( csiSGCursor * cursor, int count, int depth )
{
    int i;
    int j = -1;

    for( i = 0 ; i < count ; i ++)
    {
        if( !cursor[ i ].done )
        {
            if( j == -1 )
            {
                j = i;
            }
            else
            {
                if(cursor[i].pos[ depth ].key < cursor[j].pos[ depth ].key)
                {
                    j = i;
                }
            }
        }
    }

    return j;
}

void csiStoredGroup::drawStoredGroup()
{
    csiSGCursor cursor;

    initCursor( &cursor, CSI_POS_NODE );
    while( !cursor.done )
    {
        drawGroup( 
                (char*)cursor.pos[ CSI_POS_NODE ].key.body,
                (char*)cursor.pos[ CSI_POS_NODE ].subKey.body,
                0 );
        TEST( nextCursor( &cursor ) );
    }

    drawGroupEnd();

    destCursor( & cursor );

    return;

    EXCEPTION_END;

    CSI_ASSERT( false );
}


void csiStoredGroup::report()
{
    reportTable( 0 );
    rootMap->dump();
}

void csiStoredGroup::reportTable( int prefixPadding )
{
    int    i;

    REPORT( BAR_STR );
    REPORT( "\n" );
    flushResult.report( "StoredGroup:");
    lookupStat.report( prefixPadding );
    REPORT("\n");
}

void csiSGCursor::report()
{
    int i;

    REPORT("-------------- Cursor --------------\n");
    REPORT("subNo      : %d\n", subNo );
    REPORT("depth      : %d\n", depth );
    REPORT("done       : %d\n", done );
    REPORT("readCount  : %d\n", readCount );

    for( i = 0 ; i < depth ; i ++ )
    {
        pos[ i ].report();
        REPORT("\n");
    }
}
