#include <csiManager.h>
#include <csiMemGroup.h>
#include <csiStoredGroup.h>
#include <csiWorkerPool.h>
#include <csiPageManager.h>

int                                    csiManager::SIMaxCount;
int                                    csiManager::SICount;
int                                    csiManager::storedGroupLossValidation;
int                                    csiManager::storedGroupOrderValidation;
int                                    csiManager::memGroupCountForSwitch;
int                                    csiManager::flushWaitingMsec;
int                                    csiManager::nodeMergeThreshold;
int                                    csiManager::compactionGroupThreshold;
int                                    csiManager::compactionGroupCount;
int                                    csiManager::drawGroup;
string                                 csiManager::masterFN;
unordered_map<SimpleHash, csiSIInfo*>  csiManager::SIMap;
csiSimpleRWLock                        csiManager::siMapRWLock;
uint64_t                               csiManager::lastFlushTime = 0;

bool csiManager::init()
{
    SIMaxCount              = get_property_int("common","index_max_count");
    memGroupCountForSwitch  =
        get_property_int("group","memgroup_count_for_switch");
    SICount                 = 0;
    flushWaitingMsec        = get_property_int("group","flush_waiting_msec");
    nodeMergeThreshold      = get_property_int("group","node_merge_threshold");
    compactionGroupThreshold   =
        get_property_int("group","compaction_group_threshold");
    compactionGroupCount       =
        get_property_int("group","compaction_group_count");
    storedGroupLossValidation  =
        get_property_int("group","stored_group_loss_validation");
    storedGroupOrderValidation =
        get_property_int("group","stored_group_order_validation");
    drawGroup   = get_property_int("monitor","draw_group");
    masterFN    = get_property_string("io","master");

    CSI_ASSERT( nodeMergeThreshold <= MERGING_MAX );
    CSI_ASSERT( compactionGroupCount <= MERGING_MAX );

    CSI_SRWL_INIT( &siMapRWLock );
    CSI_ASSERT( memGroupCountForSwitch <= MEMGROUP_MAX );

    TEST( csiMemGroup::init() );
    TEST( csiStoredGroup::init() );

    csiWorkerPool::registRF( csiManager::report );

    return true;

    EXCEPTION_END;

    return false;
}
bool csiManager::dest()
{
    csiSIInfo    * SIInfo;
    bool           siMapLocked = false;
    SimpleHash     targetNameSH;

    siMapRWLock.WLock();
    siMapLocked = true;
    for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; )
    {
        SIInfo = itr->second;
        targetNameSH = getSimpleHash( strlen(SIInfo->SIName), SIInfo->SIName );
        TEST( dropInternal( SIInfo ) );
        itr ++;
        (void) SIMap.erase( targetNameSH );
    }
    siMapLocked = false;
    releaseSIMapLock();

    TEST( csiStoredGroup::dest() );
    TEST( csiMemGroup::dest() );
    siMapRWLock.dest();

    return true;

    EXCEPTION_END;

    if( siMapLocked )    releaseSIMapLock();

    return false;
}


int csiManager::createSI( int SINameLen, char * SIName )
{
    SimpleHash     target = getSimpleHash( SINameLen, SIName );
    csiSIInfo    * newSIInfo = NULL;
    csiSIInfo    * prevSIInfo = NULL;
    void         * newMemGroup;
    bool           siMapLocked = false;
    int            seq;
    int            i;
    int            createdMemGroupIdx = 0;;

    /* 이름 중복검사 */
    prevSIInfo  = chooseSI( SINameLen, SIName, true /*createDropSI*/ );
    siMapLocked = true;
    if( prevSIInfo != NULL )
    {
        prevSIInfo->report();
        LOG("SI NAME Conflict : %d vs %d=>[%d]%s", 
            getSimpleHash(
                strlen(prevSIInfo->SIName ),
                prevSIInfo->SIName ),
            target, SINameLen,SIName );
        TEST( prevSIInfo == NULL );
    }

    seq = __sync_add_and_fetch( & SICount, 1 );
    TEST_RAISE( seq <= SIMaxCount, INDEX_OVERFLOW ); /* 개수 체크 */

    /* SI(SecondaryIndex)Info 생성 */
//    TEST( CSI_MALLOC( sizeof( csiSIInfo ), (void**)(&newSIInfo) ) );
    newSIInfo = new csiSIInfo();

    newSIInfo->storedGroup            = NULL;
    csiMemset( newSIInfo->memGroup, 0, sizeof( void* ) * MEMGROUP_MAX );
    for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
    {
        TEST( ( newMemGroup = (void*)csiMemGroup::create() ) );
        createdMemGroupIdx = i;
        newSIInfo->memGroup[ i ] = newMemGroup;
    }
    newSIInfo->curMemGroupIdx       = 0;
    newSIInfo->flushMemGroupIdx     = 0;
    newSIInfo->keyCount             = 0;
    newSIInfo->unmergedGroupCount   = 0;
    newSIInfo->groupCount           = 0;

    newSIInfo->scanCount            = 0;
    newSIInfo->queryCount           = 0;
    newSIInfo->groupCompactionCount = 0;
    newSIInfo->rangeCompactionCount = 0;
    newSIInfo->nodeMergeCount       = 0;

    newSIInfo->flushWaitingCount    = 0;
    newSIInfo->switchByVB           = 0;
    newSIInfo->switchByVC           = 0;
    new ( &newSIInfo->lookupStat ) csiLookupStat;

    CSI_SRWL_INIT( &newSIInfo->switchLock );
    CSI_SRWL_INIT( &newSIInfo->mergeLock );
    memcpy( newSIInfo->SIName, SIName, min( NAME_LEN, SINameLen ) );
    newSIInfo->SIName[ min( NAME_LEN, SINameLen ) ] = '\0';

    SIMap[ target ] = newSIInfo;
    siMapLocked = false;

    storeMaster();

    releaseSIMapLock();

    LOG( "create SI success : %s -> [%d]", SIName, seq );

    return seq;

    EXCEPTION( INDEX_OVERFLOW );
    {
        LOG( "index overflow : %s ( %d >= %d )", SIName, seq, SIMaxCount );
        (void)__sync_sub_and_fetch( & SICount, 1 );
    }
    EXCEPTION_END;

    LOG( "create SI fail : %s", SIName );

    if( siMapLocked )    releaseSIMapLock();
    for( i = 0 ; i < createdMemGroupIdx ; i ++ )
    {
        csiMemGroup::drop( (csiMemGroup*)newSIInfo->memGroup[ i ] );
    }
    if( newSIInfo ) CSI_FREE( newSIInfo );

    return -1;
}
bool csiManager::drop(int SINameLen, char * SIName )
{
    bool           siMapLocked = false;
    csiSIInfo    * SIInfo = NULL;
    SimpleHash     targetNameSH;

    SIInfo = chooseSI( SINameLen, (char*)SIName, true /*XLock*/ );
    siMapLocked = true;

    targetNameSH = getSimpleHash( SINameLen, SIName);
    TEST( SIInfo );
    TEST( dropInternal(SIInfo) );
    (void) SIMap.erase( targetNameSH );

    storeMaster();

    siMapLocked = false;
    releaseSIMapLock();

    return true;

    EXCEPTION_END;

    if( siMapLocked == true )    releaseSIMapLock();

    return false;
}

bool csiManager::dropInternal( csiSIInfo * SIInfo )
{
    csiStoredGroup    * storedGroup;
    csiStoredGroup    * nextStoredGroup;
    bool                switchLocked= false;
    SimpleHash          targetNameSH;
    int                 i;

    /* WLock 잡혀있어야 함*/
    CSI_ASSERT( siMapRWLock.isWLock() );

    if( SIInfo != NULL )    
    {
        targetNameSH = getSimpleHash( strlen(SIInfo->SIName), SIInfo->SIName );

        LOG("drop SI %s[%d]",SIInfo->SIName, targetNameSH );

        SIInfo->switchLock.WLock();
        switchLocked = true;

        for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
        {
            if( SIInfo->memGroup[ i ] != NULL ) 
            {
                csiMemGroup::drop( (csiMemGroup*)SIInfo->memGroup[ i ] );
            }
        }
        storedGroup = (csiStoredGroup*)SIInfo->storedGroup;
        while( storedGroup != NULL )
        {
            nextStoredGroup = storedGroup->getNext();
            TEST( csiStoredGroup::remove(    SIInfo, 
                                         storedGroup->getRPID() ) );
            storedGroup = nextStoredGroup;
        }

        switchLocked = false;
        SIInfo->switchLock.release();
        SIInfo->switchLock.dest();
        SIInfo->mergeLock.dest();

        TEST( CSI_FREE( SIInfo ) );

        (void) __sync_add_and_fetch( & SICount, -1 );
        LOG("drop SUCCESS ");
    }

    //    drawAll("drop");

    return true;

    EXCEPTION_END;

    if( switchLocked )    SIInfo->switchLock.release();

    return false;
}

bool csiManager::insertKV( int           SINameLen,
                           const char  * SIName, 
                           uint          keyLen,
                           char        * keyBody,
                           uint          valLen,
                           char        * valBody,
                           uint          info )
{
    ByteArray              key;
    ByteArray              val;
    csiSIInfo            * targetSIInfo = NULL;
    csiMemGroup          * memGroup;
    int                    curMemGroupIdx;
    csiMemGroupResult      ret;
    bool                   siMapLocked = false;
    bool                   switchLocked = false;

    key.len     = keyLen;
    key.body    = (uchar*)keyBody;
    val.len     = valLen;
    val.body    = (uchar*)valBody;

    targetSIInfo = chooseSI( SINameLen, (char*)SIName, false );
    siMapLocked  = true;
    TEST( targetSIInfo );

    targetSIInfo->switchLock.RLock();
    switchLocked = true;
    while( true )
    {
        curMemGroupIdx = targetSIInfo->curMemGroupIdx;
        memGroup = (csiMemGroup*)targetSIInfo->memGroup[ curMemGroupIdx ];
        if( memGroup->getStatus() == CSI_MEMGROUP_STATUS_ACTIVE )
        {
            TEST( memGroup->insertAndSort(  key, val, info, &ret ) );

            if( ret== CSI_MEMGROUP_SUCCESS ) break;
            if( ret== CSI_MEMGROUP_FAIL_OVERFLOW_VB )targetSIInfo->switchByVB++;
            else                                     targetSIInfo->switchByVC++;

            switchLocked = false;
            targetSIInfo->switchLock.release();

            /* Flush & switch가 필요함 */
            switchMemGroup( targetSIInfo, curMemGroupIdx );
        }
        else
        {
            switchLocked = false;
            targetSIInfo->switchLock.release();
        }
        wait4Insert( targetSIInfo );

        targetSIInfo->switchLock.RLock();
        switchLocked = true;
    }
    atomicInc( &targetSIInfo->queryCount, 1 );
    atomicInc( &targetSIInfo->keyCount, 1 );
    switchLocked = false;
    targetSIInfo->switchLock.release();

    siMapLocked = false;
    releaseSIMapLock();

    return true;

    EXCEPTION_END;

    if( siMapLocked )    releaseSIMapLock();
    if( switchLocked )    targetSIInfo->switchLock.release();

    return false;
}

/*Read연산을 수행함*/
bool csiManager::readKV(ByteArray SIName, ByteArray key, ByteArray *val  )
{
    csiSIInfo       * si;
    bool              siMapLocked = false;
    bool              switchLocked = false;

    si = chooseSI( SIName.len,
                   (char*)SIName.body, 
                   false /* createDropSI */
                   );
    siMapLocked = true;
    TEST( si );

    si->switchLock.RLock();
    switchLocked = true;
    TEST( readInternal( si, key, val ) );

    switchLocked = false;
    si->switchLock.release();

    siMapLocked = false;
    releaseSIMapLock();

    return true;

    EXCEPTION_END;

    if( switchLocked == true )    si->switchLock.release();
    if( siMapLocked == true )    releaseSIMapLock();

    return false;
}


bool csiManager::readInternal( csiSIInfo * si, ByteArray key, ByteArray *val )
{
    csiMemGroup       * memGroup;
    csiStoredGroup    * storedGroup;
    int                 i;

    atomicInc( &si->queryCount, 1 );

    /* flush중인 MemGroup도 읽어야 할 수 있기에, 일단 다 읽어봄.
     * StoredGroup으로 Switch할때는, MemGroup의 switchLock이 막아줌 */
    for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
    {
        memGroup     = (csiMemGroup*)si->memGroup[ i ];

        memGroup->read( key, val );
    }
    storedGroup = (csiStoredGroup*)si->storedGroup;

    /* stored group에 대해 read 수행함 */
    while( storedGroup != NULL )
    {
        TEST( storedGroup->findKeyValue( key, val ) );

        storedGroup = storedGroup->getNext();
    }

    return true;

    EXCEPTION_END;

    return false;
}

bool    csiManager::softFlushAll()
{
    csiSIInfo *SIInfo;
    int        memGroupIdx;
    int        i;
    uint64_t   curTime = get_cur_microseconds();
    int        backgroundFlushTime = 
        get_property_int("monitor","background_flush");

    if( curTime-lastFlushTime > backgroundFlushTime*1000*1000 )
    {
        lastFlushTime = curTime;

        for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; itr ++ )
        {
            SIInfo = itr->second;
            memGroupIdx = SIInfo->curMemGroupIdx;
            switchMemGroup( SIInfo, memGroupIdx );
            for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
            {
                wait4Flush( SIInfo, i );
            }
        }
    }

    return true;
}

bool    csiManager::forceSwitchAndFlushAll()
{
    csiSIInfo            * SIInfo;
    int                      memGroupIdx;
    int                      i;

    for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; itr ++ )
    {
        SIInfo = itr->second;
        memGroupIdx = SIInfo->curMemGroupIdx;
        switchMemGroup( SIInfo, memGroupIdx );
        for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
        {
            wait4Flush( SIInfo, i );
        }
    }

    return true;
}


bool    csiManager::forceSwitchAndFlush( int SINameLen, const char * SIName )
{
    csiSIInfo            * SIInfo;
    int                    memGroupIdx;
    bool                   siMapLocked = false;
    int                    i;

    DEBUG("ForceSwitchAndFlush... %s\n",SIName );
    SIInfo = csiManager::chooseSI( SINameLen, (char*)SIName, false );
    siMapLocked = true;
    TEST( SIInfo );

    memGroupIdx = SIInfo->curMemGroupIdx;
    DEBUG("SwitchMemGroup.\n" );
    switchMemGroup( SIInfo, memGroupIdx );
    for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
    {
        DEBUG("wait for flush...: %d\n", i );
        wait4Flush( SIInfo, i );
    }

    siMapLocked = false;
    releaseSIMapLock();

    return true;

    EXCEPTION_END;

    if( siMapLocked == true )    releaseSIMapLock();

    return false;
}

bool    csiManager::forceCompactionAll()
{
    csiSIInfo            * SIInfo;
    int                      prevGroupCountInLevel;
    int                      prevGroupCount;
    int                      level;

    /* compaction이 disable 됨 */
    if( compactionGroupCount == 0 ) 
        return true;

    for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; itr ++ )
    {
        SIInfo = itr->second;
        /* Group이 하나될때가지 Compaction */
        while( SIInfo->groupCount > 1 )
        {
            prevGroupCount = SIInfo->groupCount;
            for( level = 0 ; level < 32 ; level ++ )
            {
                do
                {
                    prevGroupCountInLevel = SIInfo->groupCount;
                    TEST( compaction( SIInfo, compactionGroupCount, level ) );
                }
                while( prevGroupCountInLevel != SIInfo->groupCount );
            }
            if( prevGroupCount  == SIInfo->groupCount )    /* Level별로 SSTable들이 있어서, Compaction이 안됨 */
            {
                break;
            }
        }
        /* level과 무관한 Compaction 진행 */
        while( SIInfo->groupCount > 1 )
        {
            TEST( compaction( SIInfo, compactionGroupCount, -1 ) );
        }
    }

    return true;

    EXCEPTION_END;

    return false;
}


bool    csiManager::forceCompaction( int SINameLen, const char * SIName )
{
    csiSIInfo            * SIInfo;
    bool                   siMapLocked = false;
    int                    prevGroupCount;
    int                    prevGroupCountInLevel;
    int                    level;

    /* compaction이 disable 됨 */
    if( compactionGroupCount == 0 ) 
        return true;

    siMapLocked = true;
    TEST( ( SIInfo = csiManager::chooseSI( SINameLen, (char*)SIName, false ) ) );

    /* Group이 하나될때가지 Compaction */
    while( SIInfo->groupCount > 1 )
    {
        prevGroupCount = SIInfo->groupCount;
        for( level = 0 ; level < 32 ; level ++ )
        {
            do
            {
                prevGroupCountInLevel = SIInfo->groupCount;
                TEST( compaction( SIInfo, compactionGroupCount, level ) );
            }
            while( prevGroupCountInLevel != SIInfo->groupCount );
        }
        if( prevGroupCount  == SIInfo->groupCount )    /* Level별로 SSTable들이 있어서, Compaction이 안됨 */
        {
            break;
        }
    }
    /* level과 무관한 Compaction 진행 */
    while( SIInfo->groupCount > 1 )
    {
        TEST( compaction( SIInfo, compactionGroupCount, -1 ) );
    }

    siMapLocked = false;
    releaseSIMapLock();

    return true;

    EXCEPTION_END;

    if( siMapLocked == true )    releaseSIMapLock();

    return false;
}

bool    csiManager::forceRangeCompaction( int SINameLen, const char * SIName )
{
    return false;
}
bool    csiManager::forceNodeMergeAll()
{
    csiSIInfo            * SIInfo;

    /* nodeMerge가 disable 됨 */
    if(    nodeMergeThreshold == 0 )    return true;

    for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; itr ++ )
    {
        SIInfo = itr->second;
        /* 전부 nodeMerge */
        while( SIInfo->unmergedGroupCount > 1 )
        {
            TEST( nodeMerge( SIInfo ) );
        }
    }

    return true;

    EXCEPTION_END;

    return false;
}


bool    csiManager::forceNodeMerge( int SINameLen, const char * SIName )
{
    csiSIInfo          * SIInfo;
    bool                 siMapLocked = false;

    /* nodeMerge가 disable 됨 */
    if(    nodeMergeThreshold == 0 )    return true;

    siMapLocked = true;
    TEST( ( SIInfo = csiManager::chooseSI( SINameLen, (char*)SIName, false ) ) );

    /* 전부 nodeMerge */
    while( SIInfo->unmergedGroupCount > 1 )
    {
        TEST( nodeMerge( SIInfo ) );
    }

    siMapLocked = false;
    releaseSIMapLock();

    return true;

    EXCEPTION_END;

    if( siMapLocked == true )    releaseSIMapLock();

    return false;
}

uint64_t        csiManager::getSize( int SINameLen, const char * SIName )
{
    csiSIInfo            * SIInfo;
    csiMemGroup          * memGroup;
    csiStoredGroup       * sgPtr;
    bool                   siMapLocked = false;
    uint64_t               size = 0;
    int                    i;

    DEBUG("getSize... %s\n",SIName );
    SIInfo = csiManager::chooseSI( SINameLen, (char*)SIName, false );
    siMapLocked = true;
    if( SIInfo )
    {
        for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
        {
            memGroup = (csiMemGroup*)SIInfo->memGroup[ i ];
            size += memGroup->getLocalBufferCount() * PAGE_SIZE;
            wait4Flush( SIInfo, i );
        }
        sgPtr = (csiStoredGroup*)SIInfo->storedGroup;
        while( sgPtr != NULL )
        {
            size += sgPtr->getFlushResult()->flushedPageCount * PAGE_SIZE;
            sgPtr = sgPtr->getNext();
        }

        siMapLocked = false;
        releaseSIMapLock();

        return size;
    }

    CSI_ASSERT( siMapLocked == false );

    return 0;
}

uint64_t        csiManager::getMemgroupSize( int SINameLen, const char * SIName )
{
    csiSIInfo              * SIInfo;
    csiMemGroup            * memGroup;
    bool                     siMapLocked = false;
    uint64_t                 size = 0;
    int                      i;

    DEBUG("getSize... %s\n",SIName );
    SIInfo = csiManager::chooseSI( SINameLen, (char*)SIName, false );
    siMapLocked = true;
    if( SIInfo )
    {
        for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
        {
            memGroup = (csiMemGroup*)SIInfo->memGroup[ i ];
            size += memGroup->getLocalBufferCount() * PAGE_SIZE;
            wait4Flush( SIInfo, i );
        }
        siMapLocked = false;
        releaseSIMapLock();

        return size;
    }

    CSI_ASSERT( siMapLocked == false );

    return 0;
}


bool    csiManager::flushMemGroup( csiSIInfo * info )
{
    csiMemGroup        * memGroup;
    int                  targetMemGroup;
    KVIterator           itr;
    bool                 flushLocked= false;
    bool                 switchLocked= false;
    int                  flushedCnt = 0;
    csiFlushResult       flushResult;
    csiStoredGroup     * resultStoredGroup;
    ByteArray            _ba;

    /* Flush할 대상을 얻어옴 */
    info->switchLock.WLock();
    switchLocked = true;
    targetMemGroup = circularInc(    &info->flushMemGroupIdx, 
                                 memGroupCountForSwitch );
    switchLocked = false;
    info->switchLock.release();

    memGroup = (csiMemGroup*)info->memGroup[ targetMemGroup ];
    CSI_ASSERT( memGroup->getStatus() == CSI_MEMGROUP_STATUS_FLUSHING );

    /* Flush 준비. lock잡고 pageManger 초기화함 */
    csiPageManager::flushLock();
    flushLocked = true;
    LOG("flush begin : %s", info->SIName );

    TEST( csiPageManager::flushBegin( memGroup->getKeyCount() ) );
    itr = memGroup->beginScan();
    _ba.alloc( CSI_BA_POOL_MEMGROUP );
    while( memGroup->isEndScan( &itr ) == false )
    {
        /* MemGroup으로 부터 정렬된 keyValue가져와서 flush*/
        memGroup->readInternal( itr, &_ba );
        TEST( csiPageManager::insertKV((ByteArray*)&(itr->first), &_ba) );
        itr ++;
        flushedCnt ++;
    }
    _ba.free();
    TEST( csiPageManager::flushEnd( "FLUSH", &flushResult ) );

    CSI_ASSERT( flushedCnt == memGroup->getKeyCount() );
    CSI_ASSERT( flushResult.KVCount == memGroup->getKeyCount() );

    /* Flush정보를 바탕으로 StoredGroup을 만들고 연결함  */
    info->switchLock.WLock();
    switchLocked = true;
    if( flushedCnt )    
    {
        TEST( csiStoredGroup::add( info, &flushResult ) );
        resultStoredGroup = *csiStoredGroup::find( 
            info, flushResult.lastRootPID );

        if( storedGroupLossValidation )
        {
            CSI_ASSERT( validationUsingMemGroup( info, memGroup ) );
        }
        if( storedGroupOrderValidation )
        {
            CSI_ASSERT( validationOrder( info,  resultStoredGroup ) );
        }

        storeMaster();
    }
    memGroup->clear();
    CSI_ASSERT( memGroup->changeStatus(
            CSI_MEMGROUP_STATUS_FLUSHING,
            CSI_MEMGROUP_STATUS_ACTIVE ) );

    switchLocked = false;
    info->switchLock.release();

    drawAll("flush");

    LOG("flush done: %s ( %d count )", info->SIName, flushedCnt );
    flushLocked = false;
    csiPageManager::flushUnlock();

    /* threshold에 따라, nodeMerge,Compaction 수행 */
    if( ( info->unmergedGroupCount >= nodeMergeThreshold ) &&
       ( nodeMergeThreshold > 0 ) )    /*nodeMerge활성화되어야*/
    {
        TEST( nodeMerge( info ) );
    }

    if( ( info->groupCount >= compactionGroupThreshold ) &&
       ( compactionGroupCount > 0 ) &&
       ( compactionGroupThreshold > 0 ) ) /*compaction활성화 되어야 */
    {
        TEST( compaction( info, compactionGroupCount, 0 /*level */ ) );
    }

    return true;

    EXCEPTION_END;

    report();

    if( flushLocked  )    csiPageManager::flushUnlock();
    if( switchLocked )    info->switchLock.release();

    return false;
}

bool    csiManager::nodeMerge( csiSIInfo * info )
{
    bool                  flushLocked= false;
    bool                  mergeLocked= false;
    bool                  switchLocked= false;
    csiSGCursor           sgCursor[ MERGING_MAX ];
    csiStoredGroup      * sgPtr;
    csiStoredGroup      * storedGroup[ MERGING_MAX ];
    csiStoredGroup      * resultStoredGroup;
    csiPos              * nodePos[ MERGING_MAX ];
    csiPos              * minNodePos;
    int                   targetGroupCount = 0;
    char                * pageBuf[ MERGING_MAX ];
    csiSlotDir          * subSlotDir[ MERGING_MAX ];
    csiPageID             prevPID;
    bool                  ret;
    int                   size = 0;
    int                   estiSize;
    int                   minSG;
    int                   tryCount = 0;
    csiFlushResult        flushResult;
    int                   ratio;
    int                   prevRatio = 0;
    int                   estimatedDPageCount = 0;
    int                   i;

    /*************** preparation ***************/
    /* 억지로 진행할 필요 없다. */
    if( !info->mergeLock.tryWLock() )    return true;
    mergeLocked = true;

    csiPageManager::flushLock();
    flushLocked = true;

    /* NodeMerge 대상 Group을 선정함 */
    info->switchLock.RLock();
    switchLocked = true;

    targetGroupCount = 0;
    sgPtr = (csiStoredGroup*)info->storedGroup;
    for( i = 0 ; i < nodeMergeThreshold ; )
    {
        if( sgPtr == NULL ) break; /* found all */

        if( sgPtr->getNodeMergeLevel() > 1 )
        {    /* 이미 nodeMerge 됨 */
            sgPtr = sgPtr->getNext();
            continue;
        }

        /* Cursor를 초기화함 */
        sgPtr->initCursor( &sgCursor[ i ], CSI_POS_NODE );
        /* keyArray의 중간 모습을 만들 페이지 버퍼를 할당받는다.
         * 각각의 KeyArray를 만들고 총 크기가 Page보다 크면 Flush*/
        TEST( pageBuf[i] = csiPageManager::getVictimBuffer( true/*retry*/) );

        nodePos[ i ]  = &sgCursor[ i ].pos[ CSI_POS_NODE ];
        subSlotDir[i] = (csiSlotDir*)pageBuf[i];
        subSlotDir[i]->init( CSI_SD_KEY_ARRAY, pageBuf[i] + PAGE_SIZE );
        storedGroup[i] = sgPtr;
        estimatedDPageCount += sgPtr->getPageCount( CSI_PAGE_TYPE_DPAGE );
        sgPtr = sgPtr->getNext();
        i++;
        targetGroupCount ++;
    }

    switchLocked = false;
    info->switchLock.release();

    if( targetGroupCount > 0 )
    {
        LOG("nodeMerge begin : %s - estimatedDPageCount:%d", 
            info->SIName, estimatedDPageCount );

        for( i = 0 ; i < targetGroupCount ; i ++)
        {
            REPORT("\t%2d[Root:%-8d DPageCount:%-9d] ",
                    i, 
                    storedGroup[i]->getRPID(),
                    storedGroup[i]->getPageCount( CSI_PAGE_TYPE_DPAGE ) );
            REPORT("Level : %d/%d ", 
                    storedGroup[i]->getGroupMergeLevel(),
                    storedGroup[i]->getNodeMergeLevel() );
            REPORT("\n");
        }

        TEST( csiPageManager::flushBegin() );

        /*********** stored group에 대해 DPID 및 Key수집 ***********/
        while( true )
        {
            minSG = csiStoredGroup::chooseKey( 
                sgCursor, targetGroupCount, CSI_POS_NODE );
            if( minSG == -1 )
            {
                /* 모든 NodeKey에 대한 Scan끝. 마지막 남은 부분 Flush */
                TEST( csiPageManager::insertKeyArrayToNode( 
                        (csiSlotDir**)subSlotDir, targetGroupCount ) );
                break;
            }

            minNodePos = nodePos[ minSG ];

            tryCount ++;
            /* 삽입을 시도함 */
            while( true )
            {
                size = sizeof( csiPageHeader );

                /* 삽입 가능한지 공간 검사함*/
                for( i = 0 ; i < targetGroupCount ; i ++)
                {
                    size += sizeof( csiOffset )
                            + subSlotDir[ i ]->getUsedSize( 1/*align*/ )
                            + (CSI_ALIGN - 1);

                    if( i == minSG )/*여기에 삽입시 마지막Slot은 제거 후 삽입*/
                    {
                        size -=subSlotDir[ i ]->getLastSlotSize();
                    }
                }
                estiSize = 
                    csiSlotDir::getCompactBASize( &minNodePos->key ) + 
                    csiSlotDir::getCompactBASize( &minNodePos->subKey );

                /* 삽입 가능함 */
                if( ( size + estiSize < PAGE_SIZE ) &&
                   ( subSlotDir[ minSG ]->isSlotLimit() == false ) )
                {
                    TEST( csiPageManager::insertToKeyArray( 
                            subSlotDir[ minSG ],
                            minNodePos->key,
                            minNodePos->subKey,
                            minNodePos->PID,
                            &ret ) );
                    if( ret == true )
                    {
                        break;
                    }
                    /* 삽입 가능한 공간이 남았음에도, 삽입실패할 수 있다.
                     * KeyArray는 Key들의 PID가 연속적이지 않을 경우
                     * 삽입하지 않기 때문이다. */
                }

                /* over flow, 작업된 keyArray들을 Node에 삽입. */
                TEST( csiPageManager::insertKeyArrayToNode( 
                        (csiSlotDir**)subSlotDir, targetGroupCount ) );
                /* 초기화 */
                for( i = 0 ; i < targetGroupCount ; i ++)
                {
                    /* 이전 PID 잠시 백업함. init에서 지워지니까 */
                    prevPID = subSlotDir[ i ]->prevPID;
                    subSlotDir[i]->init( 
                        CSI_SD_KEY_ARRAY, pageBuf[i] + PAGE_SIZE );
                    subSlotDir[ i ]->prevPID = prevPID;
                }
                /* 루프를 돌아 다시 삽입함 */
            }

            TEST( storedGroup[ minSG ]->nextCursor( &sgCursor[ minSG ] ) );

            ratio = ( tryCount )*100 / estimatedDPageCount ;
            if( ratio != prevRatio )
            {
                REPORT("\r%3d%% %9d/%-9d", 
                        ratio, tryCount, estimatedDPageCount );
                printf("\r%3d%% %9d/%-9d", 
                        ratio, tryCount, estimatedDPageCount );
                fflush(stdout);

                prevRatio = ratio;
            }
        }
        TEST( csiPageManager::flushEnd( "nodeMerge", &flushResult ) );

        REPORT("\n");
        printf("\n");
        REPORT("Done:\n");

        for( i = 0 ; i < targetGroupCount ; i ++)
        {
            storedGroup[i]->destCursor( &sgCursor[ i ] );
            csiPageManager::releaseVictimBuffer( pageBuf[i] );
        }

        if( tryCount )
        {    /* nodeMerge 한것이 있다면 */
            info->switchLock.WLock();
            switchLocked = true;

            flushResult.nodeMergeLevel = targetGroupCount;

            /* 기존의 Group들은 Node가 무의미해졌음. 제거함. */
            for( i = 0 ; i < targetGroupCount ; i ++)
                flushResult.add4nodeMerge( i,storedGroup[i]->getFlushResult());
            TEST( csiStoredGroup::add(     info, &flushResult ) );
            resultStoredGroup = *csiStoredGroup::find( 
                info, flushResult.lastRootPID );

            if( storedGroupLossValidation )
                for( i = 0 ; i < targetGroupCount ; i ++)
                    CSI_ASSERT( validationUsingStoredGroup( 
                            info, storedGroup[ i ], resultStoredGroup ) );
            if( storedGroupOrderValidation )
                CSI_ASSERT( validationOrder( info,  resultStoredGroup ) );

            for( i = 0 ; i < targetGroupCount ; i ++)
                TEST( csiStoredGroup::remove( info,storedGroup[i]->getRPID()));
            storeMaster();

            switchLocked = false;
            info->switchLock.release();
        }

        info->nodeMergeCount ++;
        LOG("nodeMerge end : %s", info->SIName );
    }
    else
    {
        LOG("nodeMerge cancel : %s", info->SIName );
    }

    drawAll("nodeMerge");

    flushLocked = false;
    csiPageManager::flushUnlock();

    mergeLocked = false;
    info->mergeLock.release();

    return true;

    EXCEPTION_END;

    report();

    for( i = 0 ; i < targetGroupCount ; i ++)
    {
        storedGroup[i]->destCursor( &sgCursor[ i ] );

        csiPageManager::releaseVictimBuffer( pageBuf[i] );
    }

    if( flushLocked  )    csiPageManager::flushUnlock();
    if( mergeLocked )    info->mergeLock.release();
    if( switchLocked )    info->switchLock.release();

    return false;
}

bool    csiManager::compaction( csiSIInfo    * info,
                                int              targetCount,
                                int              level,
                                ByteArray    * beginKey,
                                ByteArray    * endKey,
                                int           nodeCount )
{
    bool                  flushLocked= false;
    bool                  mergeLocked= false;
    bool                  switchLocked= false;
    bool                  needOpenCursor;
    bool                  foundEnd;
    csiSGCursor           sgCursor[ MERGING_MAX ];
    csiStoredGroup      * sgPtr;
    csiStoredGroup      * resultStoredGroup;
    csiPos              * dataPos[ MERGING_MAX ];
    csiPos              * minDataPos;
    csiPageID             nodePID[ MERGING_MAX ][2];
    int                   targetGroupCount = 0;
    int                   minSG;
    int                   KVCount = 0;
    int                   mergeCount = 0;
    int                   estimatedKeyCount = 0;
    int                   newGroupMergeLevel = level + 1;
    csiFlushResult        flushResult;
    csiFlushResult        newFlushResult[ MERGING_MAX ];
    ByteArray             prevKey;        /* order 검증 및 merge용 */
    ByteArray             prevVal;        /* order 검증 및 merge용 */
    uint64_t              beginTime;
    uint64_t              endTime;
    int                   ratio;
    int                   prevRatio = 0;
    int                   i;
    int                   j;

    CSI_ASSERT( targetCount <= MERGING_MAX );
    if( targetCount == 0 ) targetCount = MERGING_MAX;

    /*************** preparation ***************/
    /* 억지로 진행할 필요 없다. */
    if( !info->mergeLock.tryWLock() )    return true;
    mergeLocked = true;

    csiPageManager::flushLock();
    flushLocked = true;

    /* Compaction 대상 Group을 선정함 */
    info->switchLock.RLock();
    switchLocked = true;

    prevKey.alloc( CSI_BA_POOL_COMPACTION );
    prevVal.alloc( CSI_BA_POOL_COMPACTION );

    targetGroupCount = 0;
    sgPtr = (csiStoredGroup*)info->storedGroup;
    for( i = 0 ; i < targetCount ; )
    {
        /* 더이상 없는 경우 */
        if( sgPtr == NULL ) break;
        if( ( sgPtr->getGroupMergeLevel() != level ) && ( level != -1 ) ) 
        {
            sgPtr = sgPtr->getNext();
            continue;
        }


        if( i + sgPtr->getNodeMergeLevel() > targetCount ) break;

        estimatedKeyCount += sgPtr->estimatedKeyCount( nodeCount );

        /* cursor를 초기화함 */
        for( j = 0 ; j < sgPtr->getNodeMergeLevel() ; j ++ )
        {
            sgPtr->initCursor( &sgCursor[i], CSI_POS_DATA, true/*mpr*/,
                               j, beginKey );
            nodePID[i][0]=NULL_PID;
            nodePID[i][1]=NULL_PID;
            needOpenCursor=false;
            if( !sgCursor[ i ].done )
            {
                if( beginKey == NULL )
                {
                    needOpenCursor=true;
                }
                else
                {
                    /* Node내 첫번째 key부터 읽도록 조작함 */
                    TEST( sgPtr->readFromPage( 
                            sgCursor[ i ].pos[ CSI_POS_ROOT ].PID,
                            CSI_PAGE_TYPE_NODE,
                            0/*seq*/,
                            &sgCursor[ i ].pos[ CSI_POS_NODE ],
                            j ) );
                    nodePID[i][0] = sgCursor[ i ].pos[ CSI_POS_ROOT ].PID;
                    if( j > 0 )
                    {
                        CSI_ASSERT( nodePID[i][0] == nodePID[i-1][0] );
                    }
                    if( sgCursor[ i ].pos[ CSI_POS_NODE ].ret )
                    {
                        TEST( sgPtr->readFromPage( 
                                sgCursor[ i ].pos[ CSI_POS_NODE ].PID,
                                CSI_PAGE_TYPE_DPAGE,
                                0/*seq*/,
                                &sgCursor[ i ].pos[ CSI_POS_DATA ],
                                j ) );
                        
                        if( sgCursor[ i ].pos[ CSI_POS_DATA ].ret )
                        {
                            needOpenCursor = true;
                        }
                    }
                }
            }
            if( needOpenCursor )
            {
                nodePID[i][1] = NULL_PID;
                dataPos[i]    = &sgCursor[ i ].pos[ CSI_POS_DATA ];
                i++;
            }
            else
            {
                sgPtr->destCursor( &sgCursor[ i ] );
            }
        }
        sgPtr = sgPtr->getNext();
    }
    targetGroupCount = i;
    switchLocked = false;
    info->switchLock.release();

    if( targetGroupCount <= 1 )    /* Compaction할 대상이 없음 */
    {
        for( i = 0 ; i < targetGroupCount ; i ++)    
        {
            sgPtr = (csiStoredGroup*)sgCursor[ i ].targetSGPtr;
            sgPtr->destCursor( &sgCursor[ i ] );
        }
    }
    else
    {
        LOG("compaction begin : %s - estimatedKeyCount:%d", 
                info->SIName, estimatedKeyCount );
        REPORT("compaction info:\n");
        if( !beginKey->isNull() ) 
        {
            REPORT("BeginKey:");
            beginKey->dump();
            REPORT("\n");
        }
        if( !endKey->isNull() ) 
        {
            REPORT("endKey  :");
            endKey->dump();
            REPORT("\n");
        }


        for( i = 0 ; i < targetGroupCount ; i ++)
        {
            sgPtr = (csiStoredGroup*)sgCursor[ i ].targetSGPtr;
            REPORT("\t%2d[%10d/%10d] ",
                   i, 
                   nodePID[i][0],
                   nodePID[i][1] );
            if( sgCursor[ i ].subNo == 0 )
            {
                REPORT("  [Root:%-8d Esti.Cnt:%-9d KeyCnt:%-9d subNo:%d] ",
                       sgPtr->getRPID(),
                       sgPtr->estimatedKeyCount( nodeCount ),
                       sgPtr->getKeyCount(),
                       sgCursor[ i ].subNo );
                REPORT("Level : %d(%d) ", 
                       sgPtr->getGroupMergeLevel(),
                       level );
            }
            else
            {
                REPORT("  [subNo:%d] ",
                       sgCursor[ i ].subNo );
            }
            if( !beginKey->isNull() ) 
            {
                REPORT("BeginKey:");
                beginKey->dump();
            }
            if( !endKey->isNull() ) 
            {
                REPORT("  endKey:");
                endKey->dump();
            }
            REPORT("\n");
        }


        /************* MinKey를 읽어 새로운 Group에 삽입 ************/
        TEST( csiPageManager::flushBegin( estimatedKeyCount ) );
        while( true )
        {
            minSG = csiStoredGroup::chooseKey( 
                sgCursor, targetGroupCount, CSI_POS_DATA );
            if( minSG == -1 )
            {
                /* 추출 다했으니, prevKey로 가지고 있는 것을 삽입함*/
                if( prevKey.len > 0 )
                {
                    KVCount ++;
                    TEST( csiPageManager::insertKV( &prevKey, &prevVal ) );
                }
                break;
            }

            minDataPos = dataPos[ minSG ];

            /* Deleted KeyValue */
            if( minDataPos->subKey.len == 0 )
            {
                prevKey.len = 0;
                prevVal.len = 0;
            }
            else
            {
                if( prevKey.len > 0 )
                {
                    CSI_ASSERT( !( minDataPos->key < prevKey) );
                    if( prevKey == minDataPos->key )
                    {
                        /* merge가 필요함 */
                        CSI_ASSERT( prevVal.merge( &minDataPos->subKey ) );
                        mergeCount ++;
                    }
                    else
                    {
                        /* 새로운 key 찾음. 기존 key flush후, 새 key read */
                        KVCount ++;
                        TEST( csiPageManager::insertKV( &prevKey, &prevVal ) );

                        if( (!endKey->isNull() ) && 
                           ( minDataPos->key == *endKey ) )
                        {
                            /* 현 커서가 읽는 노드까지만 Compaction한다. */
                            for( i = 0 ; i < targetGroupCount ; i ++ )
                            {
                                nodePID[i][1] = sgCursor[i].pos[CSI_POS_ROOT].PID;
                            }
                            endKey = NULL;
                        }
                        prevKey.copyFrom( &minDataPos->key );
                        prevVal.copyFrom( &minDataPos->subKey );
                    }
                }
                else
                {
                    /* 최초 read */
                    prevKey.copyFrom( &minDataPos->key );
                    prevVal.copyFrom( &minDataPos->subKey );
                }
            }
            ByteArray::validationColumn( prevVal.body );
            sgPtr = (csiStoredGroup*)sgCursor[ minSG ].targetSGPtr;
            TEST( sgPtr->nextCursor( &sgCursor[ minSG ] ) );

            /* endKey가 속한 Node 다 읽음. done */
            if( ( nodePID[minSG][1] != NULL_PID ) &&
                ( sgCursor[minSG].pos[CSI_POS_ROOT].PID != nodePID[minSG][1]))
            {
                sgCursor[minSG].done = true;
            }

            ratio = ( KVCount + mergeCount )*100 / estimatedKeyCount ;
            if( ratio != prevRatio )
            {
                REPORT("\r%3d%% %9d/%-9d   time ( %d/%d) sec      ", 
                        ratio, KVCount + mergeCount, estimatedKeyCount,
                        csiPageManager::flushElapsedSec(), 
                        csiPageManager::flushEstimationSec() );
                printf("\r%3d%% %9d/%-9d   time ( %d/%d) sec      ", 
                        ratio, KVCount + mergeCount, estimatedKeyCount,
                        csiPageManager::flushElapsedSec(), 
                        csiPageManager::flushEstimationSec() );
                fflush(stdout);

                prevRatio = ratio;
            }
        }
        TEST( csiPageManager::flushEnd( "GROUP_COMPACTION", &flushResult ) );

        REPORT("\n");
        printf("\n");

        /************* Group을 등록 및 재정리 ************/
        REPORT("Done:\n");
        for( i = 0 ; i < targetGroupCount ; i ++)    
        {
            sgPtr = (csiStoredGroup*)sgCursor[ i ].targetSGPtr;
            REPORT("\t%2d[%10d/%10d] ",
                   i, 
                   nodePID[i][0],
                   nodePID[i][1] );
            if( sgCursor[ i ].subNo == 0 )
            {
                REPORT("\t%2d[Root:%-8d Esti.Cnt:%-9d KeyCnt:%-9d subNo:%d]\n",
                       i, 
                       sgPtr->getRPID(),
                       sgPtr->estimatedKeyCount( nodeCount ),
                       sgPtr->getKeyCount(),
                       sgCursor[ i ].subNo );
                TEST( sgPtr->rootRewrite( 
                   nodePID[ i ][0], nodePID[ i ][1], &newFlushResult[ i ] ) );
            }
            else
            {
                REPORT("  [subNo:%d]\n",
                       sgCursor[ i ].subNo );
            }

            sgPtr->destCursor( &sgCursor[ i ] );
        }
        REPORT("\t  [Sum ReadCnt:%-9d FlushCnt:%-9d MergeCnt:%-9d]\n",
                KVCount,
                flushResult.KVCount,
                mergeCount );

        /* 원본의 shrink된 root로의 교체와, 새 Group추가를 동시에 수행*/
        info->switchLock.WLock();
        switchLocked = true;

        /* 새로운 Group 삽입 */
        flushResult.groupMergeLevel = newGroupMergeLevel;
        TEST( csiStoredGroup::add( info, &flushResult ) );
        resultStoredGroup = * csiStoredGroup::find( 
                info, flushResult.lastRootPID );

        if( storedGroupOrderValidation )
        {
            CSI_ASSERT( validationOrder( info,  resultStoredGroup ) );
        }

        for( i = 0 ; i < targetGroupCount ; i ++)
        {
            if( sgCursor[ i ].subNo == 0 )
            {
                sgPtr = (csiStoredGroup*)sgCursor[ i ].targetSGPtr;
                if( newFlushResult[ i ].flushedPageCount == 0 )
                {    /*완전히 날림 */
                    info->groupCompactionCount ++;
                    TEST( csiStoredGroup::remove( info, 
                                                  sgPtr->getRPID() ) );
                }
                else
                {
                    info->rangeCompactionCount ++;
                    TEST( sgPtr->changeRoot(
                            &newFlushResult[ i ],
                            sgCursor[ i ].readCount ) );
                }
            }
        }

        storeMaster();

        switchLocked = false;
        info->switchLock.release();

        drawAll("compaction");

        LOG("compaction done: %s ( %d count, %d merged )", 
                info->SIName, KVCount, mergeCount );
    }

    flushLocked = false;
    csiPageManager::flushUnlock();

    mergeLocked = false;
    info->mergeLock.release();

    prevKey.free();
    prevVal.free();

    return true;

    EXCEPTION_END;

    report();

    for( i = 0 ; i < targetGroupCount ; i ++)    
    {
        sgPtr = (csiStoredGroup*)sgCursor[ i ].targetSGPtr;
        sgPtr->destCursor( &sgCursor[ i ] );
    }

    if( flushLocked  )    csiPageManager::flushUnlock();
    if( mergeLocked )    info->mergeLock.release();
    if( switchLocked )    info->switchLock.release();

    prevKey.free();
    prevVal.free();

    return false;
}

bool csiManager::validationUsingMemGroup( csiSIInfo * SI, 
                                          csiMemGroup * memGroup )
{
    KVIterator         itr;
    ByteArray          key;
    ByteArray          val;

    val.alloc( CSI_BA_POOL_MEM_VALIDATION );

    itr = memGroup->beginScan();
    while( memGroup->isEndScan( &itr ) == false )
    {
        val.len = 0;
        key = itr->first;
        TEST( readInternal( SI, key, &val ) );
        TEST( val == itr->second );
        itr ++;
    }

    val.free();

    return true;

    EXCEPTION_END;

    REPORT("validation error : \n");
    REPORT("key    ");
    key.dump(8192);
    REPORT("\nval    ");
    val.dump(8192);
    REPORT("\nsource ");
    itr->second.dump(8192);
    REPORT("\n");

    val.free();

    CSI_ASSERT( false );
}

bool csiManager::validationUsingStoredGroup(    csiSIInfo         * SI, 
                                                csiStoredGroup    * src,
                                                csiStoredGroup    * ret )
{
    csiSGCursor       sgCursor;
    csiPos          * pos;
    ByteArray         val;

    val.alloc( CSI_BA_POOL_STORED_VALIDATION );

    /* src를 바탕으로 ret를 검증함 */
    src->initCursor( &sgCursor);
    pos = &sgCursor.pos[ CSI_POS_DATA ];
    while( !sgCursor.done )
    {
        TEST( ret->findKeyValue( pos->key, &val ) );
        TEST( pos->subKey == val );
        TEST( src->nextCursor( & sgCursor ) );
    }
    src->destCursor( &sgCursor );
    val.free();

    return true;

    EXCEPTION_END;

    sgCursor.report();
    REPORT("validation error : \n");
    REPORT("key    ");
    pos->key.dump(8192);
    REPORT("\nsource ");
    pos->subKey.dump(8192);
    REPORT("\nval    ");
    val.dump(8192);
    REPORT("\n");

    val.free();

    CSI_ASSERT( false );
}

bool csiManager::validationOrder(   csiSIInfo         * SI, 
                                    csiStoredGroup    * target )
{
    csiSGCursor       sgCursor[ MERGING_MAX ];
    csiPos          * dataPos[ MERGING_MAX ];
    int               minSG;
    csiPos          * minDataPos;
    ByteArray         prevKey;        /* order 검증 및 merge용 */
    int               i = 0;
    int               j = 0;

    prevKey.alloc( CSI_BA_POOL_STORED_VALIDATION );

    for( j = 0 ; j < target->getNodeMergeLevel() ; j ++ )
    {
        target->initCursor( &sgCursor[j], CSI_POS_DATA, true/*mpr*/, j);
        dataPos[j] = &sgCursor[j].pos[ CSI_POS_DATA ];
    }
    while( true )
    {
        minSG = csiStoredGroup::chooseKey( 
            sgCursor, target->getNodeMergeLevel(), CSI_POS_DATA );
        if( minSG == -1 )
        {
            break;
        }
        minDataPos = dataPos[ minSG ];

        i ++;
        if( prevKey.len > 0 )
        {
            TEST( !( minDataPos->key < prevKey ) );
        }
        prevKey.copyFrom( &minDataPos->key );
        TEST( target->nextCursor( & sgCursor[ minSG ] ) );

    }
    for( j = 0 ; j < target->getNodeMergeLevel() ; j ++ )
    {
        target->destCursor( &sgCursor[ j ] );
    }
    prevKey.free();


    CSI_ASSERT( i == target->getKeyCount() );

    prevKey.free();

    return true;

    EXCEPTION_END;

    sgCursor[ minSG ].report();
    REPORT("order validation error : \n");
    REPORT("key        ");
    minDataPos->key.dump(8192);
    REPORT("\nprevKey    ");
    prevKey.dump(8192);
    REPORT("\n");
    prevKey.free();

    CSI_ASSERT( false );
}
void csiSIInfo::reportDetail()
{
    csiMemGroup       * memGroupPtr;
    csiStoredGroup    * storedGroupPtr;
    int                 prefixPadding = 10;
    csiFlushResult      flushResult;
    int                 i;

    REPORT( DOUBLE_BAR_STR );
    REPORT( "\n" );
    REPORT(    "%20s : %s\n"
            "%20s : %d\n"
            "%20s : %d\n"
            "%20s : %d\n"
            "%20s : %8d/%8d\n"
            "%20s : %d\n"
            "%20s : %8d/%8d\n"
            "%20s : %d\n"
            "%20s : %d\n"
            "%20s : %d\n"
            "%20s : %d\n"
            "%20s : %d\n"
            "switchLock:",
            "SIName",            SIName,
            "KeyCount",          keyCount ,
            "ScanCount",         scanCount ,
            "QueryCount",        queryCount ,
            "MemGroupID",        curMemGroupIdx ,flushMemGroupIdx ,
            "FlushWaitCount",    flushWaitingCount,
            "switch(VB,VC)",     switchByVB,        switchByVC,
            "GroupCount",        groupCount,
            "Unmerged",          unmergedGroupCount,
            "GroupCompaction",   groupCompactionCount,
            "RangeCompaction",   rangeCompactionCount,
            "NodeMerge",         nodeMergeCount );

    switchLock.report();
    REPORT("\n");
    lookupStat.report();


    flushResult.flushedPageCount = 0;
    csiMemset( &flushResult.pageCount, 0, sizeof( int) * CSI_PAGE_TYPE_MAX );

    storedGroupPtr = (csiStoredGroup*)storedGroup;
    while( storedGroupPtr != NULL )
    {
        flushResult.flushedPageCount += 
            storedGroupPtr->getFlushResult()->flushedPageCount;
        for( i = 0 ; i < CSI_PAGE_TYPE_MAX ; i ++ )
            flushResult.pageCount[ i ] += 
                storedGroupPtr->getFlushResult()->pageCount[ i ];
        storedGroupPtr = storedGroupPtr->getNext();
    }

    REPORT("%20s : %d(D:%d N:%d R:%d, F:%d)\n",
            "PageCount",
            flushResult.flushedPageCount,
            flushResult.pageCount[ CSI_PAGE_TYPE_DPAGE ],
            flushResult.pageCount[ CSI_PAGE_TYPE_NODE ],
            flushResult.pageCount[ CSI_PAGE_TYPE_ROOT ],
            flushResult.pageCount[ CSI_PAGE_TYPE_FILTER ] );

    REPORT( BAR_STR );
    REPORT( BAR_STR );
    REPORT( "\n" );

    csiMemGroup::reportNaming( prefixPadding );
    for( i = 0 ; i < csiManager::getMemGroupCountForSwitch() ; i ++ )
    {
        memGroupPtr = (csiMemGroup*)(memGroup[i]);
        if( memGroupPtr )
        {
            memGroupPtr->reportTable( prefixPadding );
        }
    }
    storedGroupPtr = (csiStoredGroup*)storedGroup;
    while( storedGroupPtr != NULL )
    {
        storedGroupPtr->reportTable( prefixPadding );
        storedGroupPtr = storedGroupPtr->getNext();
    }

}
void csiSIInfo::reportSimple()
{
    csiStoredGroup    * storedGroupPtr;
    csiFlushResult      flushResult;
    int                 i;

    REPORT("%10s KEY:%8d  QUERY:%8d,%8d GROUP:%8d(U:%d, G:%d, R:%d, N:%d) ",
            SIName,
            keyCount,
            queryCount,
            scanCount,
            groupCount,
            unmergedGroupCount,
            groupCompactionCount,
            rangeCompactionCount,
            nodeMergeCount );

    flushResult.flushedPageCount = 0;
    csiMemset( &flushResult.pageCount, 0, sizeof( int) * CSI_PAGE_TYPE_MAX );

    storedGroupPtr = (csiStoredGroup*)storedGroup;
    while( storedGroupPtr != NULL )
    {
        flushResult.flushedPageCount += 
            storedGroupPtr->getFlushResult()->flushedPageCount;
        for( i = 0 ; i < CSI_PAGE_TYPE_MAX ; i ++ )
            flushResult.pageCount[ i ] += 
                storedGroupPtr->getFlushResult()->pageCount[ i ];
        storedGroupPtr = storedGroupPtr->getNext();
    }

    REPORT("%10s : %d(D:%d N:%d R:%d, F:%d)\n",
            "PageCount",
            flushResult.flushedPageCount,
            flushResult.pageCount[ CSI_PAGE_TYPE_DPAGE ],
            flushResult.pageCount[ CSI_PAGE_TYPE_NODE ],
            flushResult.pageCount[ CSI_PAGE_TYPE_ROOT ],
            flushResult.pageCount[ CSI_PAGE_TYPE_FILTER ] );


}

void   csiManager::report()
{
    csiSIInfo        * si;

    banner("csiManager");
    REPORT("index       : %d/%d\n",
            SICount,SIMaxCount );

    for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; itr ++ )
    {
        siMapRWLock.RLock();
        si = itr->second;
        si->switchLock.RLock();
        si->report( false/*detail*/ );
        si->switchLock.release();
        releaseSIMapLock();
    }
}

void csiManager::drawAll( const char * str, bool lock )
{
    csiStoredGroup   * storedGroup;
    csiSIInfo        * si;

    if( drawGroup )
    {
        if( lock )siMapRWLock.RLock();
        for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; itr ++ )
        {
            si = itr->second;

            if( lock ) si->switchLock.RLock();
            storedGroup = (csiStoredGroup*)si->storedGroup;
            while( storedGroup != NULL )
            {
                storedGroup->drawStoredGroup();
                storedGroup = storedGroup->getNext();
            }
            if( lock )    si->switchLock.release();
        }
        if( lock ) releaseSIMapLock();

        drawPage( (char*) str );
    }
}

void csiManager::storeMaster( bool lock )
{
    csiStoredGroup    * storedGroup;
    csiSIInfo        * si;
    int                  masterFD;

    masterFD=open( masterFN.c_str(), O_WRONLY | O_TRUNC | O_CREAT,644 );

    if( lock )siMapRWLock.RLock();
    for( SIIterator itr = SIMap.begin(); itr != SIMap.end() ; itr ++ )
    {
        si = itr->second;

        CSI_ASSERT( write( masterFD, si, sizeof( *si )) == sizeof(*si) );

        if( lock ) si->switchLock.RLock();
        storedGroup = (csiStoredGroup*)si->storedGroup;
        while( storedGroup != NULL )
        {
            storedGroup->storeMaster( masterFD );
            storedGroup = storedGroup->getNext();
        }
        if( lock )    si->switchLock.release();
    }
    if( lock ) releaseSIMapLock();
    
    close( masterFD );
}

void csiManager::reloadMaster()
{
    csiSIInfo          si;
    csiSIInfo        * newSIInfo;
    void             * newMemGroup;
    int                masterFD;
    SimpleHash         target;
    csiPageID          curLastPID;
    csiPageID          lastPID = 0;
    bool               siMapLocked = false;
    bool               switchLocked = false;
    int                ret;
    int                i;

    siMapRWLock.WLock();
    siMapLocked = true;

    printf("Reload...\n");
    LOG("Reload...\n");
    masterFD=open( masterFN.c_str(), O_RDONLY,644 );

    while( ( ret = read( masterFD, &si, sizeof( csiSIInfo )) )
            == sizeof( csiSIInfo ) )
    {
        /* SI(SecondaryIndex)Info 생성 */
        CSI_ASSERT( CSI_MALLOC( sizeof( csiSIInfo ), (void**)(&newSIInfo) ) );

        csiMemcpy( newSIInfo, &si, sizeof( csiSIInfo ) );

        newSIInfo->storedGroup            = NULL;
        csiMemset( &newSIInfo->lookupStat, 0, sizeof( newSIInfo->lookupStat ) );
        csiMemset( newSIInfo->memGroup, 0, sizeof( void* ) * MEMGROUP_MAX );
        for( i = 0 ; i < memGroupCountForSwitch ; i ++ )
        {
            CSI_ASSERT( ( newMemGroup = (void*)csiMemGroup::create() ) );
            newSIInfo->memGroup[ i ] = newMemGroup;
        }
        newSIInfo->curMemGroupIdx        = 0;
        newSIInfo->flushMemGroupIdx        = 0;

        CSI_SRWL_INIT( &newSIInfo->switchLock );
        CSI_SRWL_INIT( &newSIInfo->mergeLock );

        newSIInfo->unmergedGroupCount    = 0;
        newSIInfo->groupCount            = 0;

        printf("loadSI : %s\n", newSIInfo->SIName);
        LOG   ("loadSI : %s\n", newSIInfo->SIName);

        newSIInfo->switchLock.WLock();
        switchLocked = true;

        curLastPID = csiStoredGroup::reloadMaster( 
                masterFD, newSIInfo, si.groupCount );
        lastPID = ( curLastPID > lastPID ) ?
                    curLastPID : lastPID ;

        switchLocked = false;
        newSIInfo->switchLock.release();

        target = getSimpleHash( strlen(newSIInfo->SIName), newSIInfo->SIName );
        SIMap[ target ] = newSIInfo;

        printf("done : %s\n", newSIInfo->SIName);
        LOG   ("done : %s\n", newSIInfo->SIName);
    }

    csiIO::setLastPID( lastPID+1 );

    close( masterFD );

    printf("done\n" );
    LOG   ("done\n" );

    siMapLocked = false;
    releaseSIMapLock();

    CSI_ASSERT( siMapLocked == false );
    CSI_ASSERT( switchLocked == false );
}


void csiManager::reportMaster()
{
    csiSIInfo          si;
    int                masterFD;
    int                ret;
    int                i;

    printf("reportMaster...\n");
    LOG("reportMaster...\n");
    masterFD=open( masterFN.c_str(), O_RDONLY,644 );

    while( ( ret = read( masterFD, &si, sizeof( csiSIInfo )) )
            == sizeof( csiSIInfo ) )
    {
        /* MemGroup과 StoredGroup에 대한 MemoryPointer는 유효하지 않다. */
        for( i = 0 ; i < csiManager::getMemGroupCountForSwitch() ; i ++ )
        {
            si.memGroup[i] =NULL;
        }
        si.storedGroup = NULL;

//        si.reportDetail();
        si.reportSimple();

        csiStoredGroup::reportMaster( masterFD, si.groupCount );
    }

    close( masterFD );
}




/************************* internal functions *************************/

/*memgroup을 flush 하기 위해 switch함 */
void csiManager::switchMemGroup( csiSIInfo * SIInfo, int curMemGroupIdx )
{
    csiMemGroup    * memGroup;
    int              nextMemGroupIdx;
    bool             success = false;

    /* switch 함*/
    SIInfo->switchLock.WLock();
    memGroup = (csiMemGroup*)SIInfo->memGroup[ curMemGroupIdx ];
    nextMemGroupIdx    = (curMemGroupIdx+1) % memGroupCountForSwitch;
    if( ( curMemGroupIdx    == SIInfo->curMemGroupIdx ) &&
        ( nextMemGroupIdx    != SIInfo->flushMemGroupIdx ) &&
        ( memGroup->getStatus() == CSI_MEMGROUP_STATUS_ACTIVE ) )
    {
        CSI_ASSERT( memGroup->changeStatus(    CSI_MEMGROUP_STATUS_ACTIVE,
                                        CSI_MEMGROUP_STATUS_FLUSHING ) );
        SIInfo->curMemGroupIdx =nextMemGroupIdx; 
        success = true;
    }
    else
    {
        /* 타 Thread에 의하여 변경됨 */
    }
    SIInfo->switchLock.release();

    lastFlushTime = get_cur_microseconds();
    if( success )
    {
        /* 자신에 의해 Switch 되었으니 */
        csiWorkerPool::asyncFlush( (void*)SIInfo );
    }
}

void    csiManager::wait4Insert( csiSIInfo * SIInfo )
{
    csiMemGroup    * memGroup;

    /* 바로 다음 MemGroup이 사용 가능할때까지 대기 */
    memGroup = (csiMemGroup*)SIInfo->memGroup[ SIInfo->curMemGroupIdx ];
    while( memGroup->getStatus() != CSI_MEMGROUP_STATUS_ACTIVE )
    {
        (void)atomicInc( &SIInfo->flushWaitingCount, 1 );
        usleep( flushWaitingMsec * 1000 );
        memGroup = (csiMemGroup*)SIInfo->memGroup[ SIInfo->curMemGroupIdx ];
    }
}

void    csiManager::wait4Flush( csiSIInfo * SIInfo, int memGroupIdx )
{
    csiMemGroup    * memGroup;

    memGroup = (csiMemGroup*)SIInfo->memGroup[ memGroupIdx ];
    while( memGroup->getStatus() != CSI_MEMGROUP_STATUS_ACTIVE )
    {
        (void)atomicInc( &SIInfo->flushWaitingCount, 1 );
        usleep( flushWaitingMsec * 1000 );
    }
}

