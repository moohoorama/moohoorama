#include <csiPageManager.h>
#include <csiWorkerPool.h>
#include <csiStoredGroup.h>
#include <csiIO.h>
#include <sys/uio.h>

char            *csiPageManager::bufferOrgPtr    = NULL;
char            *csiPageManager::bufferPtr       = NULL;
uint64_t         csiPageManager::bufferSize      = 0;

csiBufferInfo   *csiPageManager::infoPtr            = NULL;
int              csiPageManager::infoCount          = 0;

int              csiPageManager::LRUParallelity = 0;
int              csiPageManager::LRUPIdx        = 0;
SyncLList        csiPageManager::LRU[ CSI_BUFFER_LRUPARALLEL_MAX ];
int              csiPageManager::freePIdx       = 0;
SyncLList        csiPageManager::freeList[ CSI_BUFFER_LRUPARALLEL_MAX ];
SyncLList       *csiPageManager::hashMap        = NULL;
int              csiPageManager::hashMapSize    = 0;
uint64_t         csiPageManager::filterRatio    = 0;

csiFlushInfo     csiPageManager::flushInfo;

int              csiPageManager::findOrReadPageCount    = 0;
int              csiPageManager::findPageCount          = 0;
int              csiPageManager::dupPageCount           = 0;
int              csiPageManager::readPageCount          = 0;

int              csiPageManager::hitThreshold           = 0;
int              csiPageManager::hashReportLimit        = 0;
int              csiPageManager::hashReportChainingThreshold    = 0;
int              csiPageManager::hashReportLockMissThreshold    = 0;
int              csiPageManager::victimSleepMsec        = 0;
int              csiPageManager::victimSleepCount       = 0;

int              csiPageManager::hitWeightRoot          = 0;
int              csiPageManager::hitWeightNode          = 0;
int              csiPageManager::hitWeightDPage         = 0;
int              csiPageManager::hitWeightDefault       = 0;

int              csiPageManager::kickOutPolicy[ CSI_PAGE_TYPE_MAX ] = { 0 };

int              csiMPRInfo::totalReadIOCount = 0;
int              csiMPRInfo::totalReadPageCount = 0;

/***************** initialize page manager *************************/

bool csiPageManager::init()
{
    int        i;

    bufferOrgPtr                = NULL;
    bufferPtr                   = NULL;
    infoPtr                     = NULL;
    hashMap                     = NULL;
    flushInfo.filterPtr         = NULL;

    /* property에서 필요 값들을 읽음  */
    bufferSize      = get_property_int("page_manager","buffer_size_mb");
    hashMapSize     = get_property_int("page_manager","hash_map_size");
    LRUParallelity  = get_property_int("page_manager","lru_parallelity");
    hitThreshold    = get_property_int("page_manager","hit_threshold");
    hashReportLimit = get_property_int("page_manager","hash_report_limit");
    victimSleepMsec = get_property_int("page_manager","victim_sleep_msec");
    hashReportChainingThreshold    = 
        get_property_int("page_manager","hash_report_chaining_threshold");
    hashReportLockMissThreshold    = 
        get_property_int("page_manager","hash_report_lock_miss_threshold");
    flushInfo.multiPageWriteCount =
        get_property_int("page_manager","multi_page_write_count");
    filterRatio = 
        get_property_int("page_manager","filter_size_ratio");

    hitWeightRoot   = get_property_int("cache_hit_weight","root");
    hitWeightNode   = get_property_int("cache_hit_weight","node");
    hitWeightDPage  = get_property_int("cache_hit_weight","dpage");
    hitWeightDefault= get_property_int("cache_hit_weight","default");


    kickOutPolicy[ CSI_PAGE_TYPE_ROOT ] = 
        get_property_int("cache_kick_out","flushed_root");
    kickOutPolicy[ CSI_PAGE_TYPE_NODE ] = 
        get_property_int("cache_kick_out","flushed_node");
    kickOutPolicy[ CSI_PAGE_TYPE_DPAGE ] = 
        get_property_int("cache_kick_out","flushed_dpage");
    kickOutPolicy[ CSI_PAGE_TYPE_FILTER ] = 
        get_property_int("cache_kick_out","flushed_filter");

    infoCount       = bufferSize * (MB/ PAGE_SIZE);
    bufferSize      = infoCount * PAGE_SIZE; /* PAGE_SIZE 단위로 맞춤 */
    victimSleepCount= 0;
    LRUPIdx         = 0;
    freePIdx        = 0;

    CSI_ASSERT( hashMapSize > 16 );
    CSI_ASSERT( infoCount    > 16 );
    CSI_ASSERT( LRUParallelity <= CSI_BUFFER_LRUPARALLEL_MAX  );

    /* memory 할당받음 */
    TEST( CSI_MALLOC( bufferSize + PAGE_SIZE, (void**)&bufferOrgPtr ) );
    TEST( CSI_MALLOC( sizeof(csiBufferInfo) * infoCount , (void**)&infoPtr ) );
    TEST( CSI_MALLOC( sizeof(SyncLList) * hashMapSize, (void**)&hashMap ) );
    for( i=0 ; i < CSI_PAGE_TYPE_FLUSH_MAX ; i ++ )
    {
        TEST( CSI_MALLOC( sizeof(struct iovec) 
                    * flushInfo.multiPageWriteCount,
                    (void**)&flushInfo.fpa[ i ].array ) );
    }

    /* Buffer & BufferInfo 초기화 */
    bufferPtr = (char*)align( (uintptr_t)bufferOrgPtr, PAGE_SIZE );
    csiMemset( infoPtr, 0, sizeof( csiBufferInfo ) * infoCount );
    csiMemset( bufferPtr, 0, bufferSize );

    /* Flush Info 초기화 */
    INIT_LOCK( &flushInfo.lock );
    flushInfo.missCount         = 0;
    flushInfo.flushedPageCount  = 0;
    flushInfo.accumulatedKVCount= 0;
    flushInfo.KVCount           = 0;

    /* List 구축 */
    init_lru();
    init_hash();
    init_buffer();

    csiSlotDir::globalInit();

    csiWorkerPool::registRF( csiPageManager::report );

    return true;

    EXCEPTION_END;

    CSI_ASSERT( false );
}


void csiPageManager::init_lru()
{
    int    i;
    int lruSpin;
    int lruSleep;

    lruSpin = get_property_int("page_manager","lru_spin_count");
    lruSleep= get_property_int("page_manager","lru_sleep_msec");
    for( i=0 ; i < LRUParallelity ; i ++ ) 
    {
        slist_init( &LRU[ i ], "LRU_LIST",i,lruSpin, lruSleep );
        slist_init( &freeList[ i ], "FREE_LIST",i,lruSpin, lruSleep );
    }
}
void csiPageManager::init_hash()
{
    int i;
    int hashSpin;
    int hashSleep;

    hashSpin  = get_property_int("page_manager","hash_spin_count");
    hashSleep = get_property_int("page_manager","hash_sleep_msec");

    for( i=0 ; i < hashMapSize ; i ++ ) 
        slist_init(  &hashMap[ i ], "HASH_BUCKET",i,hashSpin, hashSleep );
}
void csiPageManager::init_buffer()
{
    int i;
    int PSeq;
    int infoSpin;
    int infoSleep;

    infoSpin    = get_property_int("page_manager","info_spin_count");
    infoSleep    = get_property_int("page_manager","info_sleep_msec");

    for( i=0 ; i < infoCount ; i ++ )
    {
        PSeq = getParallelSeq( i );

        infoPtr[i].PID = NULL_PID;
        infoPtr[i].lock.init( "INFO_LOCK",i,infoSpin, infoSleep);
        infoPtr[i].hitCount = 0;

        LLIST_INIT( &(infoPtr[ i ].LRU) );
        LLIST_INIT( &(infoPtr[ i ].hash) );
        infoPtr[i].LRU.data    = (void*)&infoPtr[ i ];
        infoPtr[i].hash.data    = (void*)&infoPtr[ i ];
        //slist_pushHead( &LRU[ PSeq ], &(infoPtr[ i ].LRU) );
        slist_pushHead( &freeList[ PSeq ], &(infoPtr[ i ].LRU) );
    }
}

bool csiPageManager::dest()
{
    int    i;

    DEST_LOCK( &flushInfo.lock );

    for( i=0 ; i<CSI_PAGE_TYPE_FLUSH_MAX ; i ++ )
        TEST( CSI_FREE( flushInfo.fpa[ i ].array ) );
    for( i=0 ; i<infoCount ; i ++ )
        infoPtr[i].lock.dest();
    for( i=0 ; i < LRUParallelity ; i ++ ) 
    {
        slist_dest(  &LRU[ i ] );
        slist_dest(  &freeList[ i ] );
    }
    for( i=0 ; i < hashMapSize ; i ++ ) 
        slist_dest(  &hashMap[ i ] );

    if( bufferOrgPtr )    TEST( CSI_FREE( bufferOrgPtr ) );
    if( infoPtr )        TEST( CSI_FREE( infoPtr ) );
    if( hashMap )        TEST( CSI_FREE( hashMap ) );

    bufferOrgPtr    = NULL;
    bufferPtr        = NULL;
    infoPtr            = NULL;
    hashMap            = NULL;
    infoCount        = 0;
    hashMapSize        = 0;
    LRUParallelity    = 0;
    LRUPIdx            = 0;

    return true;

    EXCEPTION_END;

    return false;
}

void   csiPageManager::report()
{
    csiPageHeader    *header;
    const char        assignUnassignTitle[][9]={"ASSIGN","NULL_PID"};
    const char        hotColdTitle[][9]={"HOT","COLD", "NONE"};
    int               cnt=0;
    float             hitRatio;
    int               pageStats[2][3][ CSI_PAGE_TYPE_MAX ];
    int               type;
    int               assignUnassign=0;
    int               hotCold=0;
    int               statValue;
    int               sumValue;
    const int         highestCount = 8;
    int               highestVal[ highestCount ];
    int               highestIdx[ highestCount ];
    int               i;
    int               j;
    int               k;
    
    csiMemset( pageStats, 0, sizeof( pageStats ) );

    if( findOrReadPageCount )
        hitRatio = (findOrReadPageCount-readPageCount)*100.0f / 
                    findOrReadPageCount;
    else
        hitRatio = 0;

    banner("csiPageManager");
    REPORT("size:%lld(%lld MB)  "
            "count:%d "
            "victimSleepCount:%d\n"
            BAR_STR
            "\n"
            "find    :%10d\n"
            "findRead:%10d\n"
            "dup     :%10d\n"
            "read    :%10d\n"
            "hitRatio:%6.2f\n"
            "\n",
            bufferSize, bufferSize/1024/1024,
            infoCount,
            victimSleepCount,
            findPageCount,
            findOrReadPageCount,
            dupPageCount,
            readPageCount,
            hitRatio );
    REPORT("PageList [%d/%d]\n", LRUPIdx, LRUParallelity );
    REPORT("%8s %8s\n", "Free", "Lru" );
    for( i=0 ; i < LRUParallelity ; i ++)
    {
        REPORT("%8d %8d\n", freeList[i].size, LRU[i].size );
    }

    prepareHighestEntry( (int*)highestVal, (int*)highestIdx, highestCount );
    REPORT("HASHMAP [%d]\n", hashMapSize );
    for( i=0 ; i < hashMapSize ; i ++)
    {
        pickHighestEntry( (int*)highestVal, (int*)highestIdx, highestCount,
                          hashMap[i].size, i );
    }
    REPORT("[%8s] %8s\n", "HASH_IDX", "PageIDs" );
    for( i=0 ; i < highestCount ; i ++ )
    {
        LList            * cur;
        csiBufferInfo    * BInfo;
        SyncLList       * ptr;

        if( highestIdx[i] != -1 )
        {
            ptr =  &hashMap[ highestIdx[i] ];
            slist_RLock( ptr );
            REPORT("[%8d] ", highestIdx[i] );
            for( cur = ptr->head.next ; 
                 cur != &ptr->head ; 
                 cur = cur->next )
            {
                BInfo = (csiBufferInfo*)cur->data;
                REPORT("%10d ", BInfo->PID);
            }
            slist_unlock( ptr );
            REPORT("\n");
            cnt ++;
        }
    }

    for( i=0 ; i < infoCount ; i ++)
    {
        header = (csiPageHeader*)getBuffer( i );

        assignUnassign    = ( infoPtr[ i ].PID == NULL_PID );
        if( infoPtr[ i ].hitCount > hitThreshold )
        {
            hotCold = 0;        /* hot */
        }
        else
        {
            if( infoPtr[ i ].hitCount > 0 )    
            {
                hotCold = 1;    /* cold */
            }
            else
            {
                hotCold = 2;    /* none */
            }
        }
        type = CSI_PAGE_TYPE_NODE;
        if( ( 0 <= header->type ) && ( header->type < CSI_PAGE_TYPE_MAX ) )
            type = header->type;
        pageStats[ assignUnassign ][ hotCold ][ type ]++;
    }

    for( assignUnassign = 0 ; assignUnassign <= 1 ; assignUnassign ++ )
    {
        REPORT("[%s]\n",assignUnassignTitle[ assignUnassign ] );
        REPORT("%10s ","TYPE");
        for( hotCold = 0 ; hotCold <= 2 ; hotCold ++ )
        {
            REPORT("%12s ", hotColdTitle[ hotCold ] );
        }
        REPORT("\n");
        for( i=0 ; i < CSI_PAGE_TYPE_MAX ; i ++ )
        {
            for( hotCold = 0 ; hotCold <= 2 ; hotCold ++ )
                if( pageStats[ assignUnassign ][ hotCold ][ i ] ) break;
            if( hotCold < 3 )
            {
                REPORT("%10s ",
                       csiPageManager::getPageTypeName(
                           static_cast<csiPageType>(i)));
                sumValue = 0;
                for( hotCold = 0 ; hotCold <= 2 ; hotCold ++ )
                {
                    statValue = pageStats[ assignUnassign ][ hotCold ][ i ];
                    sumValue += statValue;
                    REPORT("%5d(%5.2f) ", statValue, 
                                          statValue *100.0f / infoCount );
                }
                REPORT("%5d(%5.2f) ", sumValue, sumValue *100.0f / infoCount );
                REPORT("\n");
            }
        }
    }
    REPORT("flushInfo :\n");
    REPORT("%16s %10s %10s %10s %10s %10s %10s\n"
            BAR_STR
            BAR_STR
            "\n",
            "MUL_WRITE_CNT",
            "FA_P_CNT",
            "FA_CNT_D",
            "FA_CNT_N",
            "KV_COUNT",
            "ACCU_KVCNT",
            "MISS_COUNT" );
    REPORT("%16d %10d %10d %10d %10d %10d %10d\n",
            flushInfo.multiPageWriteCount,
            flushInfo.flushedPageCount,
            flushInfo.fpa[ CSI_PAGE_TYPE_DPAGE ].count,
            flushInfo.fpa[ CSI_PAGE_TYPE_NODE ].count,
            flushInfo.KVCount,
            flushInfo.accumulatedKVCount,
            flushInfo.missCount );
}

/***************** page cache operation  *************************/
void csiPageManager::assignPID( char    * page, csiPageID    PID )
{     /* Flush되어 PID를 할당받음. */
    csiBufferSeq      bs = getSeqByBufPtr( page );
    CSI_ASSERT( bs < infoCount );
    assignPID( bs, PID );
}
void csiPageManager::assignPID( csiBufferSeq bs, csiPageID    PID )
{     /* Flush되어 PID를 할당받음. */
    infoPtr[ bs ].PID = PID;
    slist_pushHead( &hashMap[ getHashIdx( PID ) ],&(infoPtr[ bs ].hash) );
    pushToLRU( bs );    /* 자연스레, 삭제 가능해짐 */
}
void csiPageManager::unassignPID( csiBufferSeq bs )
{
    csiPageID    PID = infoPtr[ bs ].PID;
    CSI_ASSERT( PID != NULL_PID );
    slist_remove( &hashMap[ getHashIdx( PID ) ],&(infoPtr[ bs ].hash) );
    infoPtr[ bs ].PID = NULL_PID;
}


/***************** flush ******************/

bool  csiFlushInfo::init( int fcount, int fratio )
{
    int i;

    for( i=0 ; i < CSI_PAGE_TYPE_FLUSH_MAX ; i ++ )
    {
        fpa[ i ].groupCount    = 0;
        fpa[ i ].lastPID    = NULL_PID;
        fpa[ i ].count        = 0;
        fpa[ i ].page        = NULL;
    }

    flushedPageCount    = 0;
    beginPID            = NULL_PID;
    endPID                = NULL_PID;
    KVCount                = 0;
    beginTime            = get_cur_microseconds();
    filterPtr            = NULL;
    filterSize            = fcount / 100 * fratio;
    estimatedCount      = fcount;

    if( filterSize )
    {
        TEST( CSI_MALLOC( filterSize, (void**)&filterPtr ) );
        initFilter( filterPtr, filterSize );
    }

    return true;

    EXCEPTION_END;

    return false;
}
bool    csiFlushInfo::dest()
{
    if( filterPtr )    CSI_ASSERT( CSI_FREE( filterPtr ) );
    filterPtr = NULL;

    return true;
}


void    csiPageManager::flushLock()
{
    uint64_t   curTime = get_cur_microseconds();
    if( TRYLOCK( &flushInfo.lock ) )
    {
        LOCK( &flushInfo.lock );
        flushInfo.missCount ++;
    }
    flushInfo.prepareTime = curTime;
}

void    csiPageManager::flushUnlock()
{
    UNLOCK( &flushInfo.lock );
}

/*어떤 Group에 대한 flush를 시작함*/
bool    csiPageManager::flushBegin( int estimatedKeyCount)
{
    TEST( flushInfo.init( estimatedKeyCount, filterRatio ) );

    return true;

    EXCEPTION_END;

    return false;
}

/* MPR 초기화 */
bool csiMPRInfo::globalInit()
{
    return true;
}

/* MPR(MultiPageRead) */
bool        csiMPRInfo::init( int aBufferCount )
{
    int          i;

    prepareCount        = 0;
    readCount           = 0;
    getCount            = 0 ;

    readPageCount       = 0;
    readIOCount         = 0;
    bufferCount         = aBufferCount;


    CSI_ASSERT( 1 <= aBufferCount  );
    if( aBufferCount >= 2 )
    {
        for( i=0 ; i < aBufferCount ; i ++ )
        {
            buffer[ i ] = csiPageManager::getVictimBuffer( true );
        }
    }
    else
    {
        buffer[ 0 ] = NULL;
    }

    return true;

    EXCEPTION_END;

    dest();

    return false;
}
void        csiMPRInfo::dest()
{
    int i;

    atomicInc( &totalReadPageCount, readPageCount );
    atomicInc( &totalReadIOCount, readIOCount );

    if( bufferCount == 1 ) /*disable MPR */
    {
        if( buffer[0] != NULL )
            csiPageManager::releasePage( buffer[0] );
    }
    else
    {
        for( i=0 ; i < bufferCount ; i ++ )
            csiPageManager::releaseVictimBuffer( buffer[ i ] );
    }
}
/* 읽을 Page들을 MPRInfo에게 알려줌. */
bool        csiMPRInfo::prepare( csiPageID PID )
{
    CSI_ASSERT( prepareCount <= bufferCount )
    if( prepareCount == bufferCount ) return false;

    PIDArray[ prepareCount ++ ] = PID;
    return true;
}
/* Page들을 가져옴 */
char    *    csiMPRInfo::getNext()
{
    csiPageID     beginPID;
    char        * page;
    
    if( bufferCount == 1 ) /*disable MPR */
    {
        if( prepareCount ) 
        {
            CSI_ASSERT( prepareCount == 1 );
            prepareCount = 0;
            if( buffer[0] != NULL )
                csiPageManager::releasePage( buffer[0] );
            buffer[0]= csiPageManager::findOrReadPage(PIDArray[0],&readCount);
            return buffer[0];
        }
        return NULL;
    }

    /* first get, so module have to read multiple pages */
    if( getCount == 0 )
    {
        /* don't have prepare page */
        if( prepareCount == 0 )
        {
            return NULL;
        }

        /* find continues page id*/
        beginPID = PIDArray[ 0 ];
        for( readCount = 0 ; readCount < prepareCount ; readCount ++ )
            if( beginPID + readCount != PIDArray[ readCount ] ) break;

        CSI_ASSERT( ( 0 < readCount ) && ( readCount <= prepareCount ) );

        CSI_ASSERT( csiIO::readMultiPage(
                    (char**)buffer, beginPID, readCount ) );
        readIOCount ++;
    }

    CSI_ASSERT( getCount <= readCount );
    if( readCount == getCount )
    {
        int i;
        /* shift left PIDs */
        for( i = readCount ; i < prepareCount ; i ++ )
        {
            PIDArray[ i - readCount ] = PIDArray[ i ];
        }
        prepareCount -= readCount;
        readCount = 0;
        getCount = 0;
        return NULL;
    }

    readPageCount ++;

    return buffer[ getCount++ ];
}

void csiMPRInfo::dump()
{
    REPORT("BufferCount  : %d\n", bufferCount );
    REPORT("readPageCount: %d\n", readPageCount );
    REPORT("readIOCount  : %d\n", readIOCount );
    REPORT("Avg.ReadCnt  : %6.2f\n\n", readPageCount*1.0f/readIOCount );
}

void    csiPageManager::initBufferPage( char        * page, 
                                        csiPageType      type)
{
    csiPageHeader    * header = (csiPageHeader*)page;
    csiSlotDirType     dirType;

    header->type                = type;
    header->prevPID             = NULL_PID;
    header->siblingSeq          = -1;
    switch( type )
    {
        case CSI_PAGE_TYPE_NONE:
        case CSI_PAGE_TYPE_MEMGROUP:    /* MEMGROUP 임시 저장용 */
        case CSI_PAGE_TYPE_WORKAREA:    /* I/O와 상관없이, 작업용 버퍼 사용 */
        case CSI_PAGE_TYPE_FILTER:         /* bloomFilter */
            dirType = CSI_SD_NONE;
            break;
        case CSI_PAGE_TYPE_SUPPLEMENT:
            dirType = CSI_SD_VALUE_ONLY;
            break;
        case CSI_PAGE_TYPE_DPAGE:         /* (K + V) * N */
            dirType = CSI_SD_KEY_VALUE;
            break;
        case CSI_PAGE_TYPE_NODE:        /* subSlotDir가 KArray */
            dirType = CSI_SD_SUPER_KA;
            break;
        case CSI_PAGE_TYPE_ROOT:          /* (K + NodePID ) * N */
            dirType = CSI_SD_KEY_PID;
            break;
        case CSI_PAGE_TYPE_FLUSH_MAX:    /* flush/non flush 구분용 타입 */
        case CSI_PAGE_TYPE_MAX:
        default:
            CSI_ASSERT( false );
    }
    header->slotDir.init( dirType, page + PAGE_SIZE );
    CSI_ASSERT( header->slotDir.lastOffset == ESTIMATED_LASTOFFSET );
}

int  csiPageManager::insertSupplementKV(ByteArray        *val, 
                                        csiLargeValueRef *lvRef)
{
    csiPageHeader     *header;
    csiPageID          estimatedLastPID;
    int                size=0;
    int                freeSize=0;
    ByteArray          _ba = *val;
    int32_t            slotIdx = -1;

    /* NodePage의 구조 때문에, DPage는 최대한 뭉쳐있는 것이 효율이 좋다.
     * 따라서 SupplementPage와 DPage가 섞이지 않도록 하기 위해,
     * SupplementPage를 기록하고 이후 DPage, Node, Root의 순으로 기록하도록
     * 한다. 
     * 따라서 여기서 삽입되는 SupplementKV는 반드시 csiIO의 LastPID에서
     * 연속된다. */
    lvRef->count     = 0;

    do {
        header=(csiPageHeader*)flushInfo.fpa[CSI_PAGE_TYPE_SUPPLEMENT].page;
        if( header ) {
            _ba=header->slotDir.insertUtmostV(&_ba, &slotIdx);
            if (slotIdx != -1) { 
                lvRef->count ++;
                if(lvRef->count == 1 ) lvRef->slot_idx = slotIdx;
            } else {
                TEST( allocAndRegistFlushPage(CSI_PAGE_TYPE_SUPPLEMENT) );
            }
        } else {
            TEST( allocAndRegistFlushPage(CSI_PAGE_TYPE_SUPPLEMENT) );
        }
    } while( _ba.len > 0 );

    lvRef->page_info = csiIO::estimatedAppendPID() + 
        flushInfo.fpa[CSI_PAGE_TYPE_SUPPLEMENT].count
        - lvRef->count;

    return lvRef->count;

    EXCEPTION_END;

    return 0;
}
bool csiPageManager::insertKV( ByteArray *key, ByteArray *val)
{
    csiPageHeader    *header;
    csiPageHeader    *supHeader;
    csiPageID         spid;
    csiLargeValueRef  lvRef;
    int               cnt;
    char             *slotPtr;
    char             *orgSlotPtr;
    int               retry = 0;

    /* 페이지 할당을 위한 루프 */
    while( true )
    {
        TEST( retry <= 1 );    /* 두번의 할당은 있을 수 없음 */

        header    = (csiPageHeader*)flushInfo.fpa[ CSI_PAGE_TYPE_DPAGE ].page;
        if( header    )    /*페이지를 할당한 상태이면 */
        {
            TEST( header->type == CSI_PAGE_TYPE_DPAGE );

            if( header->slotDir.insertKV( key, val ) )
            {
                setFilter(  flushInfo.filterPtr, 
                            flushInfo.filterSize, 
                            (void*)key );
                break;
            }
            else
            {
                if( val->isLargeValue() )
                {
                    TEST( cnt=insertSupplementKV( val, &lvRef ) );
                    if(header->slotDir.insertKV4Supplemental(key,&lvRef))
                    {
                        setFilter(flushInfo.filterPtr, 
                                  flushInfo.filterSize, 
                                  (void*)key );
                        break;
                    }
                    TEST( allocAndRegistFlushPage( CSI_PAGE_TYPE_DPAGE ) );
                    header = 
                        (csiPageHeader*)flushInfo.fpa[CSI_PAGE_TYPE_DPAGE].page;
                    CSI_ASSERT(
                        header->slotDir.insertKV4Supplemental(key,&lvRef) );
                    setFilter(flushInfo.filterPtr, 
                              flushInfo.filterSize, 
                              (void*)key );
                    break;
                }
            }
        }
        TEST( allocAndRegistFlushPage( CSI_PAGE_TYPE_DPAGE ) );
        retry ++;
    }

    flushInfo.KVCount ++;
    
    return true;

    EXCEPTION_END;

    dumpPage( (char*)header );

    return false;
}

/* NodeMerge, 즉 node 재구성 용 */
bool    csiPageManager::insertKeyArrayToNode(    
        csiSlotDir    **subSlots,     int      count )
{
    csiFlushPageArray    *fpa;
    csiSlotDir           *subSlot;
    csiPageHeader        *header;
    csiPageID             estimatedLastPID;
    int                   size[ MERGING_MAX ];
    int                   i;
    int                   j;

    /* 아래쪽에서 딱딱 subSlot을 Page 크기에 맞춰서 올려줬으리라 가정한다 */
    /* victim page를 얻어와서, 초기화 후 Flush 대상으로 삼음 */
    TEST( allocAndRegistFlushPage( CSI_PAGE_TYPE_NODE ) );
    header    = (csiPageHeader*)flushInfo.fpa[ CSI_PAGE_TYPE_NODE ].page;

    for( i=0 ; i < count ; i ++ )
    {
        size[i] =    subSlots[i]->getUsedSize();
        subSlot = (csiSlotDir*)
            header->slotDir.allocSlot(size[i], CSI_ALIGN );
        if( !subSlot )    /* 반드시 할당되어야 함 */
        {
            LOG("insert key array to node error: %d\n", i );
            for( j = 0 ; j < count ; j ++ )
            {
                LOG("subslot : size [%d] %d ", j, size[j] );
                subSlots[j]->dump();
            }
            LOG("free: %d", header->slotDir.getFreeSize() );
            CSI_ASSERT( false );
        }

        subSlot->init( CSI_SD_KEY_ARRAY, ((char*)subSlot) + size[i] );
        CSI_ASSERT( subSlot->copyFrom( subSlots[i] ) ); 

        if( subSlot->slotCount > 0 )
        {
            fpa        = &flushInfo.fpa[ CSI_PAGE_TYPE_NODE ];
            estimatedLastPID = fpa->lastPID;
            if( estimatedLastPID == NULL_PID ) 
            {
                estimatedLastPID = csiIO::estimatedAppendPID() - 1;
            }
            subSlots[i]->prevPID =     estimatedLastPID + fpa->count;
        }
    }

    return true;

    EXCEPTION_END;

    return false;
}



bool    csiPageManager::insertToNode(    char        * childDPage,
                                        csiPageID      childPID )
{
    csiPageHeader        *header;
    csiSlotDir           *subSlotDir;
    ByteArray             beginKey;
    ByteArray             endKey;
    ByteArray             prevLastKey;
    bool                  ret;
    int                   seq;
    int                   retry = 0;

    TEST( childDPage != NULL );

    /* ChildDPage의 첫/마지막 Key를 읽음 */
    header    = (csiPageHeader*)childDPage;
    seq        = header->slotDir.slotCount;
    TEST( seq >= 1 );
    header->slotDir.readBA( 0,       &beginKey );
    header->slotDir.readBA( seq - 1, &endKey );

    /* 여기서 Node는 nodeMerge안된, 1개의 Group인 경우만 생각함 */
    /* 페이지 할당을 위한 루프 */
    while( true )
    {
        CSI_ASSERT( retry <= 1 );    /* 두번의 할당은 있을 수 없음 */

        header    = (csiPageHeader*)flushInfo.fpa[ CSI_PAGE_TYPE_NODE ].page;
        if( header )    /*페이지를 할당한 상태이면 */
        {
            subSlotDir    = (csiSlotDir*)header->slotDir.getPtrBySlot( 0 );
            TEST( insertToKeyArray( subSlotDir,
                                    beginKey, endKey, 
                                    childPID, &ret ) );
            if( ret == true )    break;  /* 성공 */
        }

        TEST( allocAndRegistFlushPage( CSI_PAGE_TYPE_NODE ) );
        header    = (csiPageHeader*)flushInfo.fpa[ CSI_PAGE_TYPE_NODE ].page;

        /* 일단 KeyArray한개만 허용. SlotDir 바로 뒤가 새 KArray */
        subSlotDir    = (csiSlotDir*)
            header->slotDir.allocSlot(    0/*max size*/, CSI_ALIGN );
        CSI_ASSERT( align( (intptr_t)subSlotDir, CSI_ALIGN) == (intptr_t)subSlotDir );
        subSlotDir->init( CSI_SD_KEY_ARRAY, ((char*)header) + PAGE_SIZE );

        retry ++;
    }

    return true;

    EXCEPTION_END;

    return false;
}

bool    csiPageManager::insertToKeyArray(    csiSlotDir            * subSlotDir,
                                            ByteArray              beginKey,
                                            ByteArray              endKey,
                                            csiPageID              PID,
                                            bool                * ret)
{
    char                *slotPtr;
    int                  seq;
    int                  freeSize;
    int                  estiSize = 0;        /* 예상 크기 */

    *ret = false; 

    /* 한계값이 있고, 거기에 도달했다면 */
    if( subSlotDir->isSlotLimit() )
    {
        *ret = false;
        return true;
    }

    seq = subSlotDir->slotCount - 1;
    if( subSlotDir->beginPID    == NULL_PID )
    {
        subSlotDir->beginPID = PID;
    }
    else
    {
        if( subSlotDir->beginPID + seq != PID )
        {
            /* DPID가 연속적으로 배치되지 않을 경우, 
             * 새롭게 Node를 생성해야 함 */
            *ret = false;
            return true;
        }
    }
    /* Node에서 EndKey를 하나를 지우고, DPage의 BeginKey와 EndKey를 Node에 
     * 넣는다.
     * 예)
     * DPage0 = [0,1,3]
     * DPage1 = [4,5,7]
     * DPage2 = [8,9,10]
     *
     * 1) Dpage0정보 추가 : Node = [0,3]
     * 2) Dpage1정부 추가 : Node = [0,4,7]
     * 3) Dpage2정부 추가 : Node = [0,4,8,10]
     * 따라서, 현재의 FreeSize + 마지막 키 크기가 진짜 빈 공간이다 */
    freeSize = subSlotDir->getFreeSize() + subSlotDir->getSlotSize(seq);
    estiSize = csiSlotDir::getCompactBASize( &beginKey ) 
             + csiSlotDir::getCompactBASize( &endKey );

    if( freeSize >= estiSize )
    {        /* 삽입 가능 */
        (void)subSlotDir->removeLastSlot();
        TEST( subSlotDir->insertK( &beginKey ) );
        TEST( subSlotDir->insertK( &endKey ) );

        *ret = true;
        return true;
    }

    *ret = false;

    return true;

    EXCEPTION_END;

    return false;
}

bool    csiPageManager::insertToRoot(    ByteArray    key, csiPageID PID )
{
    csiPageHeader       *header;
    char                *slotPtr;
    char                *orgSlotPtr;
    int                  retry = 0;

    /* 여기서 Node는 nodeMerge안된, 1개의 Group인 경우만 생각함 */
    /* 페이지 할당을 위한 루프 */
    while( true )
    {
        CSI_ASSERT( retry <= 1 );    /* 두번의 할당은 있을 수 없음 */
        header    = (csiPageHeader*)flushInfo.fpa[ CSI_PAGE_TYPE_ROOT ].page;

        if( header )    /*페이지를 할당한 상태이면 */
        {
            TEST( header->type == CSI_PAGE_TYPE_ROOT );
            if( header->slotDir.insertKP( &key, PID ) ) break;
        }

        TEST( allocAndRegistFlushPage( CSI_PAGE_TYPE_ROOT ) );
        header    = (csiPageHeader*)flushInfo.fpa[ CSI_PAGE_TYPE_ROOT ].page;

        retry ++;
    }

    return true;

    EXCEPTION_END;

    return false;
}



bool     csiPageManager::allocAndRegistFlushPage( csiPageType type )
{
    csiFlushPageArray    * fpa;
    csiPageHeader        * header;
    char                 * newPage;
    csiPageHeader        * newHeader;
    
    CSI_ASSERT( ( CSI_PAGE_TYPE_NONE < type ) && 
                ( type <= CSI_PAGE_TYPE_FLUSH_MAX ) );

    fpa    = &flushInfo.fpa[ type ];
    CSI_ASSERT( fpa->count <= flushInfo.multiPageWriteCount );

    newPage     = getVictimBuffer( true/*retry*/ );
    newHeader= (csiPageHeader*)newPage;
    initBufferPage( newPage, type );
    newHeader->siblingSeq    = (uint)fpa->groupCount ++;

    if( fpa->count )    /* 이전 Page가 있으면 */
    {
        header        = (csiPageHeader*)fpa->page;
        newHeader->slotDir.setPrev( &header->slotDir );
    }
    /* 기존 FlushArray가 충분히 찼으면, Flush */
    if( fpa->count == flushInfo.multiPageWriteCount )
    {
        /* supplementPage는 반드시 먼저 기록되어야 함 */
        if( type != CSI_PAGE_TYPE_SUPPLEMENT )
        {
            TEST( flushPages( CSI_PAGE_TYPE_SUPPLEMENT ) );
        }
        TEST( flushPages( type ) );
        CSI_ASSERT( fpa->count == 0 );
    }

    fpa->page                         = newPage;
    fpa->array[ fpa->count ].iov_len  = PAGE_SIZE;
    fpa->array[ fpa->count ].iov_base = newPage;;
    fpa->count ++;

    return true;

    EXCEPTION_END;

    return false;
}


bool    csiPageManager::flushPages( csiPageType type )
{
    csiFlushPageArray    *fpa;
    csiPageID             PID;
    csiPageHeader        *header;
    char                 *page;
    ByteArray             key;
    int                   i;

    fpa        = &flushInfo.fpa[ type ];

    if( fpa->count )
    {
        /* prevPID 설정 */
        for( i=0 ; i < fpa->count ; i ++ )
        {
            header    = (csiPageHeader*)fpa->array[ i ].iov_base;
            header->prevPID = fpa->lastPID;
            if( i == 0 )
            {
                fpa->lastPID = csiIO::estimatedAppendPID();
            }
            else
            {
                fpa->lastPID ++;
            }
        }

        TEST( csiIO::appendPages(    fpa->array,
                                    fpa->count,
                                    &PID ) );
        flushInfo.flushedPageCount += fpa->count;
        
        for( i=0 ; i < fpa->count ; i ++ )
        {
            page    = (char*)fpa->array[ i ].iov_base;
            header    = (csiPageHeader*)page;
            CSI_ASSERT( header->slotDir.lastOffset == ESTIMATED_LASTOFFSET );
            CSI_ASSERT( header->type == type );

            switch( type )
            {
            case CSI_PAGE_TYPE_DPAGE:
                TEST( insertToNode( page, PID + i ) );
                break;
            case CSI_PAGE_TYPE_NODE:
                key = csiStoredGroup::chooseNodeKeyInBuffer( 
                        page, true/*min*/ );
                TEST( insertToRoot( key, PID + i ) );
                break;
            case CSI_PAGE_TYPE_ROOT:
                break;
            default:
                break;
            }

            if( flushInfo.beginPID == NULL_PID ) flushInfo.beginPID = PID+i;
            flushInfo.endPID = PID+i;

            /* 사용한 페이지를 cache에 등록할 것인가, 무시할 것인가 */
            if( kickOutPolicy[ type ]  )    releaseVictimBuffer( page );
            else                            assignPID( page, PID + i );
        }
        fpa->count = 0;
    }
    fpa->page = NULL;

    return true;

    EXCEPTION_END;

    return false;
}

bool    csiPageManager::flushFilter()
{
    csiPageHeader        * header;
    csiPageID              PID = NULL_PID;
    char                 * slotPtr;
    int                    size;
    int                    freeSize;
    int                    slotSize;

    size = flushInfo.filterSize;

    while( size > 0 )
    {
        header = (csiPageHeader*)getVictimBuffer( true/*retry*/ );
        initBufferPage( (char*)header, CSI_PAGE_TYPE_FILTER );
        header->prevPID = PID;

        freeSize = header->slotDir.getFreeSize() - sizeof( csiOffset );
        if( freeSize >= size )
        {    /*삽입 가능함 */ 
            slotPtr = header->slotDir.allocSlot( size );

            slotSize = header->slotDir.getSlotSize( 0 );
            CSI_ASSERT( slotSize <= freeSize );
            CSI_ASSERT( slotSize <= size );
            CSI_ASSERT( slotPtr );

            size -= slotSize;
            CSI_ASSERT( size == 0 );
            csiMemcpy( slotPtr, flushInfo.filterPtr + size, slotSize );
        }
        else
        {
            /* 공간 부족. 잘라서 기록해야함 */
            slotPtr = header->slotDir.allocSlot( 0 );    /*공간 최대한 확보*/

            slotSize = header->slotDir.getSlotSize( 0 );
            CSI_ASSERT( slotSize == freeSize );
            CSI_ASSERT( slotPtr );

            size -= slotSize;
            CSI_ASSERT( size > 0 );
            csiMemcpy( slotPtr, flushInfo.filterPtr + size, slotSize );
        }

        CSI_ASSERT( header->slotDir.lastOffset == ESTIMATED_LASTOFFSET );

        TEST( csiIO::appendPage( (char*)header, PAGE_SIZE, &PID ) );
        flushInfo.flushedPageCount ++;
        if( flushInfo.beginPID == NULL_PID ) flushInfo.beginPID = PID;
        flushInfo.endPID = PID;

        if( kickOutPolicy[ CSI_PAGE_TYPE_FILTER ] )    
            releaseVictimBuffer( (char*)header );
        else                        assignPID( (char*)header, PID );
    }

    flushInfo.lastFilterPID = PID;
        
    return true;

    EXCEPTION_END;

    return false;
}

int     csiPageManager::flushElapsedSec()
{
    uint64_t elapsedTime = get_cur_microseconds() - flushInfo.beginTime;
    return elapsedTime / 1000 / 1000;
}
int     csiPageManager::flushEstimationSec()
{
    int sec = ((uint64_t)flushElapsedSec()*flushInfo.estimatedCount
               /flushInfo.KVCount);

    return sec;
}

/*Group에 대한 Flush가 종료됨*/
bool    csiPageManager::flushEnd(    const char        * title,
                                    csiFlushResult    * ret )
{
    int        i;
    int        bps = 0;
    uint64_t   flushedSize;

    TEST( flushPages( CSI_PAGE_TYPE_SUPPLEMENT ) );
    TEST( flushPages( CSI_PAGE_TYPE_DPAGE ) );
    TEST( flushPages( CSI_PAGE_TYPE_NODE ) );
    TEST( flushPages( CSI_PAGE_TYPE_ROOT ) );

    if( flushInfo.KVCount )TEST( flushFilter() );
    TEST( flushInfo.dest() );

    if( flushInfo.flushedPageCount )
    {
        flushInfo.endTime = get_cur_microseconds();
        flushedSize = ((uint64_t)flushInfo.flushedPageCount)*PAGE_SIZE;

        if( flushInfo.endTime > flushInfo.beginTime )
        {
            bps = ( flushedSize * 1000 * 1000 )
                /    ( flushInfo.endTime - flushInfo.beginTime );
        }

        LOG(    "%s:\n"
                "KVCount         : %d\n"
                "pageCount       : %d(D:%d N:%d R:%d)\n"
                "flushSize       : %lld(%lldMB)\n"
                "prepareTime     : %lld us(%lld s)\n"
                "flushTime       : %lld us(%lld s)\n"
                "flushPerf       : %d BPS ( %d MPS )\n",
                title,
                flushInfo.KVCount,
                flushInfo.flushedPageCount,
                flushInfo.fpa[ CSI_PAGE_TYPE_DPAGE ].groupCount,
                flushInfo.fpa[ CSI_PAGE_TYPE_NODE ].groupCount,
                flushInfo.fpa[ CSI_PAGE_TYPE_ROOT ].groupCount,
                flushedSize,
                flushedSize/1024/1024,
                flushInfo.beginTime - flushInfo.prepareTime,
                (flushInfo.beginTime - flushInfo.prepareTime)/1000000,
                flushInfo.endTime - flushInfo.prepareTime,
                (flushInfo.endTime - flushInfo.prepareTime)/1000000,
                bps,
                bps/1024/1024 );
        printf( "%s:\n"
                "KVCount         : %d\n"
                "pageCount       : %d(D:%d N:%d R:%d)\n"
                "flushSize       : %lld(%lldMB)\n"
                "prepareTime     : %lld us(%lld s)\n"
                "flushTime       : %lld us(%lld s)\n"
                "flushPerf       : %d BPS ( %d MPS )\n",
                title,
                flushInfo.KVCount,
                flushInfo.flushedPageCount,
                flushInfo.fpa[ CSI_PAGE_TYPE_DPAGE ].groupCount,
                flushInfo.fpa[ CSI_PAGE_TYPE_NODE ].groupCount,
                flushInfo.fpa[ CSI_PAGE_TYPE_ROOT ].groupCount,
                flushedSize,
                flushedSize/1024/1024,
                flushInfo.beginTime - flushInfo.prepareTime,
                (flushInfo.beginTime - flushInfo.prepareTime)/1000000,
                flushInfo.endTime - flushInfo.prepareTime,
                (flushInfo.endTime - flushInfo.prepareTime)/1000000,
                bps,
                bps/1024/1024 );

        flushInfo.accumulatedKVCount += flushInfo.KVCount;
    }
    csiMemset( ret, 0, sizeof( csiFlushResult ) );
    ret->beginPID           =    flushInfo.beginPID;
    ret->endPID             =    flushInfo.endPID;
    ret->KVCount            =    flushInfo.KVCount;
    ret->flushedPageCount   =   flushInfo.flushedPageCount;
    for( i=0 ; i < CSI_PAGE_TYPE_FLUSH_MAX ; i ++ )
    {
        ret->pageCount[ i ] = flushInfo.fpa[ i].groupCount;
    }
    ret->lastRootPID        = 
                flushInfo.fpa[ CSI_PAGE_TYPE_ROOT ].lastPID;
    ret->lastFilterPID[0]   =   flushInfo.lastFilterPID;
    ret->filterSize[0]      =    flushInfo.filterSize;
    ret->estimatedCount     =   flushInfo.estimatedCount;
    ret->nodeMergeLevel     =    1;
    ret->groupMergeLevel    =    1;

    return true;

    EXCEPTION_END;

    return false;
}


void csiPageManager::dumpPage( char * page )
{
    csiPageHeader        * header = (csiPageHeader*)page;

    REPORT("type      : %d(%s)\n", header->type,
           csiPageManager::getPageTypeName(header->type));
    REPORT("prevPID   : %d\n", header->prevPID );
    REPORT("siblingSeq: %d\n", header->siblingSeq );
    REPORT("slotCount : %d\n", header->slotDir.slotCount );
    REPORT("lastOffset: %d\n", header->slotDir.lastOffset );
    header->slotDir.dump();
}

void csiFlushResult::add4nodeMerge( int seq, csiFlushResult * dst )
{
    CSI_ASSERT( seq < nodeMergeLevel );

    KVCount                     += dst->KVCount;
    childBeginPID[ seq ]         = dst->beginPID;
    childEndPID[ seq ]           = dst->endPID;
    childEstimatedCount[ seq ]   = dst->estimatedCount;
    flushedPageCount            += dst->flushedPageCount;
    pageCount[ CSI_PAGE_TYPE_DPAGE ] += dst-> pageCount[ CSI_PAGE_TYPE_DPAGE ];

    lastFilterPID[ seq ]    = dst->lastFilterPID[ 0 ];
    filterSize[ seq ]       = dst->filterSize[ 0 ];
}

void csiFlushResult::report( const char * title)
{
    int    i;

    REPORT(    "%s\n"
            "PID Range       : %d - %d\n"
            "KVCount         : %d\n"
            "pageCount       : %d(D:%d N:%d R:%d, F:%d)\n"
            "flushSize       : %lld (%lld MB)\n"
            "lastRootPID     : %d\n"
            "estimatedCnt    : %d\n"
            "groupMergeLevel : %d\n"
            "nodeMergeLevel  : %d\n",
            title,
            beginPID,
            endPID,
            KVCount,
            flushedPageCount,
            pageCount[ CSI_PAGE_TYPE_DPAGE ],
            pageCount[ CSI_PAGE_TYPE_NODE ],
            pageCount[ CSI_PAGE_TYPE_ROOT ],
            pageCount[ CSI_PAGE_TYPE_FILTER ],
            ((uint64_t)flushedPageCount)*PAGE_SIZE,
            ((uint64_t)flushedPageCount)*PAGE_SIZE/1024/1024,
            lastRootPID,
            estimatedCount,
            groupMergeLevel,
            nodeMergeLevel );

    if( nodeMergeLevel > 1 )
    {
        for( i=0; i < nodeMergeLevel ; i ++ )
        {
            REPORT( "\t[%8d]PID Range    : %d - %d\n"
                    "\t          FilterPID    : %d\n"
                    "\t          FilterSize   : %d\n",
                    childEstimatedCount[ i ],
                    childBeginPID[ i ],
                    childEndPID[ i ],
                    lastFilterPID[  i ],
                    filterSize[ i ] );
        }
    }
    else
    {
        REPORT( "FilterPID       : %d\n"
                "FilterSize      : %d\n",
                lastFilterPID[  0 ],
                filterSize[ 0 ] );
    }
}

void csiFlushResult::log( const char * title)
{
    int    i;

    LOG(    "%s\n"
            "PID Range       : %d - %d\n"
            "KVCount         : %d\n"
            "pageCount       : %d(D:%d N:%d R:%d F:%d)\n"
            "flushSize       : %lld (%lld MB)\n"
            "lastRootPID     : %d\n"
            "estimatedCount  : %d\n"
            "groupMergeLevel : %d\n"
            "nodeMergeLevel  : %d\n",
            title,
            beginPID,
            endPID,
            KVCount,
            flushedPageCount,
            pageCount[ CSI_PAGE_TYPE_DPAGE ],
            pageCount[ CSI_PAGE_TYPE_NODE ],
            pageCount[ CSI_PAGE_TYPE_ROOT ],
            pageCount[ CSI_PAGE_TYPE_FILTER ],
            ((uint64_t)flushedPageCount)*PAGE_SIZE,
            ((uint64_t)flushedPageCount)*PAGE_SIZE/1024/1024,
            lastRootPID,
            estimatedCount,
            groupMergeLevel,
            nodeMergeLevel );

    if( nodeMergeLevel > 1 )
    {
        for( i=0; i < nodeMergeLevel ; i ++ )
        {
            logln(    "\t[%8d]PID Range    : %d - %d\n"
                    "\t          FilterPID    : %d\n"
                    "\t          FilterSize   : %d\n",
                    childEstimatedCount[ i ],
                    childBeginPID[ i ],
                    childEndPID[ i ],
                    lastFilterPID[  i ],
                    filterSize[ i ] );
        }
    }
    else
    {
        logln(    "FilterPID       : %d\n"
                "FilterSize      : %d\n",
                lastFilterPID[  0 ],
                filterSize[ 0 ] );
    }
}

#define STORE_VAR(fd,var) CSI_ASSERT(write(fd,&var,sizeof(var))==sizeof(var));
void csiFlushResult::store( int fd )
{
    int   i;
    int   version = 0x1000;

    STORE_VAR(fd,version);
    STORE_VAR(fd,nodeMergeLevel);
    STORE_VAR(fd,groupMergeLevel);
    STORE_VAR(fd,KVCount);
    STORE_VAR(fd,beginPID);
    STORE_VAR(fd,endPID);
    for( i=0 ; i < nodeMergeLevel ; i ++ )
    {
        STORE_VAR(fd,childBeginPID[i]);
        STORE_VAR(fd,childEndPID[i]);
        STORE_VAR(fd,childEstimatedCount[i]);
        STORE_VAR(fd,lastFilterPID[i]);
        STORE_VAR(fd,filterSize[i]);
    }
    STORE_VAR(fd,flushedPageCount);
    STORE_VAR(fd,pageCount);
    STORE_VAR(fd,lastRootPID);
    STORE_VAR(fd,estimatedCount);
}
#undef STORE_VAR

#define RELOAD_VAR(fd,var) CSI_ASSERT(read(fd,&var,sizeof(var))==sizeof(var));
void csiFlushResult::reload( int fd )
{
    int   i;
    int   version = 0x1000;
    csiFlushResult ret;

    i=lseek(fd,0,SEEK_CUR);
    //i=read(fd,&ret,sizeof(ret));
    //i=lseek(fd,-sizeof(ret),SEEK_CUR);
    RELOAD_VAR(fd,version);
    printf("version : %x\n",version);
    switch( version )
    {
    case 0x1000:
        RELOAD_VAR(fd,nodeMergeLevel);
        RELOAD_VAR(fd,groupMergeLevel);
        RELOAD_VAR(fd,KVCount);
        RELOAD_VAR(fd,beginPID);
        RELOAD_VAR(fd,endPID);
        for( i=0 ; i < nodeMergeLevel ; i ++ )
        {
            RELOAD_VAR(fd,childBeginPID[i]);
            RELOAD_VAR(fd,childEndPID[i]);
            RELOAD_VAR(fd,childEstimatedCount[i]);
            RELOAD_VAR(fd,lastFilterPID[i]);
            RELOAD_VAR(fd,filterSize[i]);
        }
        RELOAD_VAR(fd,flushedPageCount);
        RELOAD_VAR(fd,pageCount);
        RELOAD_VAR(fd,lastRootPID);
        RELOAD_VAR(fd,estimatedCount);
        break;
    default:
        i=lseek(fd,i,SEEK_SET);
        RELOAD_VAR(fd,(*this));
        break;
    }
}
#undef RELOAD_VAR
