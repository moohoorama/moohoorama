#include <csiByteArray.h>
#include <csiWorkerPool.h>

ByteArray  ByteArray::nullByteArray;
int        ByteArray::resultBufferType=0;
int        ByteArray::resultBufferDefaultSize = 2048;
int        ByteArray::resultBufferPoolSize = 2048;
int        ByteArray::cassandraStyleMerge=0;
int        ByteArray::noMerge=0;
int        ByteArray::retryLimit=0;
int        ByteArray::largeValueThreshold=0;
int        ByteArray::poolParallel=4;

char      *ByteArray::resultBufferPool = NULL;
int        ByteArray::poolStat[2][ CSI_BA_POOL_MAX ];
csiConcurrentQueue      ByteArray::poolQueue[PARALLEL_MAX];

bool ByteArray::init()
{
    VoidPtr    ptr;
    int        i;

    largeValueThreshold     =
        get_property_int("result_buffer","large_value_threshold");
    resultBufferType        = 
        get_property_int("result_buffer","type");
    resultBufferDefaultSize = 
        get_property_int("result_buffer","default_size");
    resultBufferPoolSize    = 
        get_property_int("result_buffer","pool_size");
    poolParallel =
        get_property_int("result_buffer","pool_parallel");
    cassandraStyleMerge     = 
        get_property_int("result_buffer","cassandra_style_merge");
    noMerge = 
        get_property_int("result_buffer","no_merge");
    retryLimit =
        get_property_int("result_buffer","retry_limit");

    nullByteArray.allocSize =
        nullByteArray.len=0;

    for (i = 0; i < poolParallel; ++i) {
        TEST(poolQueue[i].init("BYTE_ARRAY_POOL", i, resultBufferPoolSize*2));
    }
    TEST( CSI_MALLOC( resultBufferDefaultSize * resultBufferPoolSize, 
                (void**)&resultBufferPool ) );
    for( i=0 ; i < resultBufferPoolSize ; i ++ )
    {
        ptr = (VoidPtr)(resultBufferPool + i*resultBufferDefaultSize);
        CSI_ASSERT( validationBAPtr( ptr ) );
        poolQueue[getIdx(ptr)].push( &ptr );
    }

    csiWorkerPool::registRF( ByteArray::report );

    return true;

    EXCEPTION_END;

    CSI_ASSERT( 0 );
}
bool ByteArray::dest()
{
    int i;

    for (i = 0; i < poolParallel; ++i) {
        poolQueue[i].free();
    }

    CSI_FREE( resultBufferPool );

    return true;
}

#define COPY_AND_MOVE_SRC( dst, src, size )     \
    csiMemcpy( (dst), (src), size );            \
    (src) += size;
#define COPY_AND_MOVE_DST( dst, src, size )     \
    csiMemcpy( dst, (src), size );              \
    (dst) += size;
bool ByteArray::merge( ByteArray * src )
{
    if( ( !cassandraStyleMerge ) ||
        ( len == 0 ) )
    {
        copyFrom( src );
        return true;
    }

    if( noMerge == 1 )
    {
        dump();
        REPORT("\n");
        src->dump();
        REPORT("\n");

        printf("NewKey : %s\n",body );
        printf("OldKey : %s\n",src->body );
    }
    CSI_ASSERT( noMerge == 0 );

    map<ByteArray, ByteArray>            columnMap;
    map<ByteArray, ByteArray>::iterator  itr;
    ByteArray                            newBuffer;
    short                                columnCount;
    uchar                               *dst;

    readAndMapping( &columnMap, body );
    readAndMapping( &columnMap, src->body );

    if( len + src->len >= resultBufferDefaultSize )
    {
        REPORT("@@@@@@@@@@@@ %d/%d\n",len,src->len);
        dump( 65536 );
        REPORT("\n");
        src->dump( 65536 );
        REPORT("\n");
        CSI_ASSERT( false );
    }
    newBuffer.alloc( type, len + src->len );

    columnCount=0;
    dst = newBuffer.body + sizeof( short );
    /*맨 앞 2byte에 column count 배치할 것임 */
    for( itr = columnMap.begin(); itr != columnMap.end() ; itr ++ )
    {
        COPY_AND_MOVE_DST( dst, &(itr->first.len), sizeof( short ) );
        COPY_AND_MOVE_DST( dst, itr->first.body, itr->first.len );
        COPY_AND_MOVE_DST( dst, &(itr->second.len), sizeof( int ) );
        COPY_AND_MOVE_DST( dst, itr->second.body, itr->second.len );
        columnCount ++;

        DEBUG("NAME  : %16s\n",  itr->first.body);
        CSI_ASSERT( dst - newBuffer.body <= resultBufferDefaultSize );
    }
    DEBUG("write COLUMN_COUNT : %d\n\n", columnCount );
    csiMemcpy( newBuffer.body, &columnCount, sizeof( short ) );
    newBuffer.len = dst - newBuffer.body;
    CSI_ASSERT( newBuffer.len <= resultBufferDefaultSize );

    /* oldBuffer는 free하고, newBuffer로 대체한다.*/
    this->free();
    *this = newBuffer;


    CSI_ASSERT( validationColumn( body ) );

    return true;
}

void ByteArray::readAndMapping( 
    map<ByteArray,ByteArray> *columnMap, uchar * dst )
{
    short      columnCount;
    short      len2B;
    int        len4B;
    ByteArray  name;
    ByteArray  value;
    int        i;
    
    COPY_AND_MOVE_SRC( &columnCount, dst, sizeof( columnCount ) );

    DEBUG("READ COLUMN_COUNT : %d\n", columnCount );
    for( i=0 ; i < columnCount ; i ++ )
    {
        COPY_AND_MOVE_SRC( &len2B, dst, sizeof( len2B ) );
        name.len    = len2B;
        name.body    = dst;
        dst += len2B;

        CSI_ASSERT( len2B <= resultBufferDefaultSize );


        COPY_AND_MOVE_SRC( &len4B, dst, sizeof( len4B ) );
        value.len    = len4B;
        value.body    = dst;
        dst += len4B;

        CSI_ASSERT( len4B <= resultBufferDefaultSize );

        (*columnMap)[ name ] = value;
        DEBUG("NAME  : %16s \n", name.body);
    }
    DEBUG("\n");
}

bool ByteArray::validationBAPtr( void * ptr )
{
    XINT    ptrVal;
    XINT    poolVal[2];

    ptrVal     = (XINT)ptr;
    poolVal[0] = (XINT)resultBufferPool;
    poolVal[1] = (XINT)(resultBufferPool +
        resultBufferDefaultSize * resultBufferPoolSize );
    if( ( poolVal[0] <= ptrVal ) && 
            (ptrVal + resultBufferDefaultSize <= poolVal[1] ) )
    {
        if( ( ptrVal - poolVal[0] ) % resultBufferDefaultSize 
                == 0)
        {
            return true;
        }
    }

    return false;
}

void ByteArray::report()
{
    const char title [][32]={
        "UNKNWN",
        "TEST",
        "READ",
        "COMP.",
        "MEMVAL",
        "STRVAL",
        "ROOT",
        "SCAN",
        "SLOT",
        "ASYNC.",
        "MEMGROUP",
        "SCANNER",
    };
    int i;

    banner("ResultPool");
    for (i = 0; i < poolParallel; ++i) {
        poolQueue[i].report();
    }

    for( i=0 ; i < CSI_BA_POOL_MAX ; i ++ )
    {
        REPORT("%6s ",title[i]);
    }
    REPORT("\n");
    for( i=0 ; i < CSI_BA_POOL_MAX ; i ++ )
    {
        REPORT( "%6d ", poolStat[0][i] );
    }
    REPORT("\n");
    for( i=0 ; i < CSI_BA_POOL_MAX ; i ++ )
    {
        REPORT( "%6d ", poolStat[1][i] );
    }
    REPORT("\n");
}

void    ByteArray::basicTest()
{
    map<ByteArray, ByteArray>            columnMap;
    map<ByteArray, ByteArray>::iterator  itr;
    ByteArray                            ba[2];
    int                                  oldSetting;

    uchar     data0[]={
        0x01,0x00,0x0a,0x00,
        0x62,0x73,0x61,0x6e,
        0x64,0x65,0x72,0x73,
        0x6f,0x6e,0x00,0x00,
        0x00,0x00 };
    uchar     data1[]={
        0x01,0x00,0x07,0x00,
        0x68,0x74,0x61,0x79,
        0x6c,0x65,0x72,0x00,
        0x00,0x00,0x00 };
    ba[0].len    = sizeof( data0 ) / sizeof( data0[0] );
    ba[0].body   = data0;
    ba[1].len    = sizeof( data1 ) / sizeof( data1[0] );
    ba[1].body   = data1;
    oldSetting   = cassandraStyleMerge;
    cassandraStyleMerge = 1;
    CSI_ASSERT( ba[0].merge( &ba[1] ) );
    ba[0].dump( 128 );
    REPORT("\n");
    
    readAndMapping( &columnMap, ba[0].body );
    cassandraStyleMerge = oldSetting;

    ba[0].free();
}

void    ByteArray::log( int limitLen )
{
    char        hexBuf[ HEX_BUFFER_LEN ] ={0};

    if( len == 0 )
    {
        REPORT("%4d| NULL", 0 );
    }
    else
    {
        dump_hex( (char*)body, len, (char*)hexBuf, HEX_BUFFER_LEN, 
                false/*detail*/ );
        if( limitLen > 3 )
        {
            hexBuf[ limitLen - 3]='.';
            hexBuf[ limitLen - 2]='.';
            hexBuf[ limitLen - 1]='.';
            hexBuf[ limitLen - 0]='\0';
        }
        LOG("%4d|%-40s", len, hexBuf);
    }
}


void    ByteArray::dump( int limitLen )
{
    char        hexBuf[ HEX_BUFFER_LEN ] ={0};

    if( len == 0 )
    {
        REPORT("%4d| NULL", 0 );
    }
    else
    {
        dump_hex( (char*)body, len, (char*)hexBuf, HEX_BUFFER_LEN, 
                false/*detail*/ );
        if( limitLen > 3 )
        {
            hexBuf[ limitLen - 3]='.';
            hexBuf[ limitLen - 2]='.';
            hexBuf[ limitLen - 1]='.';
            hexBuf[ limitLen - 0]='\0';
        }
        REPORT("%4d|%-40s", len, hexBuf);
    }
}

void    ByteArray::print( int limitLen )
{
    char        hexBuf[ HEX_BUFFER_LEN ] ={0};

    if( len == 0 )
    {
        printf("%4d| NULL", 0 );
    }
    else
    {
        dump_hex( (char*)body, len, (char*)hexBuf, HEX_BUFFER_LEN, 
                false/*detail*/ );
        if( limitLen > 3 )
        {
            hexBuf[ limitLen - 3]='.';
            hexBuf[ limitLen - 2]='.';
            hexBuf[ limitLen - 1]='.';
            hexBuf[ limitLen - 0]='\0';
        }
        printf("%4d|%-40s", len, hexBuf);
    }
}


bool ByteArray::validationColumn( uchar * bodyPtr )
{
    map<ByteArray, ByteArray>                  columnMap;

    if( debugging )
    {
        readAndMapping( &columnMap, bodyPtr );
    }

    return true;
}
