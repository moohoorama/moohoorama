PREFIX=./
OUTPUT=build_csi_config.mk

rm -f $OUTPUT
touch $OUTPUT

INCLUDE_DIRS="$PREFIX/include"
DIRS="$PREFIX/csi $PREFIX/util"
CLUSTER_DIRS="$PREFIX/cluster"
OTHER_DIRS="$PREFIX/test"

PRUNE_TEST="-name *_test.cc -prune"
PRUNE_BENCH="-name *_bench.cc -prune"
PRUNE_TOOL="-name dump.cc -prune"
PORTABLE_FILES=`find $DIRS $PRUNE_TEST -o $PRUNE_BENCH -o $PRUNE_TOOL -o -name '*.cc' -print | sort | sed "s,^$PREFIX/,," | tr "\n" " "`
INCLUDE_FILES=`find $INCLUDE_DIRS -name '*.h' -print | sort | sed "s,^$PREFIX/,," | tr "\n" " "`
CLUSTER_FILES=`find $CLUSTER_DIRS -name '*.cc' -print | sort | sed "s,^$PREFIX/,," | tr "\n" " "`
OTHER_FILES=`find $OTHER_DIRS -name '*.cc' -print | sort | sed "s,^$PREFIX/,," | tr "\n" " "`


set +f # re-enable globbing

# The sources consist of the portable files, plus the platform-specific port
# file.
echo "SOURCES=$PORTABLE_FILES $PORT_FILE" >> $OUTPUT
echo "INCLUDE_FILES=$INCLUDE_FILES $PORT_FILE" >> $OUTPUT
echo "CLUSTER_SOURCES=$CLUSTER_FILES $PORT_FILE" >> $OUTPUT
echo "OTHER_SOURCES=$OTHER_FILES $PORT_FILE" >> $OUTPUT

