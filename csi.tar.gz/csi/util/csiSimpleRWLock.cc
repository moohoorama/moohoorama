#include <common.h>
#include <csiStructure.h>
#include <csiSimpleRWLock.h>
#include <csiWorkerPool.h>
#include <csiUtil.h>
#define __STDC_FORMAT_MACROS
#include <inttypes.h>

#define LINK_LOCK( p, n ) if(p)(p)->next=(n); if(n)(n)->prev=(p);

int             csiSimpleRWLock::globalSpinCount = 100;
int             csiSimpleRWLock::globalSleepMsec = 100;

int             csiSimpleRWLock::missThreshold   = 100;
csiSimpleRWLock csiSimpleRWLock::globalLock;

void csiSimpleRWLock::globalInit()
{
    globalSpinCount = get_property_int("concurrency","rwlock_spin_count");
    globalSleepMsec = get_property_int("concurrency","rwlock_sleep_msec");
    missThreshold = get_property_int("concurrency","rwlock_miss_threshold");

    globalLock.initInternal( 0/*spin*/, 0/*sleep*/ );
    globalLock.next = &globalLock;
    globalLock.prev = &globalLock;
}
void csiSimpleRWLock::globalDest()
{
    csiSimpleRWLock * iter;

    for( iter = globalLock.next ; iter != &globalLock ; iter=iter->next )
    {
        LINK_LOCK( iter->prev, iter->next );
    }
}
void csiSimpleRWLock::init( const char *codeFile, 
                            int         codeLine, 
                            int         spin,
                            int         sleep )
{
    snprintf( codeName, 128, "%s:%d",codeFile, codeLine );

    initInternal( spin, sleep );

    globalLock.WLock();
    LINK_LOCK( this, globalLock.next );
    LINK_LOCK( &globalLock, this );
    globalLock.release();
}

void csiSimpleRWLock::initInternal( int spin, int sleep )
{
    status        = 0;
    blockRLock    = 0;
    RMissCount    = 0;
    WMissCount    = 0;

    if( spin == 0 )     spinCount    = globalSpinCount;
    else                spinCount    = spin;
    if( sleep == 0 )    sleepMsec    = globalSleepMsec;
    else                sleepMsec    = sleep;

    next = prev = NULL;
}
void csiSimpleRWLock::dest()
{
    LINK_LOCK( prev, next );
}
void csiSimpleRWLock::report( bool dump_stack )
{
    if( dump_stack )
    {
        dumpStack();
/*
        printf("LOCK MISS : %s[0x%" PRIxPTR "] (S:%2d B:%d R:%d W:%d conf:%d,%d)\n",
                codeName,
                (intptr_t)this,
                status,
                blockRLock,
                RMissCount,
                WMissCount,
                spinCount,
                sleepMsec);
*/
    }
/*
    REPORT("%-32s[0x%08" PRIxPTR "] (S:%2d B:%2d R:%4d W:%4d conf:%d,%d)\n",
            codeName,
            (intptr_t)this,
            status,
            blockRLock,
            RMissCount,
            WMissCount,
            spinCount,
            sleepMsec);
*/
}
void csiSimpleRWLock::reportGlobal()
{
    const int         highestCount = 8;
    int               highestVal[ highestCount ];
    int               highestIdx[ highestCount ];
    int               i;

    csiSimpleRWLock * iter;

    globalLock.RLock();

    banner( "RWLOCK");
    prepareHighestEntry( (int*)highestVal, (int*)highestIdx, highestCount );
    for( iter = globalLock.next ; iter != &globalLock ; iter=iter->next )
    {
        pickHighestEntry( (int*)highestVal, (int*)highestIdx, highestCount,
                          iter->getTotalMissCount(), (ulong)iter );
    }
    for( i = 0 ; i < highestCount ; i ++ )
    {
        if( highestIdx[ i ] != -1 )
        {
            iter = (csiSimpleRWLock*)highestIdx[ i ];
            iter->report();
        }
    }
    globalLock.release();
}
