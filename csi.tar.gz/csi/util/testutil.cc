#include <linkedList.h>
#include <stdio.h>
#include <csiInterface.h>
#include <testutil.h>
#include <sys/time.h>
#include <unistd.h>

int     perfStat                = 0;
bool    perfDone                = false;
int     perfMonitorInteralMsec  = 1000;
int     perfGraph[256]          = {0};

void setPerfInterval( int perfInterval)
{
    perfMonitorInteralMsec = perfInterval;
}
void resetPerfStat()
{
    perfStat = 0;

}
void incPerfStat( int delta )
{
    (void)__sync_add_and_fetch( &perfStat, delta );
}
int getPerfStat()
{
    return perfStat;
}

int *getPerfGraph()
{
    return (int*)perfGraph;
}

void *perfMonitor( void * arg)
{
    int       i     = 0;
    int       perf  = 0 ;
    int       prev  = 0;
    tm      * cur_tm;
    timeval   tv;
    uint64_t          startTime;
    uint64_t          midTime;
    uint64_t          endTime;
    uint64_t          recentTime;
    uint64_t          accuTime;

    printf("%19s,%15s,%15s,%15s\n",
            "TIME",
            "RECENT_QPS","ACCUMULATED_QPS","SUM" );

    midTime =
    startTime = 
    get_cur_milliseconds();
    while( !perfDone )
    {
        usleep( 1000 );
        i ++;
        if( ( i % perfMonitorInteralMsec ) == 0 )
        {
            endTime = get_cur_milliseconds();
            recentTime = endTime - midTime;
            accuTime = endTime - startTime;
            perf = getPerfStat();

            if( perfGraph[0] >= 250 )
                perfGraph[0] = 0;
            perfGraph[ perfGraph[0] + 1] = (perf-prev)*1000 / recentTime;
            perfGraph[ 0 ] ++;

            gettimeofday( &tv, NULL );
            cur_tm = localtime(&tv.tv_sec );
            printf("%04d/%02d/%02d %02d:%02d:%02d,", 
                    cur_tm->tm_year +1900,
                    cur_tm->tm_mon  + 1,
                    cur_tm->tm_mday + 0,
                    cur_tm->tm_hour,
                    cur_tm->tm_min,
                    cur_tm->tm_sec );

            printf("%15.2f,%15.2f,%15d\n",
                    (perf-prev)*1000.0f / recentTime,
                    perf*1000.0f / accuTime,
                    perf );
            prev = perf;
            midTime = endTime;

        }
    }

    return NULL;
}

void doParallelTest(void *(*routine) (void *), int parallel, bool qps )
{
    pthread_t           workerDesc[256] = {0};
    pthread_t           perfDesc;
    int                 i;
    bool                remain;

    CSI_ASSERT( parallel <= 256 );

    resetPerfStat();

    perfDone = false;
    if( qps )
    {
        (void) pthread_create(  
                &perfDesc,
                NULL,
                perfMonitor,
                NULL );
    }

    for( i = 0 ; i < parallel ; i ++ )
    {
        (void) pthread_create(  
                &(workerDesc[ i ]), 
                NULL,
                routine,
                (void*)i );
    }

    for( i = 0 ; i < parallel ; i ++ )
    {
        pthread_join( workerDesc[i], NULL );
    }
    perfDone = true;
}

