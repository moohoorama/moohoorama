#include <linkedList.h>
#include <stdio.h>
#include <csiUtil.h>

void      global_slist_init()
{
    /* nothing to do ... */
}

void slist_init( SyncLList    *slist, 
                 const char   *codeFile, 
                 int           codeLine,
                 int           spin,
                 int           sleep )
{
    slist->lock.init( codeFile, codeLine, spin, sleep );
    slist->head.next    = &slist->head;
    slist->head.prev    = &slist->head;
    slist->head.data    = NULL;
    slist->size         = 0;
}
void   slist_dest( SyncLList * slist )
{
    slist->head.next = &slist->head;
    slist->head.prev = &slist->head;
    slist->head.data = NULL;
    slist->lock.dest();
}

void      slist_WLock( SyncLList * slist )
{
    slist->lock.WLock();
}

void slist_pushHeadNolock( SyncLList * slist, LList * target )
{
    slist->size ++;
    LLIST_LINK( & slist->head, target );
    if( debugging )    slist_validation( slist );
}

void slist_pushHead( SyncLList * slist, LList * target )
{
    slist->lock.WLock();
    slist_pushHeadNolock( slist, target );
    slist->lock.release();
}

void slist_pushTail( SyncLList * slist, LList * target )
{
    LList    * prev;

    slist->lock.WLock();
    slist->size ++;
    prev = slist->head.prev;
    LLIST_LINK(prev, target );
    if( debugging )    slist_validation( slist );
    slist->lock.release();
}

LList * slist_popHead( SyncLList * slist )
{
    LList    * target;

    slist->lock.WLock();
    target = slist->head.next;
    if( target != &slist->head )
    {
        slist->size ++;
        LLIST_UNLINK( target );
    }
    else
    {
        target = NULL;
    }
    if( debugging )    slist_validation( slist );
    slist->lock.release();

    return target;
}

LList * slist_popTail( SyncLList * slist )
{
    LList    * target;

    slist->lock.WLock();
    target = slist->head.prev;
    if( target != &slist->head )
    {
        slist->size --;
        LLIST_UNLINK( target );
    }
    else
    {
        target = NULL;
    }
    if( debugging )    slist_validation( slist );
    slist->lock.release();

    return target;
}

void      slist_remove( SyncLList * slist, LList * target )
{
    slist->lock.WLock();
    slist->size --;
    LLIST_UNLINK( target );
    if( debugging )    slist_validation( slist );
    slist->lock.release();
}

void      slist_validation( SyncLList * slist )
{
    /*
    LList    * cur;
    int          count = 0;

    for(    cur = slist->head.next ; 
            cur != &slist->head ; 
            cur = cur->next, count ++ )
    {
        CSI_ASSERT( count <= slist->size );
    }
    */
}

void slist_report(  SyncLList * slist )
{
    LList    *cur;
    int       count = 0;

    slist->lock.RLock();
    REPORT("size(%d)\n", slist->size );

    if( ( 0 < slist->size ) && ( slist->size < 32 ) )
    {
        for( cur = slist->head.next ; cur != &slist->head ; cur = cur->next )
        {
            REPORT( "0x%08x ", (uintptr_t) cur->data );
            count ++;
            CSI_ASSERT( count <= slist->size );
        }
//        if(count) printf("\n");
    }
    slist->lock.release();
}
