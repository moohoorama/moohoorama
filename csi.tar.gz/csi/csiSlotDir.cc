#include <csiSlotDir.h>
#include <csiPageManager.h>


int csiSlotDir::slotLimit[CSI_SD_MAX]={0};
int csiSlotDir::supplementMinPiece = 64;

void csiSlotDir::globalInit()
{
    slotLimit[ CSI_SD_SUPER_KA  ] = get_property_int("slot_limit","super_ka");
    slotLimit[ CSI_SD_KEY_PID   ] = get_property_int("slot_limit","key_pid");
    slotLimit[ CSI_SD_KEY_ARRAY ] = get_property_int("slot_limit","key_array");
    slotLimit[ CSI_SD_KEY_VALUE ] = get_property_int("slot_limit","key_value");
    slotLimit[ CSI_SD_KEY_ONLY  ] = get_property_int("slot_limit","key_only");
    supplementMinPiece = get_property_int("slot_limit", "supplement_min_piece");
}

void csiSlotDir::init( csiSlotDirType aType, char * lastPtr )
{
    type       = aType;
    globalSeq  = 0;
    prevPID    = NULL_PID;
    beginPID   = NULL_PID;
    slotCount  = 0;
    lastOffset = getOffset( lastPtr );
}

int csiSlotDir::getUsedSize( int align )
{
    return lastOffset - getFreeSize( align );
}

int csiSlotDir::getFreeSize( int align )
{
    csiOffset         leftOffset;
    csiOffset         rightOffset;
    csiOffset       * lastDir;
    char            * slotPtr;

    lastDir    = & slotDir[ slotCount ];
    leftOffset = (((char*)lastDir) - (char*)this) + sizeof(csiOffset);
    rightOffset= lastDir[-1];
    slotPtr    = getPtr( leftOffset );
    leftOffset = getOffset( (char*)(((int)slotPtr) & (~(align-1))) );

    return rightOffset - leftOffset;
}

bool csiSlotDir::isSlotLimit()
{
    /* Slot 개수 한계가 설정되어있는 경우 */
    if( ( slotLimit[ type ] > 0 ) && ( slotCount >= slotLimit[ type ] ) )
    {
        return true;
    }
    return false;
}


char * csiSlotDir::allocSlot( int size, int align )
{
    csiOffset   estiNewDirOffset;        /* 예상 디렉토리 위치 */
    csiOffset   estiNewSlotOffset;    /* 예상 슬롯 위치 */
    csiOffset * lastDir;
    char      * slotPtr;

    if((size<0) || (isSlotLimit())) return NULL;

    /* 공간 평가. newSlot < newDir  + sizeof(csiOffset)은 공간부족. */
    lastDir = & slotDir[ slotCount ];
    estiNewDirOffset= (((char*)lastDir) - (char*)this) + sizeof(csiOffset);

    if( size == 0 )
    {    /* 최대 크기를 원할 경우 */
        estiNewSlotOffset = estiNewDirOffset + sizeof(csiOffset );
    }
    else
    {
        estiNewSlotOffset    = lastDir[-1] - size;
    }

    /* 공간 부족. 볼것도 없음 */
    if( estiNewSlotOffset > lastOffset )    return NULL;

    slotPtr = getPtr( estiNewSlotOffset );
    /* align만큼 내림 */
    estiNewSlotOffset = getOffset( (char*)(((int)slotPtr) & (~(align-1))) );

    if( estiNewSlotOffset >= estiNewDirOffset  )
    { /* 할당 성공 */
        *lastDir = estiNewSlotOffset;
        slotCount ++;

        return getPtr( estiNewSlotOffset );
    }

    return NULL;
}

bool csiSlotDir::insertKV( ByteArray *key, ByteArray *val)
{
    CSI_ASSERT((type == CSI_SD_KEY_VALUE) || (type==CSI_SD_NONE));

    int   estiSize = getCompactBASize( key ) + 
                     getCompactBASize( val );
    char *slotPtr  = allocSlot( estiSize );

    if( !slotPtr ) return false;

    slotPtr = writeCompactBA( slotPtr, key );
    slotPtr = writeCompactBA( slotPtr, val );

    return true;
}
bool csiSlotDir::insertKV4Supplemental(ByteArray *key, csiLargeValueRef *lvRef)
{
    CSI_ASSERT( type == CSI_SD_KEY_VALUE );

    int    estiSize = getCompactBASize( key ) + 1 + sizeof(*lvRef);
    char * slotPtr  = allocSlot( estiSize );

    if( !slotPtr ) return false;
    slotPtr = writeCompactBA(slotPtr, key);
    slotPtr = writeSupplement(slotPtr, lvRef);

    return true;
}

bool csiSlotDir::insertK( ByteArray *key )
{
    CSI_ASSERT( ( type == CSI_SD_KEY_ONLY ) 
              || (type == CSI_SD_KEY_ARRAY ));

    int    estiSize = getCompactBASize( key );
    char * slotPtr  = allocSlot( estiSize );

    if( !slotPtr ) return false;
    slotPtr = writeCompactBA( slotPtr, key );

    return true;
}

bool csiSlotDir::insertV( ByteArray *key )
{
    CSI_ASSERT((type == CSI_SD_VALUE_ONLY) || (type==CSI_SD_NONE));

    int    estiSize = getCompactBASize( key );
    char * slotPtr  = allocSlot( estiSize );

    if( !slotPtr ) return false;
    slotPtr = writeCompactBA( slotPtr, key );

    return true;
}


bool    csiSlotDir::insertKP( ByteArray *key, csiPageID PID )
{
    CSI_ASSERT( type == CSI_SD_KEY_PID );

    int    estiSize = getCompactBASize( key ) + sizeof( csiPageID);
    char * slotPtr  = allocSlot( estiSize );

    if( !slotPtr ) return false;
    slotPtr = writeCompactBA( slotPtr, key );
    csiMemcpy( slotPtr, &PID, sizeof( csiPageID ) );

    return true;
}

/* Value를 삽입할 수 있는 만큼 최대한 삽입하고, 나머지를 반환한다. */
ByteArray csiSlotDir::insertUtmostV(ByteArray *val, int *ret)
{
    CSI_ASSERT((type == CSI_SD_VALUE_ONLY) || (type==CSI_SD_NONE));

    int       freeSize = getFreeSize()-sizeof(csiOffset);

    /* minPiece 이상의 공간을 가졌으며, 이미 삽입된 Slot이 1개 이하여야함.
     * 왜냐하면, PID만으로 SupplementKV를 가리키기에, 
     * (기존에서 넘어온 것 + 삽입된 새 값) 둘이 한계이기 때문이다. */
    if((slotCount >= 2) || (freeSize < supplementMinPiece)){
        (*ret)=-1;
        return *val;
    }

    ByteArray _ba;
    ByteArray _ret;

    (*ret)   = slotCount;
    _ret.len = 0;

    if( freeSize >= csiSlotDir::getCompactBASize(val) ) {
        CSI_ASSERT( insertV(val) );
        return _ret;
    }
    _ba.len = freeSize-CSI_HEAD_MAXLEN;
    _ba.body= val->body +val->len - freeSize-CSI_HEAD_MAXLEN;
    if( insertV(&_ba) )
    {
        _ret.len = val->len - _ba.len;
        _ret.body= val->body;
    }
    else
    {
        _ret=*val;
    }

    return _ret;
}

void csiSlotDir::readAndCopyValue( uchar *ptr, ByteArray * ba )
{
    ByteArray      _ba;
    csiPageID      PID;
    int            cnt;
    csiPageHeader *header;
    int            i;

    CSI_ASSERT( ba->allocSize > 0 );

    if( ptr[0] == CSI_SUPPLEMENTAL ) {
        csiLargeValueRef lvRef;

        ptr++;
        csiMemcpy( &lvRef, ptr, sizeof(lvRef) );
        ptr += sizeof(lvRef);

        for(i = 0; i<lvRef.count; ++i) {
            header=(csiPageHeader*)csiPageManager::findOrReadPage(
                    lvRef.page_info+lvRef.count-i-1, NULL/*readCount*/);
            /**************** **************** ****************
             *[0.AAAAAAAAAA]*-*[0.AA][1.BBBB]*-*[0.BBB][2.CCC]*
             **************** **************** ****************
             *                        ^--------------^
             */
            if(lvRef.count-1 == i) {
                header->slotDir.readBA( lvRef.slot_idx, &_ba );
            } else {
                header->slotDir.readBA( 0, &_ba );
            }
            ba->append( &_ba );
            csiPageManager::releasePage( (char*)header );
        }
    }
    else
    {
        readCompactBA( (char*)ptr, &_ba );
        ba->copyFrom(&_ba);

    }
}

bool    csiSlotDir::removeLastSlot()
{
    if( slotCount > 0 )
    {
        slotCount --;
        if( slotCount == 0 )
        {
            beginPID = NULL_PID;
        }
        return true;
    }
    return false;
}

int        csiSlotDir::getSlotSize( int idx )
{
    int                size;

    if( idx < 0 || idx >= slotCount )    return 0;

    size = slotDir[idx -1] - slotDir[idx];
    CSI_ASSERT( size > 0 );

    return size;
}

bool    csiSlotDir::copyFrom( csiSlotDir * src )
{
    char * srcSlot;
    char * dstSlot;
    int    size;
    int    i;

    type      = src->type;
    globalSeq = src->globalSeq;
    prevPID   = src->prevPID;
    beginPID  = src->beginPID;

    for( i = 0 ; i < src->slotCount ; i++ )
    {
        srcSlot = src->getPtrBySlot( i );
        size    = src->getSlotSize( i );

        TEST( dstSlot = allocSlot( size ) );
        csiMemcpy( dstSlot, srcSlot, size );
    }

    return true;

    EXCEPTION_END;

    return false;
}

bool    csiSlotDir::setPrev( csiSlotDir * src )
{
    CSI_ASSERT( type == src->type );

    globalSeq = src->globalSeq + src->slotCount;

    return true;
}

bool    csiSlotDir::find( ByteArray key, csiPos * pos, bool exact )
{
    ByteArray    ba;
    int          seq = binarySearchInternal( key );

    if( exact == false )
    {
        /* exact가 false이면, key가 이 SlotDirectory가 가진 값을
         * 벗어나더라도, 적당히 근사값으로 커서를 옮기라는 의미 */
        if( seq < 0 ) seq = 0;
        if( seq >= slotCount ) seq = slotCount - 1;
    }

    /* KeyArray일 경우, 마지막은 바로 전 Key의 Endkey임.
     * 같을 경우, 유효함. */
    if( ( type == CSI_SD_KEY_ARRAY ) && (seq == slotCount - 1 ) &&
        ( slotCount > 0 ) )
    {
        (void) readCompactBA( getPtrBySlot( slotCount - 1 ), &ba );
        if( key == ba )
        {
            seq = slotCount - 2;
        }
        else
        {
            pos->ret        = false;
            pos->seq        = -1;
            pos->prevPID    = NULL_PID;

            return false;
        }
    }
    
    return read( seq, pos );

}

bool    csiSlotDir::read( int seq, csiPos * pos )
{
    char                * bytePtr;

    /* 이 타입 이면서 find를 호출할이 없음 */
    CSI_ASSERT( type != CSI_SD_NONE );

    pos->ret            = false;
    pos->seq            = -1;
    if( type == CSI_SD_KEY_ARRAY )
    {
        /* KEY_ARRAY일때, 마지막 Key는 range용. 읽는 대상 아님 */
        pos->remainCount    = slotCount - seq - 1;
        if( slotCount == 0 )
        {
            CSI_DASSERT( seq == 0 || seq == -1 );
            pos->remainCount = 0;
        }
    }
    else
    {
        pos->remainCount    = slotCount - seq;
    }
    if( seq <= 0 ) pos->prevPID    = prevPID;
    else           pos->prevPID    = NULL_PID;

    /* 읽을 것이 없음 */
    if( ( seq < 0 ) || ( pos->remainCount == 0 ) ) return false;

    pos->seq        = seq;
    pos->globalSeq  = seq + globalSeq;

    /* Key는 Merge하면 안된다. ColumnStyle이 아니기 때문이다. */
    bytePtr = readAndCopyCompactBA( getPtrBySlot( pos->seq ), &pos->key );
    switch( type )
    {
        case CSI_SD_KEY_PID:
            csiMemcpy( &pos->PID, bytePtr, sizeof( csiPageID ) );
            break;
        case CSI_SD_KEY_ARRAY:
            pos->PID = beginPID + pos->seq;
            bytePtr = readAndCopyCompactBA(
                    getPtrBySlot( pos->seq + 1 ), &pos->subKey );
            break;
        case CSI_SD_KEY_VALUE:
            readAndCopyValue((uchar*)bytePtr, &pos->subKey);
            break;
        default:
            CSI_ASSERT( 0 );    
    }

    pos->ret        = true;
    return true;
}


bool    csiSlotDir::sort()
{
    char          stack[ PAGE_SIZE ];
    char        * bufferOrgPtr = NULL;
    char        * bufferPtr;
    int           slotDirSize;
    int           level;
    csiOffset   * srcPtr;
    csiOffset   * dstPtr;
    ByteArray     key[2];
    int           cur[2];
    int           choice=-1;
    int           target;
    int           i;

    CSI_ASSERT( type != CSI_SD_NONE );

    slotDirSize = slotCount * sizeof( csiOffset );

    if( slotDirSize < PAGE_SIZE )
    {    /* 스택으로 수행 */
        bufferPtr = (char*)stack;
    }
    else
    {
        TEST( CSI_MALLOC( slotDirSize + CSI_ALIGN, (void**)bufferOrgPtr ) );
        bufferPtr = (char*)align( (unsigned int)bufferOrgPtr, CSI_ALIGN );
    }

    /* Merge Sort 수행 */
    srcPtr = (csiOffset*)slotDir;
    dstPtr = (csiOffset*)bufferPtr;
    for( level = 2 ; level < slotCount * 2 ; level *=2 )
    {
        target = 0;
        for( i = 0 ; i < slotCount ; i+= level )
        {
            cur[0]    = i;
            cur[1]    = i + level / 2;
            do
            {
                choice = -1;
                if( ( cur[1] == i + level ) ||
                    ( cur[1] >= slotCount ) )        choice = 0;
                if( ( cur[0] == i + level / 2 ) )    choice = 1;
                if( choice == - 1 )
                {
                    (void)readCompactBA( getPtr( srcPtr[ cur[0] ] ), &key[0] );
                    (void)readCompactBA( getPtr( srcPtr[ cur[1] ] ), &key[1] );
                    if( key[0] < key[1] )    choice = 0;
                    else                    choice = 1;
                }

                dstPtr[ target ] = srcPtr[ cur[choice] ];
                cur[choice] ++;
                target ++;
            } while(    ( target < slotCount ) &&
                        ( target < i + level ) );
            if( slotCount < i + level/2  )
            {
                CSI_ASSERT( cur[0] == slotCount );
            }
            else
            {
                CSI_ASSERT( cur[0] == i + level/2 );
                CSI_ASSERT( ( cur[1] == i + level ) || 
                        ( cur[1] == slotCount ) );
            }
        }
        csiMemcpy( srcPtr, dstPtr, slotDirSize );
    }

    if( slotDirSize >= PAGE_SIZE )    CSI_FREE( bufferOrgPtr );

    return true;

    EXCEPTION_END;

    return false;
}

void csiSlotDir::dump( int limitLen )
{
    const char      title[][8]={
        "NONE",
        "SUPER",
        "KEY_PID",
        "KEY_ARY",
        "KEY_VAL",
        "KEY_ONL",
        "VAL_ONL" };
    uchar        * cursor;
    char          hexBuf[ HEX_BUFFER_LEN ] ={0};
    csiPageID     PID;
    int           size;
    int           i;

    REPORT("[%4s %04s] globalSeq:%d lastOffset:%d prevPID:%d, beginPID:%d %s", 
        "SEQ", "OFST",globalSeq, lastOffset, prevPID, beginPID, title[type] );
    REPORT("\n");

    for( i = 0 ; i < slotCount ; i++ )
    {
        REPORT("[%4d %04d]", 
                i, slotDir[ i ] );
        cursor = (uchar*)getPtrBySlot( i );
        switch( type )
        {
            case CSI_SD_NONE:
                size = getSlotSize( i );
                dump_hex( (char*)cursor, size, (char*)hexBuf, HEX_BUFFER_LEN, 
                        false/*detail*/ );
                if( limitLen > 3 )
                {
                    hexBuf[ limitLen - 3]='.';
                    hexBuf[ limitLen - 2]='.';
                    hexBuf[ limitLen - 1]='.';
                    hexBuf[ limitLen - 0]='\0';
                }
                REPORT("%4d:%40s\n", size,hexBuf);
                break;
            case CSI_SD_SUPER_KA:
                REPORT("\n");
                ((csiSlotDir*)cursor)->dump( limitLen );
                break;
            case CSI_SD_KEY_PID:
                cursor = dumpCompactBA( cursor, limitLen );  /* Key */
                csiMemcpy( &PID, cursor, sizeof( csiPageID ) );
                REPORT(" : %d\n", PID);
                break;
            case CSI_SD_KEY_ARRAY:
                cursor = dumpCompactBA( cursor, limitLen );  /* Key */
                if( i < slotCount -1 )
                    REPORT(" %-8d", beginPID + i );
                REPORT("\n");
                break;
            case CSI_SD_KEY_VALUE:
                cursor = dumpCompactBA( cursor, limitLen );  /* Key */
                REPORT(" : ");
                cursor = dumpCompactBA( cursor, limitLen );  /* Value */
                REPORT("\n");
                break;
            case CSI_SD_KEY_ONLY:
            case CSI_SD_VALUE_ONLY:
                cursor = dumpCompactBA( cursor, limitLen ); 
                REPORT("\n");
            default:
                break;
        }
    }
}


void csiPos::report()
{
    REPORT("[%c] ",(ret)?'T':'F' );
    REPORT("seq(%8d/%8d) ",seq, globalSeq );
    REPORT("PID(%8d/%8d) ",PID, prevPID );
    key.dump(16);
    REPORT(":");
    subKey.dump(16);
}

uchar * csiSlotDir::dumpCompactBA( uchar * ptr, int limitLen )
{
    ByteArray   ba;
    char        hexBuf[ HEX_BUFFER_LEN ] ={0};

    if( ptr[0] == CSI_SUPPLEMENTAL ) {
        csiLargeValueRef lvRef;

        ptr++;
        csiMemcpy( &lvRef, ptr, sizeof(lvRef) );
        ptr += sizeof(lvRef);
        
        REPORT("[(%d:%d) %d]",lvRef.page_info,lvRef.slot_idx,lvRef.count);
    }  else {
        ptr += readCompactInt( (char*)ptr, (int*)&(ba.len) );
        ba.body = (uchar*)ptr;

        CSI_ASSERT( ba.len >= 0 );
        dump_hex( (char*)ba.body, ba.len, (char*)hexBuf, HEX_BUFFER_LEN, 
                 false/*detail*/ );
        if( limitLen > 3 ) {
            hexBuf[ limitLen - 3]='.';
            hexBuf[ limitLen - 2]='.';
            hexBuf[ limitLen - 1]='.';
            hexBuf[ limitLen - 0]='\0';
        }
        REPORT("%4d|%40s", ba.len, hexBuf);
    }

    return ptr + ba.len;
}

