#include <csiWorkerPool.h>
#include <pthread.h>
#include <time.h>
#include <csiManager.h>
#include <csiMemGroup.h>
#include <csiIO.h>

 
csiConcurrentQueue    csiWorkerPool::jobQueue;
csiConcurrentQueue    csiWorkerPool::bufferQueue;
csiJob              * csiWorkerPool::jobBuffer;

int                   csiWorkerPool::jobStats[2][CSI_JOB_MAX]; 
pthread_t           * csiWorkerPool::workerDesc;
int                   csiWorkerPool::workerCount;
int                   csiWorkerPool::workingThreadCount;
csiWorkerPoolStatus   csiWorkerPool::status;
int                   csiWorkerPool::monitoringIntervalSec;
int                   csiWorkerPool::pushSleepMsec;
int                   csiWorkerPool::popSleepMsec;

ReportFunc            csiWorkerPool::rfArray[CSI_REPORT_FUNCTION_COUNT];
int                   csiWorkerPool::rfCursor = 0;

bool csiWorkerPool::init( bool monitoring )
{
    int     i;
    int     queueSize;
    VoidPtr ptr;

    workerDesc  = NULL;

    monitoringIntervalSec   = get_property_int("monitor","interval_sec");
    queueSize               = get_property_int("worker_pool","queue_size");
    workerCount             = get_property_int("worker_pool","worker_count");
    pushSleepMsec           = get_property_int("worker_pool","push_sleep_msec");
    popSleepMsec            = get_property_int("worker_pool","pop_sleep_msec");

    rfCursor                = 0;
    csiMemset( jobStats, 0, sizeof( jobStats ) );

    TEST( jobQueue.init( "WORKER_JOB",0,queueSize * 2 ) );
    TEST( bufferQueue.init( "TASK_BUFFER",0,queueSize * 2 ) );
    TEST( CSI_MALLOC( sizeof(csiJob)*queueSize, (void**)&jobBuffer ) );
    for( i = 0 ; i < queueSize ; i ++ )
    {
        ptr = &(jobBuffer[ i ] );
        bufferQueue.push(&ptr );
    }

    /* worker로 동작할 thread 생성함 */
    status = CSI_WORKER_POOL_INIT;
    workingThreadCount  = 0;
    TEST( CSI_MALLOC( sizeof(pthread_t)*workerCount, (void**)(&workerDesc) ) );
    for( i = 0 ; i < workerCount ; i ++ )
    {
        (void) pthread_create(  &(workerDesc[ i ]), 
                                NULL,
                                workerRun,
                                (void*)NULL );
    }

    while( workingThreadCount < workerCount ) /* 모든 Worker가 구동될때까지*/
    {
        __sync_synchronize();
        usleep( pushSleepMsec * 1000 );
    }

    registRF( csiWorkerPool::report );
    if( monitoring )    asyncMonitoring();
    status = CSI_WORKER_POOL_ACTIVE;

    return true;

    EXCEPTION_END;

    CSI_ASSERT( dest() );

    return false;
}
bool csiWorkerPool::stopWorkers( bool immediate )
{
    if( immediate ) status = CSI_WORKER_POOL_IMMEDIATE_SHUTDOWN;
    else            status = CSI_WORKER_POOL_NORMAL_SHUTDOWN;

    usleep( pushSleepMsec * 1000 );

    while( workingThreadCount > 0 ) /* 모든 Worker가 멈출때까지 대기 */
    {
        __sync_synchronize();
        usleep( pushSleepMsec * 1000 );
    }

    return true;
}

bool csiWorkerPool::dest()
{
    stopWorkers( true /* immediate */ );

    if( workerDesc ) CSI_ASSERT( CSI_FREE( workerDesc ) );
    jobQueue.free();
    bufferQueue.free();
    workerDesc  = NULL;

    return true;
}

/* Monitoring 업무를 등록함 */
void csiWorkerPool::asyncMonitoring()
{
    csiJob  job;

    job.type = CSI_JOB_MONITORING;
    job.target = NULL;

    CSI_ASSERT( pushJob( job ) );
}
/*Background로 Flush(또는 nodeMerge까지)수행함*/
void csiWorkerPool::asyncFlush( void * group )
{
    csiJob  job;

    job.type = CSI_JOB_FLUSH;
    job.target = group;

    CSI_ASSERT( pushJob( job ) );
}
/*Background로 Compaction을 수행함*/
bool csiWorkerPool::asyncCompaction(    void        * group, 
                                        ByteArray     beginKey, 
                                        ByteArray     endKey,
                                        int           nodeCount,
                                        int           groupMergeLevel )
{
    csiJob  job;

    job.beginKey.alloc( CSI_BA_POOL_ASYNC_COMPACTION );
    job.endKey.alloc( CSI_BA_POOL_ASYNC_COMPACTION );
    job.type        = CSI_JOB_COMPACTION;
    job.target      = group;
    job.nodeCount   = nodeCount;
    job.groupMergeLevel = groupMergeLevel;

    job.beginKey.copyFrom( &beginKey );
    job.endKey.copyFrom( &endKey );

    /* stored table read하던 중 왔기 때문에, switch lock을 잡은 상태다
     * 따라서 너무 오래 있다간 dead lock 가능성도 있기 때문에, 
     * 시도만 해보고 안되면 빠진다.
     * 어차피 이번에 안되도 다음에 하면 된다. */
    if( pushJob( job, false /*retry */ ) == false )
    {
        /* 실패했으면, free 한다. */
        job.beginKey.free();
        job.endKey.free();

        return false;
    }
    return true;
}

bool csiWorkerPool::pushJob( csiJob job, bool retry )
{
    VoidPtr   ptr;
    csiJob  * buffer;


    while( bufferQueue.pop( &ptr ) == false )
    {
        if( retry == false ) return false;
        usleep( pushSleepMsec * 1000 );
        if( status == CSI_WORKER_POOL_IMMEDIATE_SHUTDOWN ) return true;
    }
    buffer = (csiJob*)ptr;

    csiMemcpy( buffer, &job, sizeof( csiJob ) );
    jobQueue.push( &ptr );
    __sync_add_and_fetch( & jobStats[0][ job.type ], 1 );    

    return true;
}

void * csiWorkerPool::workerRun( void * ptrArg )
{
    VoidPtr   ptr;
    csiJob  * job;

    atomicInc( & workingThreadCount, 1 );

    do
    {
        if( jobQueue.pop( & ptr ) == false )
        {
            if( status == CSI_WORKER_POOL_NORMAL_SHUTDOWN ) break;
            usleep( popSleepMsec * 1000 );
            continue;
        }
        job = (csiJob*)ptr;

        switch( job->type )
        {
            case CSI_JOB_MONITORING:
                monitoring();
                break;
            case CSI_JOB_FLUSH:
                if( job->target == NULL )
                {
                    CSI_ASSERT( csiManager::softFlushAll() );
                }
                else
                {
                    CSI_ASSERT( csiManager::flushMemGroup( 
                            (csiSIInfo*)job->target) );
                }
                break;
            case CSI_JOB_COMPACTION:
                /* job의 beginKey, endKey는 alloc했기 때문에
                 * free해줘야 한다.
                 * Compaction작업이 많이 밀려 있으면, 너무 alloc이 많이 되는
                 * 문제가 발생할 수 있는데, 일단 구현 편의상 다음과 같이
                 * 간단하게 한다. */
                CSI_ASSERT( csiManager::compaction(
                            (csiSIInfo*)job->target,
                            0,
                            job->groupMergeLevel,
                            &job->beginKey,
                            &job->endKey,
                            job->nodeCount) );

                job->beginKey.free();
                job->endKey.free();
                break;
            default:
                /* 등록되지 않은 상태는 있을 수 없음 */
                LOG( "invalid job queue %d",job->type );
                CSI_ASSERT( false );
                break;
        }
        __sync_add_and_fetch( & jobStats[1][ job->type ], 1 );  

        bufferQueue.push(&ptr );

    }
    while( status != CSI_WORKER_POOL_IMMEDIATE_SHUTDOWN );

    atomicInc( & workingThreadCount, -1 );

    return NULL;
}

void csiWorkerPool::monitoring()
{
    uint64_t prevTime, nextTime;

    while( status == CSI_WORKER_POOL_INIT )
    {
        usleep( 1000 );
    }

    prevTime = get_cur_microseconds();
    while( status == CSI_WORKER_POOL_ACTIVE )
    {
        usleep( 1000 );
        nextTime = get_cur_microseconds();
        if( (int)(nextTime - prevTime) >= monitoringIntervalSec * 1000 * 1000 )
        {
            prevTime = nextTime;
            reportAll();
            csiManager::drawAll("");
            asyncFlush( NULL );
        }
    }
}

void csiWorkerPool::registRF( ReportFunc rf )
{
    CSI_ASSERT( rfCursor <= CSI_REPORT_FUNCTION_COUNT );
    rfArray[ rfCursor++ ] = rf;
}
void csiWorkerPool::reportAll()
{
    int i;

    REPORT( 
            DOUBLE_BAR_STR
            DOUBLE_BAR_STR
            DOUBLE_BAR_STR
            "\n" );
    for( i = 0 ; i < rfCursor ; i ++ )
    {
        rfArray[ i ]();
    }
    REPORT("\n\n\n");
}

void   csiWorkerPool::report()
{
    const char jobTypeNames[][16]={
        "NONE",
        "REGISTERING",
        "MONITORING",
        "FLUSH",
        "COMPACTION"};
    int i;

    REPORT(BAR_STR BAR_STR"\n");
    banner( "csiWorkerPool");
    REPORT( "status                :%d\n"
            "worker(working/max)   :%d/%d\n"
            "monitoringIntervalSec :%d\n"
            "pushSleepMsec         :%d\n"
            "popSleepMsec          :%d\n"
            "ReportFunctions       :%d\n",
            status,
            workingThreadCount,
            workerCount,
            monitoringIntervalSec,
            pushSleepMsec,
            popSleepMsec,
            rfCursor );

    REPORT("Queue : ");
    jobQueue.report();

    REPORT("Job stats:\n");
    for( i = 0 ; i < CSI_JOB_MAX ; i ++)
    {
        REPORT("%16s %d/%d\n", 
                jobTypeNames[i], 
                jobStats[0][i],
                jobStats[1][i] );
    }
}
