
---------------------
compile
---------------------

sh> make
 


---------------------
tool
---------------------

dumpcsi -p <pageid>



---------------------
mandatory
---------------------

skvs.properties - Property file.
skvs.report		- Report of a secondary indices.
skvs.log		- Log of a fault or special issue.



---------------------
test
---------------------

./test1
./test2 -t 16 -c 10000 -k 32 -v 512
./test3 -t 16 -i 10000 -r 100000 -k 32 -v 512
./test3 -t 1 -i 400000 -r 400000 -k 32 -v 1024 -f -n


---------------------
 module
---------------------
csiInterface
	Insert	데이터 삽입	success/fail
	Read	데이터 읽기	key/value
	init	SI 초기화	success/fail
	drop	SI 제거	success/fail
	truncate	SI 재초기화(init & drop)	success/fail
	forceBlockingFlush	강제 Flush	success/fail
	getSize	SI의 크기 알기	size
	reload	서버 구동을 위한 연산	success/fail
csiGroupManager
	chooseGroup	읽고 쓸 대상 Group을 찾음	GroupID
	insert	삽입을 수행함	success/fail
	read	Read연산을 수행함	key/value
	flushMemGroup	memGroup을 stored Group으로 Flush함	success/fail
	switchMemGroup	Write대상 memGroup을 변경함	success/fail
	packingNode	Node를 Packing함	success/fail
	compaction	"Partial/Full Compaction을 함.  두 연산의 차이는 범위와 trim 여부밖에 없음"	success/fail
	chooseMinKey	여러 Key 중 가장 작은 Key를 선택함	KeyIdx
csiMemGroup
	insertAndSort	삽입하면서 동시에 정렬함	success/fail
	beginScan	Scan을 시작함(미리 첫 페이지 read해둠)	success/fail
	read	Key/value를 하나 읽어 반환함	Key/Value
	endScan	Scan이 종료됨	success/fail
csiStoredGroup
	registerStoredGroup	새롭게 생성된 StoredGroup을 등록함	success/fail
	packingNode	Node에 대한 Packing을 수행함	success/fail
	filtering	대상 Group이 해당 KV가 있을지 Filtering	success/fail
	beginScan	Scan을 시작함(미리 첫 페이지 read해둠)	success/fail
	read	Key/value를 하나 읽어 반환함	Key/Value
	endScan	Scan이 종료됨	success/fail
csiWorker
	asyncFlush	Background로 Flush(또는 packing까지)수행함	None
	asyncCompaction	Background로 Compaction을 수행함	None
csiPageManager
	flushGroupBegin	어떤 Group에 대한 flush를 시작함	success/fail
	insertToDPage	Dpage에 KV를 넣음.	success/fail
	insertToNode	Node에 K를 넣음.	success/fail
	makeToRoot	Root를 생성함	success/fail
	flushGroupEnd	Group에 대한 Flush가 종료됨	success/fail
	getDPage	Dpage하나를 읽음	Dpage
	getNode	Node 하나를 읽음	Node
	getRoot	Root 하나를 읽음	Root
	trimGroup	Group 하나를 통째로 Trim함	success/fail
csiIO
	append	데이터를 추가로 기록함	PageID
	read	데이터를 읽음	data


