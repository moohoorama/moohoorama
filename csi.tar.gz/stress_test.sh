rm /mnt/sata/test.out
./test2 -t 16 -c 10000 -k 32 -v 512 > /dev/null
./test3 -t 16 -i 10000 -r 100000 -k 32 -v 512  > /dev/null

./test3 -t 1 -i 400000 -r 400000 -k 32 -v 1024 > /dev/null
./test3 -t 1 -i 400000 -r 400000 -k 32 -v 1024 -f > /dev/null
./test3 -t 1 -i 400000 -r 400000 -k 32 -v 1024 -f -n > /dev/null
./test3 -t 1 -i 400000 -r 400000 -k 32 -v 1024 -f -c > /dev/null

./test3 -t 4 -i 100000 -r 100000 -k 32 -v 1024 > /dev/null
./test3 -t 4 -i 100000 -r 100000 -k 32 -v 1024 -f > /dev/null
./test3 -t 4 -i 100000 -r 100000 -k 32 -v 1024 -f -n > /dev/null
./test3 -t 4 -i 100000 -r 100000 -k 32 -v 1024 -f -c > /dev/null

./test3 -t 4 -i 1000000 -r 1000000 -k 16 -v 990 -f > /dev/null

./test3 -t 16 -i 16384 -r 1000000 -k 16 -v 990 -f > /dev/null
