#include <stdio.h>
#include <csiInterface.h>
#include <linenoise.h>
#include <string.h>
#include <csiManager.h>

// Declare variable
enum
{
    CONTEXT_SINAME,
    CONTEXT_LIMIT,
    CONTEXT_MAX
};

const int   TOKEN_LEN       = 16;
const int   DEFAULT_STR_LEN = 256;
const int   CONTEXT_STR_LEN = 256;
const int   MAX_LIMIT = 100;
char        *HISTORY_FILE   =(char*)"history.txt";

char gContext[CONTEXT_MAX][ CONTEXT_STR_LEN ];
char gRecentKey[MAX_LIMIT][ DEFAULT_STR_LEN ];

// Declare function
void printTitle();
void makePrompt( char * str);
void init();
void loadToken();
void completion(const char *buf, linenoiseCompletions *lc);

void split( char * line, char ** strPtrs );
void doCommand( char * line );

typedef bool (*tokenFunc)(int * tokens, char ** strPtrs, int tokenLen );
bool printFull( int * tokens, char ** strPtrs, int tokenLen );

/****************************** Load tokens **************************/

/**************************** Declare Functions **********************/
#define TOKEN(x,y) bool run##x(int * tokens, char ** strPtrs, int tokenLen );
#include "token.list"
#undef TOKEN 

/*************************** Assign enumeration **********************/
#define TOKEN(x,y) TOKEN_##x,
enum {
#include "token.list"
    TOKEN_MAX,
};
#undef TOKEN 
const char  * gToken[ TOKEN_MAX ];
const char  * gDesc[ TOKEN_MAX ];
tokenFunc     gFuncMap[ TOKEN_MAX ];

/************************* Set name and description ********************/
void loadToken()
{
#define TOKEN(x,y) gToken[TOKEN_##x]=#x;gDesc[TOKEN_##x]=y;
#include "token.list"
#undef TOKEN 

#define TOKEN(x,y) gFuncMap[TOKEN_##x]=run##x;
#include "token.list"
#undef TOKEN 
}

int main(int argc, char **argv)
{
    char        prompt[ DEFAULT_STR_LEN ];
    char        *line;

    CSI_ASSERT( csiInit( false /*monitoring*/, true/*signalHandling*/, true/*force std*/ )  );

    init();
    makePrompt( prompt );
    printTitle();

    while((line = linenoise( prompt )) != NULL) {
        /* Do something with the string. */
        if (line[0] != '\0' && line[0] != '/') {
            linenoiseHistoryAdd(line); /* Add to the history. */
            linenoiseHistorySave(HISTORY_FILE); /* Save the history on disk. */
            doCommand( line );
        } else if (!strncmp(line,"/historylen",11)) {
            /* The "/historylen" command will change the history len. */
            int len = atoi(line+11);
            linenoiseHistorySetMaxLen(len);
        } else if(!strcmp(line,"/cls")){
            linenoiseClearScreen();
        } else if (line[0] == '/') {
            printf("Unreconized command: %s\n", line);
        }
        free(line);
        makePrompt( prompt );
    }

    CSI_ASSERT( csiDest( true /* immediate */ ) );

    return 0;
}

int getToken( char * str )
{
    int i;

    for( i = 0 ; i < TOKEN_MAX ; i ++ )
    {
        if( !strcasecmp( str, gToken[i] ) ) return i;
    }
    return TOKEN_PARSING_ERROR;
}

void doCommand( char * line )
{
    char        *strPtrs[ TOKEN_LEN ];
    int         tokens[ TOKEN_LEN ];
    int         tokenLen=0;
    char        **ptr;
    uint64_t    startTime;
    uint64_t    endTime;
    uint64_t    durTime;
    bool        ret;
    int         i;

    split( line, (char**)strPtrs  );

    for( i = 0 ; strPtrs[ i ] != NULL ; ptr ++, i ++ )
    {
        tokens[ i ] = getToken( strPtrs[ i ] );
        tokenLen ++;
    }

    startTime = get_cur_milliseconds();
    ret = gFuncMap[ tokens[0] ]( (int*)tokens, (char**)strPtrs, tokenLen );
    endTime = get_cur_milliseconds();
    durTime = endTime - startTime;

    if( ret )
    {
        printf("Success. %f sec\n\n", durTime/1000.0);
    }
    else
    {
        printf("Failure. %f sec\n\n", durTime/1000.0);
    }

}

bool printNode( int * tokens, char ** strPtrs, int tokenLen )
{
    int           i;
    int           j;
    int           limit = atoi( gContext[ CONTEXT_LIMIT ] );
    char        * name = gContext[ CONTEXT_SINAME ];
    csiSIInfo   * si;
    csiStoredGroup  * storedGroup;
    csiSGCursor       sgCursor;

    if( tokenLen >= 2 )
    {
        /* set name */
        name = strPtrs[ 1 ];
        if( tokenLen >= 3 )
        {
            limit = atoi( strPtrs[ 2 ] );
        }
    }

    si = csiManager::chooseSI( strlen(name), name, false/*XLock*/);
    CSI_ASSERT( si );
    si->switchLock.RLock();
    
    i = 0;
    j = 0;
    storedGroup = (csiStoredGroup*)si->storedGroup;
    while( storedGroup != NULL )
    {
        REPORT("[RootPID:%10d] %d/%d\n",storedGroup->getRPID(),i,j );
        storedGroup->initCursor( &sgCursor, CSI_POS_NODE );

        while( !sgCursor.done )
        {
//            sgCursor.pos[ CSI_POS_NODE ].report();
//            REPORT("\n");
            storedGroup->nextCursor( &sgCursor );
            j ++;
            if( j >= limit ) break;
        }
        storedGroup->destCursor( &sgCursor );
        storedGroup = storedGroup->getNext();
        if( j >= limit ) break;
        i++;
    }
    REPORT("[RootPID:%10s] %d/%d\n","Done",i,j);

    si->switchLock.release();
    csiManager::releaseSIMapLock();

    return true;
}

bool printFull( int * tokens, char ** strPtrs, int tokenLen )
{
    int           handle;
    csiResult   * ret;
    int           j;
    int           limit = atoi( gContext[ CONTEXT_LIMIT ] );
    char        * name = gContext[ CONTEXT_SINAME ];

    
    if( tokenLen >= 2 )
    {
        /* set name */
        name = strPtrs[ 1 ];
        if( tokenLen >= 3 )
        {
            limit = atoi( strPtrs[ 2 ] );
        }
    }

    j = 0;
    if( ( handle = csiScan( strlen(name), name, OP_GTE, limit, 0, NULL ) ) != -1 )
    {
        while( ( ret = csiScanNext( handle ) )->keyLen > 0 )
        {
            while( ret->keyLen > 0 )
            {
                printf("%4d : %s\n",ret->keyLen, ret->keyBody );
                if( tokens[ 0 ] == TOKEN_LIST )
                {
                    print_hex( (char*)ret->valBody, ret->valLen );
                }
                strncpy( gRecentKey[ j % MAX_LIMIT ], (char*)ret->keyBody, 
                        ( ret->keyLen < DEFAULT_STR_LEN ) ?
                        ret->keyLen : DEFAULT_STR_LEN );

                ret ++;
                j++;
            }
        }
        CSI_ASSERT( csiScanEnd( handle ) );

        printf("Read %d count.\n", j );
    }
    else
    {
        return false;
    }

    return true;
}

void split( char * line, char ** strPtrs )
{
    char    * cur = line-1;
    int     ptrCursor = 0;
    char    * begin = NULL;
    bool    end = false;
    int     i;

    do
    {
        cur ++;
        if( (*cur) == '\0' ) end=true;
        if( (*cur) != ' ' && (*cur) != '\0' )
        {
            if( begin == NULL )
            {
                begin = cur;
            }
        }
        else
        {
            if( begin )
            {
                if( ptrCursor+1 >= TOKEN_LEN )
                {
                    strPtrs[0] = (char*)gToken[ TOKEN_TOO_LONG ];
                    return;
                }
                strPtrs[ ptrCursor++ ] = begin;
                *cur = '\0';
                begin = NULL;
            }
        }
    }
    while( !end );
    strPtrs[ ptrCursor ] = NULL;
}

void printTitle()
{
    printf("===============================================\n");
    printf("COS Command Line Interface [%s %s]\n", __DATE__, __TIME__);
    printf("SAMSUNG SWC CludOS Lab. Storage Part\n");
    printf("-----------------------------------------------\n");
    printf("help, quit, exit\n");
    printf("===============================================\n");

}
void makePrompt( char * str)
{
    int i;

    str[0]='\0';
    for( i = 0 ; i < CONTEXT_MAX ; i ++)
    {
        if( i != 0 )
        {
            strcat( str, ":" );
        }
        strcat( str, gContext[i]);
    }
    strcat( str, "> ");
}

void init()
{
    int i;

    loadToken();
    /*Default*/
    snprintf( gContext[ CONTEXT_SINAME ], CONTEXT_STR_LEN, "");
    snprintf( gContext[ CONTEXT_LIMIT ], CONTEXT_STR_LEN, "100");

    linenoiseSetCompletionCallback(completion);
    linenoiseHistoryLoad(HISTORY_FILE); /* Load the history at startup */

    for( i = 0 ; i < MAX_LIMIT ; i ++ )
    {
        gRecentKey[ i ][0]='\0';
    }
}


void completion(const char *buf, linenoiseCompletions *lc) {
    int i;
    int len = strlen(buf);

    for( i = 0 ; i < TOKEN_END_OF_COMMAND; i ++ )
    {
        if( !strncasecmp( buf, gToken[i], len ) ) 
        {
            linenoiseAddCompletion(lc, (char*)gToken[i] );
        }
    }
    for( i = 0 ; i < MAX_LIMIT ; i ++ )
    {
        if( !strncasecmp( buf, gRecentKey[i], len ) ) 
        {
            linenoiseAddCompletion(lc, (char*)gRecentKey[i] );
        }
    }
}

bool runHELP(int * tokens, char ** strPtrs, int tokenLen )
{
    int i;

    for( i = 0 ; i < TOKEN_END_OF_COMMAND; i ++ )
    {
        printf("%-20s %s\n", gToken[ i ], gDesc[ i ] );
    }

    return true;
}
bool runHISTORY(int * tokens, char ** strPtrs, int tokenLen )
{
    char      text[ DEFAULT_STR_LEN ];
    FILE    * fp = fopen(HISTORY_FILE,"rt");
    if( fp != NULL )
    {
        while( fgets( text, DEFAULT_STR_LEN, fp ) )
        {
            printf("%s",text);
        }
        fclose(fp);
    }

    return true;
}
bool runCLS(int * tokens, char ** strPtrs, int tokenLen )
{
    linenoiseClearScreen();

    return true;
}
bool runEXIT(int * tokens, char ** strPtrs, int tokenLen )
{
    exit( 0 );
}
bool runQUIT(int * tokens, char ** strPtrs, int tokenLen )
{
    exit( 0 );
}
bool runSHOW(int * tokens, char ** strPtrs, int tokenLen )
{
    csiReportAll();
}
bool runLIST(int * tokens, char ** strPtrs, int tokenLen )
{
    return printFull( (int*)tokens, (char**)strPtrs, tokenLen );
}
bool runKEY(int * tokens, char ** strPtrs, int tokenLen )
{
    return printFull( (int*)tokens, (char**)strPtrs, tokenLen );
}
bool runNODE(int * tokens, char ** strPtrs, int tokenLen )
{
    return printNode( (int*)tokens, (char**)strPtrs, tokenLen );
}
bool runRELOAD(int * tokens, char ** strPtrs, int tokenLen )
{
    csiReload();

    return true;
}
bool runSTORE(int * tokens, char ** strPtrs, int tokenLen )
{
    csiStore();
    return true;
}
bool runGET(int * tokens, char ** strPtrs, int tokenLen )
{
    char        * siname = gContext[ CONTEXT_SINAME ];
    char        * key;
    int           valLen;
    char        * valBuf;
    
    if( tokenLen < 2 )
    {
        printf("not enough argument.\n");
        return false;
    }

    /* set siname */
    key = strPtrs[ 1 ];
    if( tokenLen >= 3 )
    {
        siname = strPtrs[ 2 ];
    }

    if( !csiRead( strlen(siname),siname, strlen(key), key,
                &valLen,&valBuf ) )
    {
        printf("invalid key\n");
        return false;
    }
    if( valLen )
    {
        print_hex( (char*)valBuf, valLen );
        csiReadEnd( valBuf );
    }

    return true;
}
bool runTOTALSIZE(int * tokens, char ** strPtrs, int tokenLen )
{
    printf("TotalSize    : %lld\n", 
            csiGetSize( 
                strlen( gContext[ CONTEXT_SINAME ] ),
                gContext[ CONTEXT_SINAME ] ) );

    return true;
}
bool runSET(int * tokens, char ** strPtrs, int tokenLen )
{
    char        * siname = gContext[ CONTEXT_SINAME ];

    if( tokenLen < 3 )
    {
        printf("not enough argument.\n");
        return false;
    }

    if( tokenLen > 3 )
    {
        siname = strPtrs[ 3 ];
    }

    csiInsert(  strlen(siname),siname, 
            strlen( strPtrs[1] ), strPtrs[1] ,
            strlen( strPtrs[2] ), strPtrs[2] ,
            0 );

    return true;
}
bool runDEL(int * tokens, char ** strPtrs, int tokenLen )
{
    char        * siname = gContext[ CONTEXT_SINAME ];

    if( tokenLen < 2 )
    {
        printf("not enough argument.\n");
        return false;
    }

    if( tokenLen > 2 )
    {
        siname = strPtrs[ 2 ];
    }

    csiDelete(  strlen(siname),siname, strlen( strPtrs[1] ), strPtrs[1] );

    return true;
}

bool runSPACE(int * tokens, char ** strPtrs, int tokenLen )
{
    char * siname;

    if( tokenLen < 2 )
    {
        printf("not enough argument.\n");
        return false;
    }

    if( tokens[1] != TOKEN_PARSING_ERROR ) /* must no token */
    {
        printf("invalid name.\n");
        return false;
    }
    strncpy( gContext[ CONTEXT_SINAME ], strPtrs[1],CONTEXT_STR_LEN );
    csiCreate( strlen( strPtrs[1] ), strPtrs[1] );

    return true;
}
bool runREPLAY(int * tokens, char ** strPtrs, int tokenLen )
{
    csiReplay();

    return true;
}
bool runLIMIT(int * tokens, char ** strPtrs, int tokenLen )
{
    char * siname;
    int     i;

    if( tokenLen < 2 )
    {
        printf("not enough argument.\n");
        return false;
    }

    if( tokens[1] != TOKEN_PARSING_ERROR ) /* must no token */
    {
        printf("invalid limit.\n");
        return false;
    }

    i = atoi( strPtrs[1] );
    if( i > MAX_LIMIT )
    {
        printf("too high.\n");
        i = MAX_LIMIT;
    }
    snprintf( gContext[ CONTEXT_LIMIT ], CONTEXT_STR_LEN,"%d",i );

    return true;
}
bool runCOMPACTION(int * tokens, char ** strPtrs, int tokenLen )
{
    csiForceBlockingCompactionAll();

    return true;
}
bool runFLUSH(int * tokens, char ** strPtrs, int tokenLen )
{
    return csiForceBlockingFlushAll();
}
bool runNODEMERGE(int * tokens, char ** strPtrs, int tokenLen )
{
    csiForceBlockingNodeMergeAll();

    return true;
}
bool runEND_OF_COMMAND(int * tokens, char ** strPtrs, int tokenLen )
{
    printf("%s\n", gDesc[ tokens[0] ] );

    return true;
}
bool runTOO_LONG(int * tokens, char ** strPtrs, int tokenLen )
{
    printf("%s\n", gDesc[ tokens[0] ] );

    return true;
}
bool runPARSING_ERROR(int * tokens, char ** strPtrs, int tokenLen )
{
    printf("%s\n", gDesc[ tokens[0] ] );

    return true;
}
