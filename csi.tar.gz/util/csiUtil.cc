#include <csiUtil.h>
#include <csiByteArray.h>
#include <csiStructure.h>

#include <stdarg.h>
#include <iostream>
#include <sys/time.h>
#include <unistd.h>
#include <execinfo.h>
#include <signal.h>
#include <INIReader.h>
#include <testutil.h>

#define              DEPTH            1

void    open_log( bool forcerReportStdout );
void    log( const char *format, ...);
void    close_log();
void    load_properties( const char * fileName );

void    drawOpen();
void    drawClose();

template<typename TYPE> TYPE get_property( const char * name );

FILE                            * reportFP = NULL;
FILE                            * drawFP = NULL;
INIReader                         iniReader(PROPERTY_FILE);

int                               globalLogFd=-1;
int                               dumpLineSize;
int                               dumpColumnSize;
int                               debugging;
int                               memStatEnable=true;

unordered_map<SimpleHash, MemStatInfo > memStatMap;
csiSimpleRWLock                         memStatLock;

int                barColor    = 0;
const int          SSIZEX      = 2;
const int          SSIZEY      = 16;
const int          WIDTH       = 1024;
const int          PERF_WIDTH  = 16;
const int          PERF_HEIGHT = 256;
const int          PERF_MAX    = 160000;
int                barIdx      = PERF_HEIGHT/SSIZEY;

int leftX[DEPTH]    = {-1};
int rightX[DEPTH]   = {-1};

int        get_property_int( const char * category,  const char * name )
{
    return iniReader.GetInteger(category, name, -1 );
}

string    get_property_string( const char * category,  const char * name )
{
    return iniReader.Get(category, name, "UNKNOWN" );
}

void    dumpStack()
{
    void *array[1024];
    size_t size;


    // get void*'s for all entries on the stack
    size = backtrace(array, 1024);

    // print out all the frames to stderr
    backtrace_symbols_fd(array, size, STDERR_FILENO);
    backtrace_symbols_fd(array, size, globalLogFd);

}

void sigHandler(int sig) 
{
    fprintf(stderr, "Error: signal %d:\n", sig);
    fprintf(reportFP, "Error: signal %d:\n", sig);

    dumpStack();
    exit(1);
}


/* util쪽을 구동시에 초기화함 */
bool initUtil( bool signalHandling, bool forcerReportStdout )
{
    load_properties( PROPERTY_FILE );
    open_log( forcerReportStdout );

    global_slist_init();

    dumpLineSize    = get_property_int("log","dump_line_size");
    dumpColumnSize  = get_property_int("log","dump_column_size");
    debugging       = get_property_int("common","debugging");
    memStatEnable   = get_property_int("common","mem_stat_enable");

    CSI_SRWL_INIT( &memStatLock );

    if( signalHandling )
    {
        /* callstack 찍기 위한 Signal 등록 */
        signal(SIGSEGV, sigHandler );
        signal(SIGBUS, sigHandler );
        signal(SIGFPE, sigHandler );
    }

    return true;
}

bool destUtil()
{
    memStatLock.dest();
    close_log();

    return true;
}

void    open_log( bool forcerReportStdout )
{
    char logFileName[256];
    char reportFileName[256];
    int  stdout_flag;

    stdout_flag = get_property_int("monitor","stdout");
    strcpy( logFileName, (get_property_string("log","file_name")).c_str() );
    strcpy( reportFileName, (get_property_string("monitor","file_name")).c_str() );

    globalLogFd=open( logFileName, O_RDWR | O_APPEND | O_CREAT,644 );
    CSI_ASSERT( globalLogFd );

    if( stdout_flag || forcerReportStdout )
    {
        reportFP = stdout; 
    }
    else
    {
        reportFP = fopen( reportFileName, "a" );
    }
    CSI_ASSERT( reportFP );

    drawOpen();
            
}

void    close_log()
{
    close(globalLogFd );
    globalLogFd = -1;
    drawClose();
    fclose( reportFP );
    reportFP = NULL;
}

void    log_prefix( const char * codeFile, int codeLine)
{
    tm        * cur_tm;
    timeval     tv;

    gettimeofday( &tv, NULL );
    cur_tm = localtime(&tv.tv_sec );

    log( "[%04d/%02d/%02d %02d:%02d:%02d %24s:%-4d] ", 
            cur_tm->tm_year +1900,
            cur_tm->tm_mon  + 1,
            cur_tm->tm_mday + 0,
            cur_tm->tm_hour,
            cur_tm->tm_min,
            cur_tm->tm_sec,
            codeFile,
            codeLine );
}
void  log( const char *format, ...)
{
    va_list     arg;
    char        buffer[ HEX_BUFFER_LEN ] ={0};
    int         len;
    int         write_len;

    if( globalLogFd != -1 )
    {
        va_start( arg, format);
        (void)vsnprintf( buffer, HEX_BUFFER_LEN,  format, arg);
        va_end( arg);  
        len = strlen( buffer );
        write_len = write(globalLogFd,buffer,len);
        assert( write_len == len );
    }
}
void  logln( const char *format, ...)
{
    va_list     arg;
    char        buffer[ HEX_BUFFER_LEN ] ={0};
    int         len;
    int         write_len;

    if( globalLogFd != -1 )
    {
        va_start( arg, format);
        (void)vsnprintf( buffer, HEX_BUFFER_LEN,  format, arg);
        va_end( arg);
        len = strlen( buffer );
        write_len = write(globalLogFd,buffer,len);
        assert( write_len == len );
        log("\n");
    }
}


void    syncLogReport()
{
    fsync( globalLogFd );
    fflush( reportFP );
}

void    banner( const char * str )
{
    REPORT(BAR_STR"\n");
    REPORT("%s\n",str);
    REPORT(BAR_STR"\n");
}

void    report_prefix( const char * codeFile, int codeLine)
{
    tm        * cur_tm;
    timeval     tv;

    gettimeofday( &tv, NULL );
    cur_tm = localtime(&tv.tv_sec );

    report_text( "[%04d/%02d/%02d %02d:%02d:%02d %24s:%-4d] ", 
            cur_tm->tm_year +1900,
            cur_tm->tm_mon  + 1,
            cur_tm->tm_mday + 0,
            cur_tm->tm_hour,
            cur_tm->tm_min,
            cur_tm->tm_sec,
            codeFile,
            codeLine );
}
void  report_text( const char *format, ...)
{
    va_list        arg;

    if( reportFP )
    {
        va_start( arg, format);
        (void)vfprintf( reportFP, format, arg);
        va_end( arg);  
    }
}

void    debug_prefix( const char * codeFile, int codeLine)
{
    tm        * cur_tm;
    timeval     tv;

    if( debugging )
    {
        gettimeofday( &tv, NULL );
        cur_tm = localtime(&tv.tv_sec );

        debug_text( "[%04d/%02d/%02d %02d:%02d:%02d %24s:%-4d] ", 
                cur_tm->tm_year +1900,
                cur_tm->tm_mon  + 1,
                cur_tm->tm_mday + 0,
                cur_tm->tm_hour,
                cur_tm->tm_min,
                cur_tm->tm_sec,
                codeFile,
                codeLine );
    }
}
void  debug_text( const char *format, ...)
{
    va_list        arg;

    if( debugging )
    {
        if( reportFP )
        {
            va_start( arg, format);
            (void)vfprintf( reportFP, format, arg);
            va_end( arg);  
        }
    }
}
void drawOpen()
{
    if( !drawFP )
    {
        drawFP = fopen( "draw.svg", "w" );
        CSI_ASSERT( drawFP );
        fprintf(drawFP,
                "<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n");
        fprintf(drawFP,
           "<defs>\n"
           "<linearGradient id=\"grad1\" x1=\"0%%\" y1=\"0%%\" x2=\"0%%\" y2=\"100%\">\n"
           "<stop offset=\"0%%\" style=\"stop-color:rgb( 64,128,255);stop-opacity:1\" />\n"
           "<stop offset=\" 20%%\" style=\"stop-color:rgb(192,224,255);stop-opacity:1\" />\n"
           "<stop offset=\" 60%%\" style=\"stop-color:rgb(224,240,255);stop-opacity:1\" />\n"
           "<stop offset=\"100%%\" style=\"stop-color:rgb(128,192,255);stop-opacity:1\" />\n"
           "</linearGradient>\n"
           "</defs>\n"
           );
    }
}
void drawClose()
{
    if( drawFP )
    {
        fprintf(drawFP,"</svg>");
        fclose( drawFP );
        drawFP = NULL;
    }
}

void drawText( int x, int y, char * str )
{
    drawOpen();
    fprintf( drawFP, "<text x=\"%d\" y=\"%d\"> %s </text>\n",
            x,y, str );
}
void drawBox( int x, int y, int width, int height, int color )
{
    drawOpen();
    fprintf( drawFP, "<rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill=\"url(#grad1)\" />\n",
            x,y,width,height );
//            ((color & 4)>>2)*0xc0, ((color & 2)>>1)*0xc0, (color & 1)*0xc0  );
}

void    drawLine( int x,int y,int xx,int yy, int color )
{
    drawOpen();
    fprintf( drawFP,
            "<line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" "
            "style=\"stroke:rgb(%d,%d,%d);stroke-width:2\"/> \n",
            x,y,xx,yy,
            ((color & 4)>>2)*0xc0, ((color & 2)>>1)*0xc0, (color & 1)*0xc0  );
}
void drawGroup( char *k1, char *k2, int level)
{
    int a,b;

    a = k1[0]*256 + k1[1];
    b = k2[0]*256 + k2[1];

    a = a*WIDTH/65536;
    b = b*WIDTH/65536 + SSIZEX;

    if( leftX[ level ] == -1 )
    {
        leftX[ level ] = a;
        rightX[ level ] = b;
    }
    else
    {
        if( a <= rightX[ level ] )
        {
            rightX[ level ] = b;
        }
        else
        {
            drawBox( 
                    leftX[ level ],
                    (barIdx+level)*SSIZEY,
                    (rightX[ level ]-leftX[ level ]),
                    SSIZEY,
                    barColor );
            leftX[ level ]=a;
            rightX[ level ]=b;
        }
    }
}
void drawGroupEnd()
{
    int next = false;
    int i;

    for( i = 0 ; i < DEPTH ; i ++)
    {
        if( leftX[ i ] != -1 )
        {
            drawBox( 
                    leftX[ i ],
                    (barIdx+i)*SSIZEY,
                    (rightX[ i ]-leftX[ i ]),
                    SSIZEY,
                    barColor );
            next = true;
        }
        leftX[i]=-1;
        rightX[i]=-1;
    }
    if( next ) barIdx +=DEPTH;

    barColor ++;
}

void drawPage( char * str )
{
    int             prev;
    tm            * cur_tm;
    timeval         tv;
    char            text[256];
    int           * perfGraph = getPerfGraph();
    int             i;

    gettimeofday( &tv, NULL );
    cur_tm = localtime(&tv.tv_sec );

    sprintf( text, "%02d:%02d:%02d %s", 
            cur_tm->tm_hour,
            cur_tm->tm_min,
            cur_tm->tm_sec,
            str );
    drawText( WIDTH+128, barIdx * SSIZEY, text );

    prev = 0;
    for( i = 0 ; i < perfGraph[0]; i ++ )
    {
        drawLine( 
                i*PERF_WIDTH,
                PERF_HEIGHT - prev,
                (i+1)*PERF_WIDTH-1,    
                PERF_HEIGHT 
                    - perfGraph[ i ]*PERF_HEIGHT/PERF_MAX,
                7 );
        prev =  perfGraph[ i ]*PERF_HEIGHT/PERF_MAX;
    }

    barIdx = PERF_HEIGHT/SSIZEY;
    barColor = 0;
    drawClose();
}



void    print_hex( char * target_ptr, int length )
{
    char    buffer[ HEX_BUFFER_LEN ] ={0};

    dump_hex( target_ptr, length, (char*)buffer, HEX_BUFFER_LEN );
    printf("%s\n",buffer );
}
void    report_hex( char * target_ptr, int length )
{
    char    buffer[ HEX_BUFFER_LEN ] ={0};

    dump_hex( target_ptr, length, (char*)buffer, HEX_BUFFER_LEN );
    report_text("%s\n",buffer );
}
void    log_hex( char * target_ptr, int length )
{
    char    buffer[ HEX_BUFFER_LEN ] ={0};

    dump_hex( target_ptr, length, (char*)buffer, HEX_BUFFER_LEN );
    log("\n%s\n",buffer );
}

void    dump_hex( char * target_ptr, int length, char * outbuf, int outlen, bool detail ) {
    int i;
    int j;
    int k;
    int len=0;

    /*
    for(i = 0; i < length; ++i) {
        if(( (i%dumpLineSize) == 0) && detail) {
            len+=snprintf(outbuf+len, outlen-len, "%04x : ", i );
        }
        
        if(len > outlen) break;
    }
    */


    for( i = 0 ; i < length ; i += dumpLineSize )
    {
        if( len > outlen) break;
        if( detail )      len+=snprintf(outbuf+len, outlen-len, "%04x : ", i );

        for( j = i ; 
             (j < i+dumpLineSize) && ( j < length ) ; 
             j += dumpColumnSize )
        {
            for(    k = j ; 
                    ( k < j+dumpColumnSize ) & ( k < length ) ; 
                    k ++ )
            {
                if( len > outlen) break;
                len+=snprintf(outbuf+len, outlen-len, 
                        "%x%x",
                        ( target_ptr[ k ] >> 4 ) & 15,
                        ( target_ptr[ k ] >> 0 ) & 15 );
            }
            if( len > outlen) break;
            len+=snprintf(outbuf+len, outlen-len, 
                    " ");
        }

        if( len > outlen) break;
        if( detail )
        {
            len+=snprintf(outbuf+len, outlen-len, 
                    " : ");

            for(    j = i ; 
                    (j < i+dumpColumnSize) && ( j < length ) ; 
                    j += dumpLineSize )
            {
                for(    k = j ; 
                        ( k < j+dumpLineSize ) & ( k < length ) ; 
                        k ++ )
                {
                    if(   ( ( '!' <= target_ptr[ k ] ) &&
                                ( '~' >= target_ptr[ k ] ) ) )
                    {
                        if( len > outlen) break;
                        len+=snprintf(outbuf+len, outlen-len, 
                                "%c",target_ptr[ k ] );
                    }
                    else
                    {
                        if( len > outlen) break;
                        len+=snprintf(outbuf+len, outlen-len, 
                                "." );
                    }
                }
            }
            if( len > outlen) break;
            if( i + dumpLineSize < length )
            {
                len+=snprintf(outbuf+len, outlen-len,     "\n");
            }
        }
    }
}

void    load_properties( const char * fileName )
{
    if (iniReader.ParseError() < 0) {
        std::cout << "Can't load 'test.ini'\n";
        exit( 0 );
    }

    setPerfInterval( get_property_int("common","perf_monitor_interval_msec") );
}

void    memStatReport()
{
    MSIterator      itr;
    MemStatInfo   * msiPtr;
    MemStatInfo     total;

    if( memStatEnable )
    {
        total.allocSize     = 0;
        total.allocCount    = 0;
        total.freeCount     = 0;
        total.maxAllocSize  = 0;

        banner("memStatReport");

        REPORT("%32s %10s %10s %10s %10s\n",
               "location",
               "allocSize",
               "allocCnt",
               "freeCnt",
               "maxAllocSize" );
        REPORT(BAR_STR BAR_STR "\n");
        memStatLock.RLock();
        for( itr = memStatMap.begin(); itr != memStatMap.end() ; itr ++ )
        {
            msiPtr = &(itr->second);
            REPORT("%32s %10d %10d %10d %10d(%d MB)\n",
                   msiPtr->codeName,
                   msiPtr->allocSize,
                   msiPtr->allocCount,
                   msiPtr->freeCount,
                   msiPtr->maxAllocSize,
                   msiPtr->maxAllocSize/1024/1024 );
            total.allocSize        +=    msiPtr->allocSize;
            total.allocCount    +=    msiPtr->allocCount;
            total.freeCount        +=    msiPtr->freeCount;
            total.maxAllocSize    +=    msiPtr->maxAllocSize;
        }
        memStatLock.release();
        REPORT(BAR_STR BAR_STR "\n");
        REPORT("%32s %10d %10d %10d %10d\n",
               "TOTAL(B)",
               total.allocSize,
               total.allocCount,
               total.freeCount,
               total.maxAllocSize );
        REPORT("%32s %10d %10d %10d %10d\n",
               "TOTAL(KB)",
               total.allocSize/1024,
               total.allocCount,
               total.freeCount,
               total.maxAllocSize/1024 );
        REPORT("%32s %10d %10d %10d %10d\n",
               "TOTAL(MB)",
               total.allocSize/1024/1024,
               total.allocCount,
               total.freeCount,
               total.maxAllocSize/1024/1024 );
    }
}

bool    csiMalloc(const char * codeFile, int codeLine,
                size_t size, void ** ptr )
{
    SimpleHash    sh;
    char          codeName[128];
    MemStatInfo   msi;
    MemStatInfo * msiPtr;
    MemHeader   * memHeader;
    int           seq;

    if( !memStatEnable )
    {
        *ptr = malloc( size );
        return (*ptr) != NULL;
    }

    /************************ stat ****************/
    snprintf( codeName, 128, "%s:%d",codeFile, codeLine );
    sh = getSimpleHash( strlen(codeName), codeName );

    memStatLock.RLock();
    MSIterator itr = memStatMap.find( sh );
    memStatLock.release();
    if( itr == memStatMap.end() )
    {
        strncpy( msi.codeName, codeName, 128 );
        msi.allocSize       =    0;
        msi.allocCount      =    0;
        msi.freeCount       =    0;
        msi.maxAllocSize    =    0;
        memStatLock.WLock();
        memStatMap[ sh ] = msi;
        msiPtr = &(memStatMap[ sh]);
        memStatLock.release();
    }
    else
    {
        msiPtr = &(itr->second);
    }

    atomicInc( &msiPtr->allocSize, size );
    seq = atomicInc( &msiPtr->allocCount, 1 );

    if( msiPtr->maxAllocSize < msiPtr->allocSize )
    {
        msiPtr->maxAllocSize = msiPtr->allocSize;
    }

    /***************************** alloc *********************/
    memHeader = (MemHeader*)malloc( size + sizeof(MemHeader ) );

    if( memHeader == NULL )
    {
        memStatReport();
        return NULL;
    }

    memHeader->size = size;
    memHeader->msiSH= sh;
    *ptr = (void*)(memHeader+1);

    if( seq < MEM_REGION_MAX )
    {
        msiPtr->regionPtrs[seq][0] = (char*)*ptr;
        msiPtr->regionPtrs[seq][1] = msiPtr->regionPtrs[seq][0]+size;
        assert( msiPtr->regionPtrs[seq][0]  != NULL );
        assert( (long)msiPtr->regionPtrs[seq][1]  != (long)0xffffffff );

    }

    return (*ptr) != NULL;
}

bool    csiFree( void * ptr )
{
    MemHeader    * memHeader;
    MemStatInfo  * msiPtr;

    if( !memStatEnable )
    {
        free( ptr );
        return true;
    }


    memHeader    = ((MemHeader*)ptr) - 1;
    memStatLock.RLock();
    msiPtr       = &( memStatMap[ memHeader->msiSH ] );
    memStatLock.release();

    atomicInc( &msiPtr->allocSize, - memHeader->size );
    atomicInc( &msiPtr->freeCount, 1 );

    free( memHeader );

    return true;
}

void checkMemRegion( void * ptr )
{
    MSIterator      itr;
    MemStatInfo   * msiPtr;
    int             i;

    REPORT("CHECK_MEM_REGION");

    memStatLock.RLock();
    REPORT("%32s %4s %-12s %-12s %12s\n",
            "location",
            "seq",
            "begin",
            "end",
            "target");
    REPORT(BAR_STR BAR_STR "\n");
    for( itr = memStatMap.begin(); itr != memStatMap.end() ; itr ++ )
    {
        msiPtr = &(itr->second);
        for( i = 0 ; i < msiPtr->allocCount ; i ++ )
        {
            if( ( msiPtr->regionPtrs[i][0] <= ptr ) &&
                ( msiPtr->regionPtrs[i][1] > ptr ) )
            {
                REPORT("%32s %4d 0x%-10x 0x%-10x 0x%-10x\n",
                        msiPtr->codeName,
                        i,
                        msiPtr->regionPtrs[i][0],
                        msiPtr->regionPtrs[i][1],
                        ptr );
            }
        }
    }
    memStatLock.release();
}

const int          filterSeed[]={0, 50, 100};
void initFilter( char * ptr, int size )
{
    csiMemset( ptr, 0, size );
}

void setFilter( char * ptr, int size, void * key )
{
    ByteArray       * ba = (ByteArray*)key;
    unsigned int      ret;
    int               i;

    if( size )
    {
        for( i = 0 ; i < (int)(sizeof(filterSeed)/sizeof(filterSeed[0])) ; i ++ )
        {
            MurmurHash3_x86_32( (const void*)ba->body, ba->len, filterSeed[i], &ret );

            ret %= (size << 3);
            ptr[ ret >> 3 ] |= 1 << (ret & 7);
        }
    }
}

void addFilter( char * dst, char * src, int size )
{
    int    i;

    for( i = 0 ; i < size ; i ++ )
    {
        dst[i] |= src[i];
    }
}

int     checkFilter( char * ptr, int size, void * key )
{
    ByteArray       * ba = (ByteArray*)key;
    unsigned int      ret;
    int               i;

    if( size )
    {
        for( i = 0 ; i < (int)(sizeof(filterSeed)/sizeof(filterSeed[0])) ; i ++ )
        {
            MurmurHash3_x86_32( (const void*)ba->body, ba->len, filterSeed[i], &ret );

            ret %= (size << 3);
            if( !(ptr[ ret >> 3 ] & ( 1 << (ret & 7) ) ) )
                return false;
        }
    }
    return true;
}

