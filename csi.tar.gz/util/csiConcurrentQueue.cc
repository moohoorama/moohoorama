#include <csiConcurrentQueue.h>
#include <csiWorkerPool.h>
#include <csiUtil.h>
#include <common.h>
#include <macro.h>

#define LINK_Q( p, n ) if(p)(p)->next=(n); if(n)(n)->prev=(p);

int                csiConcurrentQueue::sleepMsec = 100;
csiSimpleRWLock    csiConcurrentQueue::globalLock;
csiConcurrentQueue csiConcurrentQueue::globalHead;

void csiConcurrentQueue::globalInit()
{
    sleepMsec = get_property_int("concurrency","queue_sleep_msec" );

    CSI_SRWL_INIT( &globalLock );
    globalHead.next = &globalHead;
    globalHead.prev = &globalHead;
}
void csiConcurrentQueue::globalDest()
{
    csiConcurrentQueue * iter;

    globalLock.RLock();
    for( iter = globalHead.next ; iter != &globalHead ; iter=iter->next )
    {
        LINK_Q( iter->prev, iter->next );
    }
    globalLock.release();
    globalLock.dest();
}
bool csiConcurrentQueue::init( const char *codeFile, 
                               int         codeLine, 
                               int         userSize )
{
    snprintf( codeName, 128, "%s:%d",codeFile, codeLine );

    count     = userSize + 2; /* push/pop gap = 2 */
    popPos    = 0;
    pushPos   = 0;

    popMiss   = 0;
    pushMiss  = 0;

    TEST( CSI_MALLOC( sizeof(csiCQStatus) * count, (void**)(&status) ) );
    TEST( CSI_MALLOC( sizeof(VoidPtr) * count, (void**)(&queue) ) );

    csiMemset( (void*)status, CSI_CQ_PUSHABLE, sizeof( csiCQStatus ) * count );
    csiMemset( (void*)queue, 0,  sizeof(VoidPtr) * count );

    globalLock.WLock();
    LINK_Q( this, globalHead.next );
    LINK_Q( &globalHead, this );
    globalLock.release();

    return true;

    EXCEPTION_END;

    free();

    return false;
}

void csiConcurrentQueue::free()
{
    globalLock.WLock();
    LINK_Q( this->prev,this->next );
    globalLock.release();
    CSI_FREE( (void*)queue );
    CSI_FREE( (void*)status );
}

void csiConcurrentQueue::push( VoidPtr *ptr )
{
    int prev,next;
    int    pos;

    while( true )
    {
        prev = pushPos;
        next = prev + 1;
        pos = next % count;
        if( ( next == popPos ) || ( status[ pos ] != CSI_CQ_PUSHABLE ) )
        {/* 꽉참 */
            usleep( sleepMsec );
            pushMiss ++;
        }
        else
        {
            if( __sync_bool_compare_and_swap( &pushPos, prev, next ) ) break;
        }
    }

    pos = prev % count;

    __sync_synchronize();
    /* Push 가능할때까지 대기 */
    while( __sync_bool_compare_and_swap( &status[ pos ],
                                         CSI_CQ_PUSHABLE, CSI_CQ_PUSHING )
            == false )
    {
        __sync_synchronize();
    }

    queue[ pos ] = *ptr;
    CSI_ASSERT( __sync_bool_compare_and_swap( &status[ pos ],
                                              CSI_CQ_PUSHING, CSI_CQ_POPABLE )
            == true );
}

bool csiConcurrentQueue::pop( VoidPtr *ptr )
{
    int prev,next;
    int pos;

    do
    {
        prev = popPos;
        next = prev + 1;
        pos = prev % count;
        if( prev == pushPos )
        {/* 비어있음 */
            popMiss ++;
            return false;
        }
        if( status[ pos ] != CSI_CQ_POPABLE )
        {
            continue; /*retry*/
        }
    }
    while( __sync_bool_compare_and_swap( &popPos, prev, next ) == false );

    pos = prev % count;

    /* 복사가 끝날때까지 대기함 */
    while( __sync_bool_compare_and_swap( &status[ pos ],
                                         CSI_CQ_POPABLE, CSI_CQ_POPPING )
            == false )
    {
        __sync_synchronize();
    }

    *ptr = queue[ pos ];
    CSI_ASSERT( __sync_bool_compare_and_swap(&status[ pos ],
                                             CSI_CQ_POPPING, CSI_CQ_PUSHABLE )
            == true );

    return true;
}

void csiConcurrentQueue::report()
{
    int free = getFree();
    REPORT("%-32s Usage(%8d:%8d => %8d/%8d), miss(push:%8d, pop:%d)\n",
           codeName,
            pushPos, popPos,
            free,
            count,
            pushMiss,
            popMiss );
}
void csiConcurrentQueue::reportGlobal()
{
    const int           highestCount = 8;
    int                 highestVal[ highestCount ];
    int                 highestIdx[ highestCount ];
    csiConcurrentQueue *iter;
    int                 i;

    globalLock.RLock();

    banner( "QUEUE");
    prepareHighestEntry( (int*)highestVal, (int*)highestIdx, highestCount );
    for( iter = globalHead.next ; iter != &globalHead ; iter=iter->next )
    {
        pickHighestEntry( (int*)highestVal, (int*)highestIdx, highestCount,
                          iter->getTotalMissCount(), (ulong)iter );
    }
    for( i = 0 ; i < highestCount ; i ++ )
    {
        if( highestIdx[ i ] != -1 )
        {
            iter = (csiConcurrentQueue*)highestIdx[ i ];
            iter->report();
        }
    }
    globalLock.release();
}
