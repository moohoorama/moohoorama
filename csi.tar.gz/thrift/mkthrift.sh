thrift --gen cpp --gen java --gen py --gen html cos.thrift
javac gen-java/cosThrift/COSClient.java
