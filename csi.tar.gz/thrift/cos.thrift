#!/usr/local/thrift/bin/thrift --gen cpp --gen java

namespace cpp cosThrift
namespace java cosThrift

service COSThrift {
	oneway void ping(),
	bool init( 1:bool monitoring, 2:bool signalHandling, 3:bool forceStdout ),
	bool reload(),
	bool dest( 1:bool immedate ),
	bool createSI(1:binary SIName),
	bool flush(),
	bool nodemerge(),
	bool compaction(),
	bool put(1:binary SIName, 2:binary key, 3:binary value),
	binary get(1:binary SIName, 2:binary key)
}
