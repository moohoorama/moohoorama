
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.TException;
import cosThrift.*;

public class test {
	public static void main( String argc[] )
	{
		COSThrift.Client	client;
		TTransport			tr = new TSocket("localhost", 9090);
		String				myhost="127.0.0.1";
		int					i;

		TProtocol proto = new TBinaryProtocol(tr);
		client = new COSThrift.Client( proto );

		try
		{
			tr.open();
			System.out.println("..."+tr);
			System.out.println("thrift test : " + client);

			System.out.println("ping!!");
			client.test();
			int ret = 0;
			for( i = 0 ; i < 10000 ; i ++ )
			{
				ret =  client.ping();
				System.out.println( i + ": " + ret );
				Thread.sleep( 1000 );
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		tr.close();
	}
}
