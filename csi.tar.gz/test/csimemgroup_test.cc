#include <csiSimpleRWLock.h>
#include <csiMemGroup.h>
#include <testutil.h>

#define KVSIZE_MAX      8192
#define MAX_VALUE       (loopCount*(threadCount/2))

csiMemGroup * memGroup = NULL;

int     keySize     = -1;
int     valSize     = -1;
int     threadCount = -1;
int     loopCount   = -1;
bool    dump        = false;

bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "t:l:k:v:d";
    int             param_opt;

    threadCount = -1;
    loopCount   = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 't':
            threadCount = atoi( optarg );
            break;
        case 'l':
            loopCount = atoi( optarg );
            break;
        case 'k': 
            keySize = atoi( optarg );
            break;
        case 'v': 
            valSize = atoi( optarg );
            break;
        case 'd': 
            dump = true;
            break;

        }
    }

    if( ( threadCount   == -1   ) ||
        ( loopCount     == -1   ) ||
        ( keySize       == -1 ) ||
        ( valSize       == -1 ) )
    {
        printf("csimemgroup_test -t [thread_count] -l [try_count_per_thread] -k [keySize] -v [valSize] {-d} \n");
        return false;
    }

    return true;
}



void * memGroupInsertTest( void * ptr )
{
    char                Buf[KVSIZE_MAX];
    int                 num = (int)ptr;
    ByteArray           key;
    ByteArray           val;
    ByteArray           result;
    csiMemGroupResult   ret;
    int                 i;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( rand() % ('~' - '!') );

    key.len = keySize;
    val.len = valSize;
    key.body = (uchar*)Buf;
    val.body = (uchar*)Buf;

    *(((int*)Buf)+1) = num;

    result.alloc( CSI_BA_POOL_TEST );

    for( i = 0 ; i < loopCount ; i ++ )
    {
        *((int*)Buf) = i;

        if( num & 1 )
        {
            CSI_ASSERT( memGroup->insertAndSort( key,val, 0/*delinfo*/, &ret ) );
        }
        else
        {
            memGroup->read( key,&result  );
        }
    }

    result.free();

    return NULL;
}

#define BUFFER_LEN 40

void fullScan()
{
    KVIterator    itr;
    ByteArray     ba;
    char          hexBuf[ BUFFER_LEN ] ={0};
    int           count = 0;

    itr = memGroup->beginScan();
    while( memGroup->isEndScan( &itr ) == false )
    {
        if( dump )
        {
            printf( "%8d - ", count );
            ba = itr->first;
            dump_hex( (char*)ba.body, ba.len, (char*)hexBuf, BUFFER_LEN, 
                    false/*detail*/ );
            printf("%4d|%40s", ba.len, hexBuf);
            ba = itr->second;
            dump_hex( (char*)ba.body, ba.len, (char*)hexBuf, BUFFER_LEN, 
                    false/*detail*/ );
            printf(" %4d|%40s\n", ba.len, hexBuf);
        }
        itr ++;
        count ++;
    }

    printf("count : %d\n",count);
}

bool test()
{
    TEST( initUtil() );
    TEST( ByteArray::init() );
    TEST( csiPageManager::init() );
    csiMemGroup::init();

    TEST( memGroup=csiMemGroup::create() );

    doParallelTest( memGroupInsertTest, threadCount, false /*qps*/);
    memGroup->report();

    fullScan();

    csiMemGroup::dest();
    TEST( csiPageManager::dest() );
    TEST( destUtil() );

    return true;

    EXCEPTION_END;

    return false;
}

int main(int argc, char **argv)
{
    if(readArg( argc, argv ) )
    {
        CSI_ASSERT( test() );
    }

    return 0;
}

