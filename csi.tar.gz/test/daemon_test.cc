#include <COSThrift.h>
#include <transport/TSocket.h>
#include <protocol/TBinaryProtocol.h>
#include <transport/TBufferTransports.h>

using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;

using boost::shared_ptr;

using namespace cosThrift;

/*
int main(int argc, char **argv) {
    TSocket         socket(new TSocket("localhost", 9090));
    TTransport      transport(new TBufferedTransport(socket));
    TProtocol       protocol(new TBinaryProtocol(transport));
    COSThriftClient client(protocol);

    try {
        transport->open();
    } catch (TException &tx) {
        printf("ERROR: %s\n", tx.what());
    }

    client.ping();
    printf("ping()\n");

    try {
        transport->close();
    } catch (TException &tx) {
        printf("ERROR: %s\n", tx.what());
    }
    return 0;
}
*/

int main(int argc, char **argv) {
    shared_ptr<TSocket> socket(new TSocket("localhost", 9090));
    shared_ptr<TTransport> transport(new TBufferedTransport(socket));
    shared_ptr<TProtocol> protocol(new TBinaryProtocol(transport));
    COSThriftClient client(protocol);

    try {
        transport->open();
    } catch (TException &tx) {
        printf("ERROR: %s\n", tx.what());
    }

    client.ping();
    printf("ping()\n");

    try {
        transport->close();
    } catch (TException &tx) {
        printf("ERROR: %s\n", tx.what());
    }
    return 0;
}

