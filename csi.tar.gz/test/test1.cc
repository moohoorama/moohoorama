#include <stdio.h>
#include <csiInterface.h>

bool insertPerf( int count )
{
    char        keyBuf[16];
    char        valBuf[2048];
    int         retLen;
    char        * retBuf;
    int         i;
    uint64_t    startTime;
    uint64_t    endTime;
    uint64_t    durTime;
    bool        ret=true;
    int         len=8;
    int         seq;

    snprintf( keyBuf, 16, "%4dkey", 0  );
    for( i = 0 ; i < 1024 ; i ++ )
    {
        valBuf[i]='A'+i%20;
    }
    valBuf[i]='\0';

    startTime = get_cur_milliseconds();
    for( i = 0 ; i < count ; i ++ )
    {
        seq=rand();
        *((int*)keyBuf) = seq;
        *((int*)valBuf) = seq;

        ret&=csiInsert( 4, 
                "test", 
                len, keyBuf,
                128, valBuf,
                0 /* delInfo*/
                );
        /*
        if( (i & 65535)==0)
        {
            printf("%d\n",i);
        }
        */
    }
    endTime = get_cur_milliseconds();

    durTime = endTime - startTime;
    printf("QPS : %lf %llu\n", 
            (count)*1.0f/(durTime/1000.0f),
            durTime,
            endTime,
            startTime );

    return ret;
}




bool insertAndRead( int count )
{
    char        keyBuf[16];
    int         retLen;
    char        * retBuf;
    int         i;
    bool        ret=true;
    char        valBuf[2048];
    int         len=8;
    int         seq;

    snprintf( keyBuf, 16, "%4dkey", 0  );
    for( i = 0 ; i < 1024 ; i ++ )
    {
        valBuf[i]='A'+i%20;
    }
    valBuf[i]='\0';

    for( i = 0 ; i < count ; i ++ )
    {
        seq=rand();
        *((int*)keyBuf) = seq;
        *((int*)valBuf) = seq;

        ret&=csiInsert( 4, "test", 
                len, keyBuf,
                32, valBuf,
                0 /* delInfo*/
                );
    }

    for( i = 0 ; i < count ; i ++ )
    {
        seq=i;
        *((int*)keyBuf) = seq;
        retLen = sizeof( valBuf );
        csiRead( 4, "test",len,keyBuf, &retLen,&retBuf );
        if( retLen > 0 )
        {
            if(*((int*)retBuf) != seq )
            {
                printf("key   :\n" );
                print_hex( keyBuf, len );
                printf("val   :\n" );
                print_hex( retBuf, retLen );
                CSI_ASSERT( false );
            }
        }
        csiReadEnd( retBuf );
    }

    return ret;
}


int main(int argc, char **argv)
{
    CSI_ASSERT( csiInit( true /*monitoring*/ )  );

    csiCreate( 4, "test" );
    csiCreate( 4, "test" ); /* dup name test */
    csiCreate( 5 ,"testa" );
    csiCreate( 5, "testb" );
    csiCreate( 5, "testc" );
    csiCreate( 5, "testd" );
    csiCreate( 4, "test" ); /* dup name test */

    csiForceBlockingFlushAll();
    csiForceBlockingFlushAll();
    csiForceBlockingFlushAll();
    csiForceBlockingFlushAll();

    CSI_ASSERT( insertPerf( 100000 ) );
    CSI_ASSERT( insertAndRead( 1000 ) );

    csiForceBlockingFlushAll();
    csiReportAll();

    CSI_ASSERT( csiDest( true /* immediate */ ) );
    csiReportAll();

    return 0;
}
