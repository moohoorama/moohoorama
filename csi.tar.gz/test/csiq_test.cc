#include <csiUtil.h>
#include <testutil.h>
#include <csiByteArray.h>
#include <csiConcurrentQueue.h>

#define THREAD_MAX 256

int     size = 0;
int     testCount = 1000;
int     threadCount = -1;
int     reportInterval  =   50000;
csiConcurrentQueue    queue;

void *testFunc( void * arg)
{
    const char  job[][8]={"push","pop"};
    int         num = (int)arg;
    int         i;
    int         val = num;
    int         tryCount = 0;

    for( i = 0 ; i < testCount ; i ++ )
    {
        if( num & 1 )
        {
            tryCount = 0;
            while( queue.pop( (VoidPtr*) &val ) == false )
            {
                tryCount ++;
                if( tryCount > 1000 )
                {
                    printf("Miss:%d\n",i);
                    queue.report();
                    tryCount = 0;
                }
                usleep( 1000 );
            } 
        }
        else
        {
            queue.push( (VoidPtr*) &val );
        }
        if( ((i+1) % reportInterval ) == 0 ) 
        {
            queue.report();
            printf("[%2d %4s]:%d\n",num, job[ num&1],i);
        }
    }

    return NULL;
}

bool testConcurrency()
{
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;
    uint64_t            sum1 = 0;
    uint64_t            sum2 = 0;

    queue.init( "TEST",0,size );

    startTime = get_cur_milliseconds();
    doParallelTest( testFunc, threadCount, false /*qps*/ );
    endTime = get_cur_milliseconds();



    printf(BAR_STR"\n");
    durTime = endTime - startTime;
    if( durTime == 0.0 )
    {
        sum2 = 0;
    }
    else
    {
        sum2 =  (uint64_t)testCount  * threadCount * 1000 / durTime ;
    }

    printf("%4s : %6lld(or %6lld)\n", "queue", sum2, sum1 );

    queue.report();
    queue.free();

    return true;
}

bool testFull()
{
    int         val = 1;

    printf("testFull ... ");
    queue.init("TEST",0, 4 );

    queue.push( (VoidPtr*) &val );
    queue.push( (VoidPtr*) &val );
    queue.push( (VoidPtr*) &val );

    queue.report();
    queue.free();
    printf("done\n");

    return true;
}

bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "s:c:t:r:";
    int             param_opt;

    size        = -1;
    testCount   = -1;
    threadCount = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
            case 's':
                size = atoi( optarg );
                break;
            case 'c':
                testCount = atoi( optarg );
                break;
            case 't':
                threadCount = atoi( optarg );
                break;
            case 'r':
                reportInterval = atoi( optarg );
                break;
        }
    }

    if( ( size == -1 ) || 
            ( threadCount == -1 ) )
    {
        printf("csiq_test -s [queue_size] -c [test_count] -t [thread_count] { -r [report_count] }\n");
        return false;
    }

    CSI_ASSERT( threadCount < THREAD_MAX );

    return true;
}



int main(int argc, char **argv)
{
    CSI_ASSERT( readArg( argc, argv ) );

    CSI_ASSERT( initUtil() );
    CSI_ASSERT( testFull() );
    CSI_ASSERT( testConcurrency() );
    CSI_ASSERT( destUtil() );


    return 0;
}

