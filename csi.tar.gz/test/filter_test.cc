#include <csiUtil.h>
#include <testutil.h>
#include <csiByteArray.h>

#define KVSIZE_MAX 8192

int     size = 0;
int     kvCount = 0;

void initFilter( char * ptr, int size );
void setFilter( char * ptr, int size, void * key );
int  checkFilter( char * ptr, int size, void * key );

bool filterTest()
{
    char          Buf[KVSIZE_MAX];
    char        * filter;
    int         * keyList;
    int           seq;
    int           failure;
    int           i;
    ByteArray     ba;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( rand() % ('~' - '!') );
    ba.len  = 16;
    ba.body = (uchar*)Buf;

    TEST( CSI_MALLOC( size, (void**)&filter ) );
    TEST( CSI_MALLOC( kvCount*sizeof(int), (void**)&keyList ) );

    initFilter( filter, size );

    printf("Set filter:\n");
    for( i = 0 ; i < kvCount ; i ++ )
    {
        seq=rand() % kvCount*2;
        keyList[i] = seq;
        *((int*)Buf) = seq;

        setFilter( filter, size, (void*)&ba );
    }

    print_hex( filter, size );

    printf("check filter( true  ):");
    failure = 0 ;
    for( i = 0 ; i < kvCount ; i ++ )
    {
        seq = keyList[i];
        *((int*)Buf) = seq;

        if( !( checkFilter( filter, size, (void*)&ba ) ) )
        {
            failure ++;
        }
    }
    printf("failure : %6d/%6d %6.2f\n",failure,kvCount, failure*100.0/kvCount);

    printf("check filter(failure):");
    failure = 0 ;
    for( i = 0 ; i < kvCount ; i ++ )
    {
        seq = keyList[i] + kvCount*2;
        *((int*)Buf) = seq;

        if( ( checkFilter( filter, size, (void*)&ba ) ) )
        {
            failure ++;
        }
    }
    printf("failure : %6d/%6d %6.2f\n",failure,kvCount, failure*100.0/kvCount);

    CSI_FREE( filter );

    return true;

    EXCEPTION_END;

    return false;
}

bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "s:c:";
    int             param_opt;

    size = -1;
    kvCount = -1;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
            case 's':
                size = atoi( optarg );
                break;
            case 'c':
                kvCount = atoi( optarg );
                break;
        }
    }

    if( ( size == -1 ) || 
            ( kvCount == -1 ) )
    {
        printf("filter_test -s [filter_size] -c [kv_Count]\n");
        return false;
    }

    return true;
}

int main(int argc, char **argv)
{
    CSI_ASSERT( readArg( argc, argv ) );

    CSI_ASSERT( initUtil() );
    CSI_ASSERT( filterTest() );
    CSI_ASSERT( destUtil() );


    return 0;
}

