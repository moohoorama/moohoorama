#include <linkedList.h>
#include <stdio.h>
#include <csiInterface.h>
#include <testutil.h>

bool linkedList()
{
    SyncLList     list;
    LList         attr[ 16 ];
    LList       * cur;
    int           i;

    SLIST_INIT( &list, 0/*spin*/,0/*sleep*/ );
    for( i = 0 ; i < 16 ; i ++ )
    {
        LLIST_INIT( &attr[i] );
        attr[i].data = (void*)((i+4)*4);
    }

    for( i = 0 ; i < 8 ; i ++ ) slist_pushHead( &list, &attr[i]);
    slist_report( &list );
    for( i = 8 ; i < 16; i ++ ) slist_pushTail( &list, &attr[i]);
    slist_report( &list );

    while( ( cur = slist_popTail( & list ) ) != NULL ) 
    {
        slist_report( &list );
        printf( "%d\n",(unsigned int)cur->data );
    }

    for( i = 0 ; i < 8 ; i ++ ) slist_pushHead( &list, &attr[i]);
    slist_report( &list );
    for( i = 8 ; i < 16; i ++ ) slist_pushTail( &list, &attr[i]);
    slist_report( &list );


    while( ( cur = slist_popHead( & list ) ) != NULL ) 
    {
        slist_report( &list );
        printf( "%d\n",(unsigned int)cur->data );
    }


    return true;
}

#define TCOUNT      64
#define TRYCOUNT    65536

SyncLList     list;
LList         attr[ TCOUNT ][ TRYCOUNT ];

void *run( void * arg)
{
    int num = (int)arg;
    int i;

    for( i = 0 ; i < TRYCOUNT ; i ++ )
    {
        attr[ num ][ i ].data =(void*)( num*10000 + i );
        slist_pushHead( &list, &attr[ num ][i ] );
    }

    return NULL;
}
bool concurrencyTest()
{
    LList   * cur;
    int       totalCount = 0;

    SLIST_INIT( &list, 0/*spin*/,0/*sleep*/ );
    doParallelTest( run, TCOUNT, false /*qps*/ );


    while( ( cur = slist_popTail( & list ) ) != NULL ) 
    {
        totalCount ++;
    }
    printf("totalCount : %d\n",totalCount);

    return true;
}

int main(int argc, char **argv)
{
    int     totalSize = 16384 * 16384 / 16;
    int     size;
    int     i;
    int     j;

    CSI_ASSERT( csiInit( true /*monitoring*/ )  );

    CSI_ASSERT( linkedList() );
    CSI_ASSERT( concurrencyTest() );

    CSI_ASSERT( csiDest( false /* immediate */ ) );


    return 0;
}
