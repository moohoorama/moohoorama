#include <stdio.h>
#include <csiInterface.h>
#include <testutil.h>

#define SI_NAME "data"

#define KVSIZE_MAX 2048

int     keySize     = 16;
int     valSize     = 512;
int     loopCount   = 20;
int     tryCount    = 10000;
int     threadCount = 4;

bool readArg( int argc, char ** argv);
bool insertPerf( int count );
bool rangeScan( int begin, int end, int count );
bool fullScan( int count );
bool printFull();

void parallelScanTest( int threadCount);

int main(int argc, char **argv)
{
    int i;

    CSI_ASSERT( readArg( argc, argv ) );

    CSI_ASSERT( csiInit( true /*monitoring*/ )  );

    csiCreate( 4, SI_NAME );

    for( i = 0 ; i < 70 ; i ++ )
    {
        csiForceBlockingFlushAll();
        CSI_ASSERT( insertPerf( loopCount ) );
    }
    for( i = 0 ; i < loopCount+5 ; i ++ )
    {
        CSI_ASSERT( fullScan( i ) );
    }
    for( i = 0 ; i < loopCount/2 ; i ++ )
    {
        CSI_ASSERT( rangeScan( i, i+loopCount/2, loopCount/2 ) );
        if( ( i % 1000) == 0 )
            printf("%d\n",i);
    }

    csiForceBlockingFlushAll();
    for( i = 0 ; i < loopCount/2 ; i ++ )
    {
        CSI_ASSERT( rangeScan( i, i+loopCount/2, loopCount/2 ) );
        if( ( i % 1000) == 0 )
            printf("%d\n",i);
    }

    parallelScanTest( threadCount );

    CSI_ASSERT( csiDest( true /* immediate */ ) );
//  csiReportAll();

    return 0;
}

void setDummyPattern( char * buffer, int len )
{
    int i;

    for( i = 0 ; i < len ; i ++ )
    {
        buffer[i] = '!' + ( i % ('~' - '!') );
    }
}

void setDummyData( char * buffer, int idx )
{
    buffer[0] = (idx>>24) & 255;
    buffer[1] = (idx>>16) & 255;
    buffer[2] = (idx>> 8) & 255;
    buffer[3] = (idx>> 0) & 255;
}
bool insertPerf( int count )
{
    char        keyBuf[KVSIZE_MAX];
    char        valBuf[KVSIZE_MAX];
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;
    bool        ret=true;
    int         i;

    setDummyPattern( (char*)keyBuf, keySize );
    setDummyPattern( (char*)valBuf, valSize );

    startTime = get_cur_milliseconds();
    for( i = 0 ; i < count ; i ++ )
    {
        setDummyData( (char*)keyBuf, i );
        setDummyData( (char*)valBuf, i );
        ret&=csiInsert( 
                4, SI_NAME, 
                keySize, keyBuf,
                valSize, valBuf,
                0 /* delInfo*/
                );
    }
    endTime = get_cur_milliseconds();

    durTime = endTime - startTime;
    printf("QPS : %lf\n", 
            (count)*1.0f/(durTime/1000.0f),
            durTime,
            endTime,
            startTime );

    return ret;
}

bool printFull()
{
    char        valBuf[KVSIZE_MAX];
    int         handle;
    csiResult * ret;
    int         j;
    int         k=0;
    char    buffer[ HEX_BUFFER_LEN ] ={0};

    setDummyPattern( (char*)valBuf, valSize );

    j = 0;
    handle = csiScan( 4, SI_NAME, OP_GTE, 20000000, 0, NULL );
    CSI_ASSERT( handle != -1 );
    while( ( ret = csiScanNext( handle ) )->keyLen > 0 )
    {
        while( ret->keyLen > 0 )
        {
//          print_hex( (char*)ret->keyBody, ret->keyLen );
//          print_hex( (char*)ret->valBody, ret->valLen );
            ret ++;
            j++;
        }
        k++;
    }
    CSI_ASSERT( csiScanEnd( handle ) );
    //printf("\n");

    return true;
}


bool fullScan( int count )
{
    char        valBuf[KVSIZE_MAX];
    int         handle;
    csiResult * ret;
    int         j;
    int         k=0;

    setDummyPattern( (char*)valBuf, valSize );

    j = 0;
    handle = csiScan( 4, SI_NAME, OP_GTE, count, 0, NULL );
    CSI_ASSERT( handle != -1 );
    while( ( ret = csiScanNext( handle ) )->keyLen > 0 )
    {
        while( ret->keyLen > 0 )
        {
            setDummyData( (char*)valBuf, j );
            if( *(int*)ret->valBody != *(int*)valBuf )
            {
                printf("%08x ",*(int*)ret->valBody );
                csiScanDump( handle );
                CSI_ASSERT( false );
            }
            ret ++;
            j++;
        }
        k++;
    }
    CSI_ASSERT( csiScanEnd( handle ) );
    //printf("\n");

    return true;
}

bool rangeScan( int begin, int end, int count )
{
    char        keyBuf[KVSIZE_MAX];
    char        valBuf[KVSIZE_MAX];
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;
    int         handle;
    csiResult * ret;
    int         i;
    int         j;

    setDummyPattern( (char*)keyBuf, keySize );
    setDummyPattern( (char*)valBuf, valSize );

    startTime = get_cur_milliseconds();
    for( i = begin ; i < end ; i ++ )
    {
        setDummyData( (char*)keyBuf, i );
        setDummyData( (char*)valBuf, i );

        j = 0;
        handle = csiScan( 4, SI_NAME, OP_GTE, count, keySize, keyBuf );
        CSI_ASSERT( handle != -1 );
        while( ( ret = csiScanNext( handle ) )->keyLen > 0 )
        {
            while( ret->keyLen > 0 )
            {
                setDummyData( (char*)keyBuf, i+j );
                setDummyData( (char*)valBuf, i+j );
                if( *(int*)ret->keyBody != *(int*)keyBuf )
                {
                    printf("%08x %08x",*(int*)ret->keyBody, *(int*)keyBuf );
                    csiScanDump( handle );
                    CSI_ASSERT( false );
                }
                if( *(int*)ret->valBody != *(int*)valBuf )
                {
                    printf("%08x ",*(int*)ret->valBody );
                    csiScanDump( handle );
                    CSI_ASSERT( false );
                }
                ret ++;
                j++;
            }
        }
        CSI_ASSERT( csiScanEnd( handle ) );
    }

    return true;
}


void *rangeScanTest( void * arg)
{
    char        keyBuf[KVSIZE_MAX];
    char        valBuf[KVSIZE_MAX];
    int         num = (int)arg;
    uint64_t            startTime;
    uint64_t            endTime;
    uint64_t            durTime;
    int         handle;
    csiResult * ret;
    int         i;
    int         j;
    int         count = tryCount;

    printf("ThreadID : %d\n",(int)pthread_self());
    printf("Start Range Test %d\n",num );
    setDummyPattern( (char*)keyBuf, keySize );
    setDummyPattern( (char*)valBuf, valSize );

    startTime = get_cur_milliseconds();
    for( i = 0 ; i < count ; i ++ )
    {
        int begin = i;
        setDummyData( (char*)valBuf, i );
        snprintf(keyBuf, KVSIZE_MAX, "user%d", begin );

        j = 0;
        handle = csiScan( 4, SI_NAME, OP_GTE, loopCount, keySize, keyBuf );
        CSI_ASSERT( handle != -1 );
        while( ( ret = csiScanNext( handle ) )->keyLen > 0 )
        {
            while( ret->keyLen > 0 )
            {
                /*
                setDummyData( (char*)keyBuf, i+j );
                setDummyData( (char*)valBuf, i+j );
                if( *(int*)ret->keyBody != *(int*)keyBuf )
                {
                    printf("%08x %08x",*(int*)ret->keyBody, *(int*)keyBuf );
                    csiScanDump( handle );
                    CSI_ASSERT( false );
                }
                if( *(int*)ret->valBody != *(int*)valBuf )
                {
                    printf("%08x ",*(int*)ret->valBody );
                    csiScanDump( handle );
                    CSI_ASSERT( false );
                }
                */
                ret ++;
                j++;
            }
        }
        if( ( i % 1000 ) == 0 )
        {
            printf("%d - %d\n",num, i);
        }
        CSI_ASSERT( csiScanEnd( handle ) );
        incPerfStat();
    }

    return NULL;
}


void parallelScanTest( int threadCount)
{
    doParallelTest( rangeScanTest, threadCount, true );
}



bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "c:k:v:t:m:";
    int             param_opt;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 't':
            threadCount = atoi( optarg );
            break;
        case 'c':
            loopCount = atoi( optarg );
            break;
        case 'm':
            tryCount = atoi( optarg );
            break;
        case 'k': 
            keySize = atoi( optarg );
            break;
        case 'v': 
            valSize = atoi( optarg );
            break;
        }
    }

    printf("function_test -c [try_count_per_thread] -k [keySize] -v [valSize] \n");

    CSI_ASSERT( keySize <= KVSIZE_MAX );
    CSI_ASSERT( valSize <= KVSIZE_MAX );

    return true;
}



