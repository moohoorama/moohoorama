#include <csiSlotDir.h>
#include <testutil.h>

#define KVSIZE_MAX      8192

int keyCount = 50;


bool test()
{
    char              bufOrg[PAGE_SIZE*2];
    char            * buf = (char*)align( (unsigned int)bufOrg, PAGE_SIZE );
    csiSlotDir      * slotDir = (csiSlotDir*)buf;
    char              Buf[KVSIZE_MAX];
    ByteArray         key;
    ByteArray         img;
    map<int,int>      testMap;
    int               estiLen;
    int               val;
    int               seq;
    int               i;

    for( i = 0 ; i < KVSIZE_MAX ; i ++ )
        Buf[i] = '!' + ( rand() % ('~' - '!') );
    key.body = (uchar*)Buf;

    slotDir->init( CSI_SD_KEY_ONLY, buf + PAGE_SIZE );

    printf("allocSlot Test:\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s %4s ","key","free");
    printf("\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s %4s ","val","size");
    printf("\n");
    for( i = 0 ; i < keyCount ; i ++ )
    {
        val             = i * 2 + 1;
        *((int*)Buf)    = val;

        key.len = i + 4;
        CSI_ASSERT( slotDir->insertK( &key ) );
        testMap[ val ] = val;
        printf("%4d %4d ",
                val,
                slotDir->getFreeSize() );
        if( ( (i+1) & 7 ) == 0 )    printf("\n");
    }
    printf("\n");

    printf("getSlotSize Test:\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s,%4s ","key","slot");
    printf("\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s,%4s ","size","size");
    printf("\n");
    for( i = 0 ; i < keyCount ; i ++ )
    {
        slotDir->readBA( i, &img );
        printf("%4d,%4d ",img.len,slotDir->getSlotSize( i ) );
        if( ( (i+1) & 7 ) == 0 )    printf("\n");
    }
    printf("\n");

    /*
    printf("binarySearch Test:\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s,%4s ","inp","ret");
    printf("\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s,%4s ","ut ","urn");
    printf("\n");
    for( i = 0 ; i < keyCount*2+2 ; i ++ )
    {
        *((int*)Buf) = i;
        key.len = i/2 + 4;

        printf("%4d %4d ",i, slotDir->binarySearch( key ) );
        if( ( (i+1) & 7 ) == 0 )    printf("\n");
    }
    printf("\n");
    */

    printf("binarySearchInternal Test:\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s,%4s ","inp","ret");
    printf("\n");
    for( i = 0 ; i<8 ; i ++ )   printf("%4s,%4s ","ut ","urn");
    printf("\n");
    for( i = 0 ; i < keyCount*2+2 ; i ++ )
    {
        *((int*)Buf) = i;
        key.len = i/2 + 4;

        seq = slotDir->binarySearchInternal( key );
        if( (0 <= seq ) && ( seq < slotDir->slotCount ) )
        {
            slotDir->readBA( seq, &img );
            val = img.compare( &key );
            CSI_ASSERT( val <= 0 );
            val = *(int*)img.body;
        }
        //CSI_ASSERT( testMap.find( val ) == val );
        printf("%4d %4d ",i, seq );
        if( ( (i+1) & 7 ) == 0 )    printf("\n");
    }

    printf("\n");

    return true;

    EXCEPTION_END;

    return false;
}

bool sortTest()
{
    char              bufOrg[PAGE_SIZE*2];
    char            * buf = (char*)align( (unsigned int)bufOrg, PAGE_SIZE );
    csiSlotDir      * slotDir = (csiSlotDir*)buf;
    char              hexBuf[ HEX_BUFFER_LEN ] ={0};
    char            * ptr;
    int               val;
    ByteArray         key;
    ByteArray         prevKey;
    int               estiLen;
    int               i;
    int               pseudoRan = 5123;
    bool              wrong = false;

    slotDir->init( CSI_SD_KEY_ONLY, buf + PAGE_SIZE );

    printf("allocSlot Test:\n");
    for( i = 0 ; i < keyCount ; i ++ )
    {
        val= (pseudoRan );
        pseudoRan = ( pseudoRan * 1234 + 132 ) % 2634;

        key.len = sizeof( int );
        key.body= (uchar*)&val;
        CSI_ASSERT( slotDir->insertK( &key ) );
    }
    printf("\n");

    printf("inserted data Test:\n");
    for( i = 0 ; i < keyCount ; i ++ )
    {
        slotDir->readBA( i, &key );
        printf("%10x ",
                (key.body[0]<<24) |
                (key.body[1]<<16) |
                (key.body[2]<< 8) |
                (key.body[3]<< 0) );
        if( ( (i+1) & 15 ) == 0 )   printf("\n");
    }
    printf("\n");

    TEST( slotDir->sort() );

    printf("sorted data Test:\n");
    prevKey.len = 0;
    for( i = 0 ; i < keyCount ; i ++ )
    {
        slotDir->readBA( i, &key );

        printf("%10x ",
                (key.body[0]<<24) |
                (key.body[1]<<16) |
                (key.body[2]<< 8) |
                (key.body[3]<< 0) );

        if( prevKey < key )
        {
        }
        else
        {
            printf("<========= wrong order\n", key.len, hexBuf);
            wrong = true;
        }
        if( ( (i+1) & 15 ) == 0 )   printf("\n");

        prevKey = key;
    }
    printf("\n");
    CSI_ASSERT( wrong == false );

    return true;

    EXCEPTION_END;

    return false;
}

bool sortPerf()
{
    char              bufOrg[PAGE_SIZE*2];
    char            * buf = (char*)align( (unsigned int)bufOrg, PAGE_SIZE );
    csiSlotDir      * slotDir = (csiSlotDir*)buf;
    char              hexBuf[ HEX_BUFFER_LEN ] ={0};
    char            * ptr;
    int               val;
    ByteArray         key;
    ByteArray         prevKey;
    int               estiLen;
    int               i;
    int               j;
    int               count = 512;
    bool              wrong = false;

    slotDir->init( CSI_SD_KEY_ONLY, buf + PAGE_SIZE );

    for( i = 0 ; i < count ; i ++ )
    {
        val = pseudoRand();

        key.len = sizeof( int );
        key.body= (uchar*)&val;
        CSI_ASSERT( slotDir->insertK( &key ) );
    }

    for( i = 0 ; i < 128 ; i ++ )
    {
        TEST( slotDir->sort() );
    }


    return true;

    EXCEPTION_END;

    return false;
}

bool readArg( int argc, char ** argv)
{
    const char      optstr[] = "s:";
    int             param_opt;

    while( -1 != ( param_opt = getopt( argc, argv, optstr ) ) )
    {
        switch( param_opt )
        {
        case 's':
            keyCount = atoi( optarg );
            CSI_ASSERT( test() );
            exit(0);
            break;
        }
    }

    return true;
}




int main(int argc, char **argv)
{
    int i;

    (void)readArg( argc, argv );
    CSI_ASSERT( initUtil() );
    for ( i=0 ; i < 80 ; i ++ )
    {
        keyCount = i;
        printf(BAR_STR"\n"
                "%d\n"
                BAR_STR"\n",
                keyCount );
        CSI_ASSERT( test() );
        printf(BAR_STR"\n" );
        CSI_ASSERT( sortTest() );
//      CSI_ASSERT( sortPerf() );
    }
    CSI_ASSERT( destUtil() );

    return 0;
}

