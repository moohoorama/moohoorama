./COSThrift-remote -h 127.0.0.1:9090 init True True True
./COSThrift-remote -h 127.0.0.1:9090 createSI data

# ./COSThrift-remote -h 127.0.0.1:9090 flush

