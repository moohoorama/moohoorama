#ifndef __TESTUTILH__
#define __TESTUTILH__

#include <pthread.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <unistd.h>

inline int pseudoRand( int seed = 0)
{
    static int z = 1;
    static int w = 1;

    if( seed != 0 ) z = w = seed;

    z = 36969 * (z & 65535) + (z >> 16);
    w = 18000 * (w & 65535) + (w >> 16);

    return (z << 16) + w;  /* 32-bit result */
}

void setPerfInterval( int perfInterval);
void resetPerfStat();
void incPerfStat( int delta = 1);
int getPerfStat();
int *getPerfGraph();

void doParallelTest(void *(*routine) (void *), int parallel, bool qps = true);
#endif
