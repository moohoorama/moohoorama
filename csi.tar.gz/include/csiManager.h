#ifndef __CSI_MANAGER_H__
#define __CSI_MANAGER_H__

#include <common.h>
#include <csiStructure.h>
#include <csiMemGroup.h>
#include <csiStoredGroup.h>

typedef unordered_map<SimpleHash, csiSIInfo*>::iterator SIIterator;


class csiManager
{
public:
    static bool init();
    static bool dest();

    /*  SI를 새로 생성함. seq를 반환함 */
    static int createSI( int SINameLen, char * SIName );
    /*  SI를 없애버림 */
    static bool drop(int SINameLen, char * SIName );

    /*삽입을 수행함*/
    static bool insertKV(   int           SINameLen,
                            const char  * SIName, 
                            uint          keyLen,
                            char        * keyBody,
                            uint          valLen,
                            char        * valBody,
                            uint          info );

    /* 대상 SI를 찾음*/
    inline static csiSIInfo * chooseSI( int SINameLen, char * SIName, 
                                        bool createDropSI );
    inline static void        releaseSIMapLock();

    /*Read연산을 수행함*/
    /* 데이터 읽기*/
    static bool readKV( ByteArray SIName, ByteArray key, ByteArray *val  );
    static bool readInternal( csiSIInfo * si, ByteArray key, ByteArray *val );

    static bool softFlushAll();

    /* 강제적으로 switch & flush를 수행함 */
    static bool forceSwitchAndFlushAll();
    static bool forceSwitchAndFlush(int SINameLen, const char * SIName );

    /* 강제적으로 Compaction을 수행함 */
    static bool forceCompactionAll();
    static bool forceCompaction(int SINameLen, const char * SIName );

    /* 강제적으로 RangeCompaction을 수행함 */
    static bool forceRangeCompactionAll();
    static bool forceRangeCompaction(int SINameLen, const char * SIName );
    /* 강제적으로 NodeMerge을 수행함 */
    static bool forceNodeMergeAll();
    static bool forceNodeMerge(int SINameLen, const char * SIName );
    static uint64_t getSize(int SINameLen, const char * SIName );
    static uint64_t getMemgroupSize(int SINameLen, const char * SIName );

    /*memGroup을 stored Group으로 Flush함 ( Worker에의해서만 호출되어야함 ) */
    static bool flushMemGroup( csiSIInfo * info ); 
    static bool nodeMerge( csiSIInfo * SI );
    static bool compaction( csiSIInfo   * SI, 
                            int           targetCount,
                            int           level,
                            ByteArray   * beginKey = NULL,
                            ByteArray   * endKey = NULL,
                            int           nodeCount = 0 );

    static int getNodeMergeThreshold(){ return nodeMergeThreshold;}

    /* si들의 상태를 보고함 */
    static void report();

    static void reportMaster();
    static void reloadMaster();
    static void storeMaster( bool lock = false );

    static void drawAll(const char * str, bool lock = false );
    static int  getMemGroupCountForSwitch()
    { return    memGroupCountForSwitch; }
private:
    /*memgroup을 flush 하기 위해 switch함 */
    static bool dropInternal( csiSIInfo * infoPtr );
    static void switchMemGroup( csiSIInfo * SI, int idx );
    static void wait4Insert( csiSIInfo * SI );
    static void wait4Flush( csiSIInfo * SI, int memGroupIdx );
    /* memGroup의 값이, StoredGroup에도 있는가*/
    static bool validationUsingMemGroup( csiSIInfo * SI, 
            csiMemGroup     * memGroup );
    /* src StoredGroup의 값이 ret storedGroup에도 있는가?*/
    static bool validationUsingStoredGroup( csiSIInfo * SI, 
            csiStoredGroup  * src, csiStoredGroup * ret );
    static bool validationOrder( csiSIInfo * SI, csiStoredGroup * target );

    static int                                    SIMaxCount;
    static int                                    SICount;
    static int                                    storedGroupLossValidation;
    static int                                    storedGroupOrderValidation;
    static int                                    memGroupCountForSwitch;
    static int                                    flushWaitingMsec;

    static int                                    nodeMergeThreshold;
    static int                                    compactionGroupThreshold;
    static int                                    compactionGroupCount;
    static int                                    drawGroup;

    static string                                 masterFN;

    static unordered_map<SimpleHash, csiSIInfo*>  SIMap;
    static csiSimpleRWLock                        siMapRWLock;
    static uint64_t                               lastFlushTime;
};


/*읽고 쓸 대상 Group을 찾음*/
csiSIInfo * csiManager::chooseSI(   int SINameLen, char * SIName, 
                                    bool  createDropSI )
{
    SimpleHash  sh = getSimpleHash( SINameLen, SIName );
    if( createDropSI )
    {
        siMapRWLock.WLock();
    }
    else
    {
        siMapRWLock.RLock();
    }
    SIIterator itr = SIMap.find( sh );
    if( itr == SIMap.end() )    return NULL;
    return itr->second;
}

void  csiManager::releaseSIMapLock()
{
    siMapRWLock.release();
}

#endif 
