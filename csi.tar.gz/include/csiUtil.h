#ifndef __CSI_UTIL_H__
#define __CSI_UTIL_H__

#include <common.h>
#include <csiSimpleRWLock.h>
#include <sys/time.h>
#include <unistd.h>
#include <MurMurHash3.h>

#include <unordered_map>
#include <string>

#define BAR_STR        "-----------------------------------------"
#define DOUBLE_BAR_STR "========================================="
#define HEX_BUFFER_LEN 32768

#ifdef __NORMAL__TRACE__
#define LOG         log_prefix(__FILE__,__LINE__);logln
#define LOG_HEX     log_prefix(__FILE__,__LINE__);log_hex
#define REPORT      report_text
#define REPORT_HEX  report_prefix(__FILE__,__LINE__);report_hex
#define DEBUG       debug_prefix(__FILE__,__LINE__);debug_text

#else
#define LOG(a,...)
#define LOG_HEX(a,...)
#define REPORT(a,...)   
#define REPORT_HEX(a,...)
#define DEBUG(a,...)
#endif
#define CSI_MALLOC(size,ptr)    csiMalloc(__FILE__,__LINE__,size,ptr)
#define CSI_FREE(ptr)           csiFree(ptr)

using namespace std;

typedef int SimpleHash;

/* Memory 할당에 관한 통계정보 */
#define MEM_REGION_MAX  32

typedef struct {
    char      codeName[128];
    int       allocSize;
    int       allocCount;
    int       freeCount;
    int       maxAllocSize;
    char    * regionPtrs[ MEM_REGION_MAX ][2];
} MemStatInfo;

typedef struct {
    size_t      size;
    int         msiSH; /*Simpleash 4 MemStatInfo  */
} MemHeader;

extern unordered_map<SimpleHash, MemStatInfo >              memStatMap;
extern csiSimpleRWLock                                      memStatLock;
typedef unordered_map<SimpleHash, MemStatInfo>::iterator    MSIterator;

extern int  debugging;

bool initUtil( bool signalHandling = true, bool forcerReportStdout = false);
bool destUtil();


/************************* DumpHex & Logging ***************************/
void    dumpStack();

void    banner( const char * str );
void    print_hex( char * target_ptr, int length );
void    report_hex( char * target_ptr, int length );
void    log_hex( char * target_ptr, int length );
void    dump_hex( char * target_ptr, int length, char * outbuf, int outlen, bool detail = true );

void    log_prefix( const char * codeFile, int codeLine);
void    logln( const char *format, ...);
void    syncLogReport();

void    report_prefix( const char * codeFile, int codeLine);
void    report_text( const char *format, ...);

void    debug_prefix( const char * codeFile, int codeLine);
void    debug_text( const char *format, ...);

void    drawBox( int x, int y, int width, int height, int color );
void    drawLine( int x,int y,int xx,int yy);
void    drawText( int x, int y, char * str );

void    drawGroup( char *k1, char *k2, int level);
void    drawGroupEnd();
void    drawPage( char * str);

int     secEstimater( uint64_t beginTime, uint64_t curTime, uint64_t progress, uint64_t goal);

inline uint64_t get_cur_microseconds()
{
    struct timeval mytime;

    // 현재 시간을 얻어온다.
    gettimeofday(&mytime, NULL);
    return (uint64_t)mytime.tv_sec * 1000 * 1000 + mytime.tv_usec;
}

inline uint64_t get_cur_milliseconds()
{
    return get_cur_microseconds() / 1000;
}

/************************* Property ***************************/
/* include/config.h에 PROPERTY_FILE 로 정의된 ./skvs.properties 
 * 파일에서  property를 읽은 값을 반환합니다.
 * 다음과 같이 사용 가능합니다.
 * get_property<int>("csi.int_value") 
 * get_property<string>("csi.int_value")  */

int     get_property_int(  const char * name );
string  get_property_string(  const char * name );

int     get_property_int( const char * category,  const char * name );
string  get_property_string( const char * category, const char * name );

/************************* Memory Management ***************************/

void    memStatReport();
bool    csiMalloc(const char * codeFile, int codeLine,
                size_t size, void ** ptr );
bool    csiFree(    void * ptr );
void    checkMemRegion( void * ptr );

inline void csiMemcpy(  void *dest, const void *src, int size )
{
    memcpy( dest, src, size );
}
inline void csiMemset(  void *dest, int val, int n )
{
    memset( dest, val, n );
}


/* report시, 가장 특정 값이 높은 데이터만 추려내는데 사용됨 */
inline void prepareHighestEntry(int * vals, int * idxs, int cnt )
{
    csiMemset( vals, -1, sizeof(int)*cnt );
    csiMemset( idxs, -1, sizeof(int)*cnt );
}
inline void pickHighestEntry( int * vals, int * idxs, int cnt, 
                       int   val,  int   idx )
{
    int j, k;
    if( vals[0] < val )
    {
        for( j = 0 ; j < cnt ; j ++ )
            if( vals[j] > val )
                break;
        j--;
        for( k = 0 ; k < j ; k ++ )
        {
            vals[k] = vals[k+1];
            idxs[k] = idxs[k+1];
        }
        vals[j] = val;
        idxs[j] = idx;
    }
}

/************************* Atomic Operation ***************************/
/* 값을 상승시키되, Max값에 도달하면 0으로 돌린다. */
inline int circularInc( volatile int * value, int max )
{
    int prevPos;
    int nextPos;

    do
    {
        prevPos = (*value) ;
        nextPos = ( prevPos + 1 ) % max;
    } while( __sync_bool_compare_and_swap( value, prevPos, nextPos ) 
            ==  false);

    return prevPos;
}

inline  int atomicInc( volatile int * value, int delta )
{
    return __sync_add_and_fetch( value, delta );
}

/************************* Others Operation ***************************/
inline int secEstimater(uint64_t beginTime, 
                        uint64_t curTime,
                        uint64_t progress,
                        uint64_t goal)
{
    uint64_t elapsedTime = curTime - beginTime;

    return elapsedTime*goal/progress;

}

inline int align( int val, int unit )
{

    return ( val + unit - 1 ) & ( ~(unit-1) );
}

inline SimpleHash getSimpleHash( int len, char * name )
{
    int h=5381;

    for(size_t i=0; i < len; i++) {
        h = ((h << 5) + h) ^ name[i];
    }

    return h;
}

inline void hash_32( const void * key, int len, uint32_t seed, void * out )
{
    MurmurHash3_x86_32( key, len, seed, out );
}

void initFilter( char * ptr, int size );
void setFilter( char * ptr, int size, void * key );
void addFilter( char * dst, char * src, int size );
int  checkFilter( char * ptr, int size, void * key );

inline unsigned int getThreadID()
{
    static int global_id=0;
    static __thread int tid=-1;
    if(tid == -1){
        tid = __sync_fetch_and_add(&global_id, 1);
    }
    return tid;
}

#endif 
