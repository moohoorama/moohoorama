#ifndef __CSI_WORKER_POOL_H__
#define __CSI_WORKER_POOL_H__

#include <common.h>
#include <pthread.h>
#include <csiConcurrentQueue.h>
#include <csiByteArray.h>

typedef enum {
    CSI_JOB_NONE,       /* 작업 없음 */
    CSI_JOB_REGISTERING,/* 작업 등록 중 */
    CSI_JOB_MONITORING, /* 상태 점검 작업 */
    CSI_JOB_FLUSH,      /* 대상 Group을 Flush(나아가 nodeMerge까지) */
    CSI_JOB_COMPACTION, /* 대상 Group을 Range Comp.(나아가 group comp.)*/
    CSI_JOB_MAX,
} csiJobType;

/* Worker가 수행할 작업이다. */
class csiJob{
public:
    csiJobType    type;
    void        * target;
    /* rangeCompaction시 지정할 begin/end key */
    ByteArray     beginKey;
    ByteArray     endKey;
    int           nodeCount;
    int           groupMergeLevel;
};

/* Monitoring Thread가 Monitor 정보 출력시 호출할 함수 */
typedef void (*ReportFunc) ();


#define CSI_REPORT_FUNCTION_COUNT 256

typedef enum {
    CSI_WORKER_POOL_INIT,
    CSI_WORKER_POOL_ACTIVE,
    CSI_WORKER_POOL_IMMEDIATE_SHUTDOWN,
    CSI_WORKER_POOL_NORMAL_SHUTDOWN
} csiWorkerPoolStatus;

class csiWorkerPool
{
public:
    static bool init( bool monitoring );
    static bool dest();
    static bool stopWorkers( bool immediate );

    /* Monitoring 업무를 등록함 */
    static void asyncMonitoring(); 
    /*Background로 Flush(또는 nodeMerge까지)수행함*/
    static void asyncFlush( void * group ); 
    /*Background로 Compaction을 수행함*/
    static bool asyncCompaction(    void        * group, 
                                    ByteArray     beginKey,
                                    ByteArray     endKey,
                                    int           nodeCount,
                                    int           groupMergeLevel ); 

    /* monitoring thread에 의해 보고될 rf(ReportFunction) 등록 */
    static void registRF( ReportFunc rf );
    static void reportAll();
private:
    static bool   pushJob( csiJob job, bool retry = true );
    static void * workerRun( void * ptr );
    static void   popAndDoJob( int pos, csiJob job );

    static void   monitoring();

    static void   report();

    static csiWorkerPoolStatus    status;

    static csiConcurrentQueue     jobQueue;
    static csiConcurrentQueue     bufferQueue;
    static csiJob               * jobBuffer;
    static int                    jobStats[2][CSI_JOB_MAX]; 

    static int            pushSleepMsec;
    static int            popSleepMsec;
    static pthread_t    * workerDesc;
    static int            workerCount;
    static int            workingThreadCount;

    static int            monitoringIntervalSec;

    /* rf(ReportFunction) */
    static ReportFunc     rfArray[CSI_REPORT_FUNCTION_COUNT];
    static int            rfCursor;
};

#endif 
