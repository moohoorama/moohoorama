#ifndef __CSI_IO_H__
#define __CSI_IO_H__

#include <common.h>
#include <csiStructure.h>
#include <sys/uio.h>

using namespace std;

#define WRITE_FD_SEQ    (0)

class csiIO
{
public:
    static bool init();
    static bool dest();

    /* appendPage를 호출한다면, 기록될 PID를 반환함 */
    static int  estimatedAppendPID()
    {   return lastPID; }
    /*데이터를 기록함*/
    static bool appendPage( char * data, int size, csiPageID * retPID );
    static bool appendPages( struct iovec * iov, int iovCnt, csiPageID * beginPID );

    /*데이터를 읽음. buffer는 반드시 4k 이상 이어야 함 */ 
    static bool readBulk( char * buffer, int size, csiPageID PID);
    static bool readPage( char * buffer, csiPageID PID);
    static bool readMultiPage( char ** buffers, csiPageID PID, int pageCount);
    static bool trim(); /*대상 영역을 지움*/
    static bool restoreCursor()
    {
        return ( lseek64(   fd, 
                            ((off64_t)lastPID) * PAGE_SIZE, 
                            SEEK_SET ) ) 
            == ( ((off64_t)lastPID) * PAGE_SIZE );
    }
    static bool setLastPID( csiPageID PID )
    {
        lastPID = PID;
        return restoreCursor();
    }

    static off64_t  getLastOffset()
    {
        off64_t ret = lseek64( fd, 0, SEEK_END );
        restoreCursor();
        return ret;
    }

    static void report();
    static void dump( csiPageID PID );
private:

    static string             target;
    static int                fd;
    static int                printReadPID;
    static int                printWritePID;
    static int                readCount;
    static int                writeCount;
    static csiPageID          lastPID;
};

#endif 
