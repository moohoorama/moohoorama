/* Copyright [2013] <yw0119kim@samsung.net> */

#ifndef INCLUDE_CSIBYTEARRAY_H_
#define INCLUDE_CSIBYTEARRAY_H_

#include <csiUtil.h>
#include <csiConcurrentQueue.h>

typedef enum {
    CSI_BA_POOL_UNKNOWN,
    CSI_BA_POOL_TEST,
    CSI_BA_POOL_READ_RESULT,
    CSI_BA_POOL_COMPACTION,
    CSI_BA_POOL_MEM_VALIDATION,
    CSI_BA_POOL_STORED_VALIDATION,
    CSI_BA_POOL_ROOT_REWRITE,
    CSI_BA_POOL_SCAN,
    CSI_BA_POOL_SLOT_SCAN,
    CSI_BA_POOL_ASYNC_COMPACTION,
    CSI_BA_POOL_MEMGROUP,
    CSI_BA_POOL_SCANNER,
    CSI_BA_POOL_MAX
} CSI_BA_POOL_USAGE;

#define CSI_BA_SUPPLEMENTAL_LEN (INT32_MAX)

typedef struct {
    int32_t count;
    int32_t page_info;
    int32_t slot_idx;
} csiLargeValueRef;

/* len과 body의 간단한 byte array(BA) 자료구조 */
class ByteArray{
    static const int PARALLEL_MAX = 32;
 public:
    static bool init();
    static bool dest();

    static void report();
    static void basicTest();
    static int  changeMergeStyle(int newStyle) {
        int ret = cassandraStyleMerge;
        cassandraStyleMerge = newStyle;
        return ret;
    }

    ByteArray() {
        allocSize    = 0;
        len          = 0;
        type         = CSI_BA_POOL_UNKNOWN;
    }
    void log(int limitLen = 40);
    void dump(int limitLen = 40);
    void print(int limitLen = 40);
    bool secureBuffer(int length);
    void copyFrom(ByteArray * src);
    void append(ByteArray * src);
    void referencing(ByteArray * src);
    bool merge(ByteArray * src);

    bool isLargeValue() {
        return len > largeValueThreshold;
    }
    bool isNull() {
        if (this == NULL) return true;
        if (this->len == 0) return true;
        return false;
    }

    inline int compare(ByteArray * other) const {
        int minLen = (len < other->len) ? len : other->len;
        int ret;
        if ((ret = memcmp(body, other->body, minLen)) != 0)
            return ret;

        if (len < other->len) return -1;
        if (len > other->len) return 1;
        return 0;
    }

    inline bool operator<(const ByteArray& other) const {
        int minLen = (len < other.len) ? len : other.len;
        int i;
        for (i = 0 ; i < minLen ; i++) {
            if (body[i] < other.body[i]) return true;
            if (body[i] > other.body[i]) return false;
        }

        return len < other.len;
    }
    inline bool operator==(const ByteArray& other) const {
        int i;
        if (len != other.len) return false;

        for (i = 0 ; i < len ; ++i)
            if (body[i] != other.body[i])
                return false;

        return true;
    }

    void alloc(int type, int size = 0) {
        allocResultBA(this, type, size);
    }
    void free() {
        if (allocSize) {
            freeResultBA(body, type);
        }
        allocSize = 0;
    }

    static void allocResultBA(ByteArray * ba, int type , int size = 0);
    static void freeResultBA(void * ptr, int type);
    static bool validationBAPtr(void * ptr);
    static bool validationColumn(uchar * body);
    static void readAndMapping(
            map<ByteArray, ByteArray> *columnMap,
            uchar * body);

    int        allocSize;
    int        type;
    int        len;
    uchar    * body;

    static ByteArray nullByteArray;

    static int getResultBufferPoolSize() {
        if (resultBufferType == 0)
            return (1<<30);
        else
            return resultBufferPoolSize;
    }

    static int remainPoolFreeCount() {
        int ret = 0;
        for (int i = 0; i < poolParallel; ++i) {
            ret += poolQueue[i].getFree();
        }
        return ret;
    }

 private:
    static int getIdx() { return (getThreadID()%1023) % poolParallel; }
    static int getIdx(VoidPtr ptr){
        return (reinterpret_cast<uint32_t>(ptr)/resultBufferDefaultSize)
            % poolParallel;
    }

    static int                 poolStat[2][ CSI_BA_POOL_MAX ];
    static int                 resultBufferType;
    static int                 resultBufferDefaultSize;
    static int                 resultBufferPoolSize;
    static int                 cassandraStyleMerge;
    static int                 noMerge;
    static int                 retryLimit;
    static int                 largeValueThreshold;
    static int                 poolParallel;
    static char               *resultBufferPool;
    static csiConcurrentQueue  poolQueue[PARALLEL_MAX];
};

inline void ByteArray::allocResultBA(ByteArray * ba, int type, int size) {
    VoidPtr    ptr = 0;
    bool       remainFree;
    int        idx;
    int        i;

    if (size == 0) size = resultBufferDefaultSize;

    atomicInc(&poolStat[0][ type ], 1);

    ba->allocSize   = 0;
    ba->type        = type;
    ba->len         = 0;

    switch (resultBufferType) {
    case 0:
        CSI_MALLOC(size, reinterpret_cast<void**>(&(ba->body)));
        ba->allocSize  = size;
        break;
    case 1:
    case 2:
        idx = getIdx();

        CSI_ASSERT(resultBufferPool != NULL);
        CSI_ASSERT(size <= resultBufferDefaultSize);
        size = resultBufferDefaultSize;
        ba->allocSize    = size;

        while(true) {
            remainFree = false;
            for(i = 0; i < poolParallel; ++i) {
                if( poolQueue[idx].pop(&ptr) ) {
                    break;
                }
                if(poolQueue[idx].getFree()) 
                    remainFree = true;
                idx = (idx+1) % poolParallel;
            }
            if(i != poolParallel) {
                CSI_ASSERT(ptr);
                break;
            }
            if((!remainFree) && (resultBufferType == 2)) {
                CSI_MALLOC(size, reinterpret_cast<void**>(&ptr));
                break;
            }
        }
        CSI_DASSERT(resultBufferType == 2 || validationBAPtr(ptr));
        ba->body = reinterpret_cast<uchar*>(ptr);
        break;
    }
}

inline bool ByteArray::secureBuffer(int needSize) {
    uchar    * newBody;

    if (needSize > allocSize) {
        if (allocSize == 0)  return false;
        if(resultBufferType == 1 ) return false;

        while (allocSize < needSize) {
            allocSize *= 2;
        }

        if (!CSI_MALLOC(allocSize, reinterpret_cast<void**>(&newBody)))
            return false;
        csiMemcpy(newBody, body, len);
        freeResultBA(body, type);
        atomicInc(&poolStat[0][ type ], 1);
        body = newBody;
    }

    return true;
}

inline void ByteArray::copyFrom(ByteArray * src) {
    if (!src->isNull()) {
        if (secureBuffer(src->len)) {
            csiMemcpy(body, src->body, src->len);
            len = src->len;
        }
    }
}

inline void ByteArray::append(ByteArray * src) {
    if (!src->isNull()) {
        if (secureBuffer(src->len+len)) {
            csiMemcpy(body+len, src->body, src->len);
            len += src->len;
        }
    }
}

inline void ByteArray::referencing(ByteArray * src) {
    len     = src->len;
    body    = src->body;
}

inline void ByteArray::freeResultBA(void * ptr, int type) {
    atomicInc(&poolStat[1][ type ], 1);

    if (resultBufferType == 0) {
        CSI_FREE(ptr);
    }else{
        if (!validationBAPtr(ptr)) {
            CSI_FREE(ptr);
        } else {
            poolQueue[getIdx(ptr)].push(reinterpret_cast<VoidPtr*>(&ptr));
        }
    }
}

#endif  // INCLUDE_CSIBYTEARRAY_H_
