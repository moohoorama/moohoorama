#ifndef __CSI_EXCEPTION_H__
#define __CSI_EXCEPTION_H__

#include <csiUtil.h>
#include <stdio.h>

#define CSI_ASSERT(n) if(!(n)){dumpStack();LOG(#n);printf(#n);syncLogReport();assert(n);}

#define CSI_DASSERT(n)  CSI_ASSERT(n)
#define DTEST(n)        TEST(n)

#define EXCEPTION(label_name)                   \
    goto EXCEPTION_END_LABEL;                   \
    label_name :

#define EXCEPTION_END                           \
    EXCEPTION_END_LABEL:                        \
    do                                          \
    {                                           \
    } while (0)


#define TEST(expression)                            \
    do                                              \
    {                                               \
        if (!(expression))                          \
        {                                           \
            LOG("TEST("#expression")");             \
            dumpStack();                            \
            goto EXCEPTION_END_LABEL;               \
        }                                           \
        else                                        \
        {                                           \
        }                                           \
    } while (0)


#define TEST_RAISE(expression, label_name)          \
    do                                              \
    {                                               \
        if (!(expression))                          \
        {                                           \
            LOG("TEST("#expression")");             \
            dumpStack();                            \
            goto label_name;                        \
        }                                           \
        else                                        \
        {                                           \
        }                                           \
    } while(0)

#define EXCEPTION_RAISE(label_name)                 \
    do                                              \
    {                                               \
            goto label_name;                        \
    } while(0)

#endif /* __EXCEPTION_H__ */
